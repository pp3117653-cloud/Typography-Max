'use client'

// Typography — single-page application shell.
// All product views live on this route and switch via the hash router.

import { Suspense, lazy, useEffect } from 'react'
import { useHashRoute, navigate } from '@/hooks/use-hash-route'
import { useSession } from '@/hooks/use-session'
import { AppShell } from '@/components/typography/app-shell'
import { Skeleton } from '@/components/ui/skeleton'

const LandingView = lazy(() => import('@/components/typography/views/landing'))
const TemplatesView = lazy(() => import('@/components/typography/views/templates'))
const PricingView = lazy(() => import('@/components/typography/views/pricing'))
const HelpView = lazy(() => import('@/components/typography/views/help'))
const PrivacyView = lazy(() => import('@/components/typography/views/privacy'))
const TermsView = lazy(() => import('@/components/typography/views/terms'))
const LoginView = lazy(() => import('@/components/typography/views/login'))
const SignupView = lazy(() => import('@/components/typography/views/signup'))
const ForgotPasswordView = lazy(() => import('@/components/typography/views/forgot-password'))
const ResetPasswordView = lazy(() => import('@/components/typography/views/reset-password'))
const DashboardView = lazy(() => import('@/components/typography/views/dashboard'))
const NewProjectView = lazy(() => import('@/components/typography/views/new'))
const EditorView = lazy(() => import('@/components/typography/editor/editor-view'))
const SettingsView = lazy(() => import('@/components/typography/views/settings'))
const BillingView = lazy(() => import('@/components/typography/views/billing'))
const NotFoundView = lazy(() => import('@/components/typography/views/not-found'))

const PUBLIC_VIEWS = new Set(['landing', 'templates', 'pricing', 'help', 'privacy', 'terms'])
const AUTH_VIEWS = new Set(['login', 'signup', 'forgot-password', 'reset-password'])
const APP_VIEWS = new Set(['dashboard', 'new', 'editor', 'settings', 'billing'])

function ViewSkeleton() {
  return (
    <div className="mx-auto max-w-6xl px-4 py-12 sm:px-6" aria-busy="true" aria-label="Loading page">
      <Skeleton className="h-10 w-2/3 max-w-md" />
      <Skeleton className="mt-4 h-5 w-1/2 max-w-sm" />
      <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        <Skeleton className="h-48 rounded-lg" />
        <Skeleton className="h-48 rounded-lg" />
        <Skeleton className="h-48 rounded-lg" />
      </div>
    </div>
  )
}

function Fallback({ children }: { children: React.ReactNode }) {
  return (
    <Suspense fallback={<ViewSkeleton />}>
      <div className="animate-in fade-in duration-300">{children}</div>
    </Suspense>
  )
}

export default function Home() {
  const { route } = useHashRoute()
  const { status, user } = useSession()

  const isEditor = route.name === 'editor'
  const isAuthView = AUTH_VIEWS.has(route.name)
  const isAppView = APP_VIEWS.has(route.name)

  // Redirect signed-in users away from login/signup.
  useEffect(() => {
    if (isAuthView && status === 'authenticated' && route.name !== 'reset-password') {
      const target =
        (route.name === 'login' || route.name === 'signup') && 'returnTo' in route && route.returnTo
          ? route.returnTo
          : '/dashboard'
      navigate(target)
    }
  }, [isAuthView, status, route])

  // Guard app views behind auth (the editor's draft mode is open to guests).
  useEffect(() => {
    if (status === 'unauthenticated' && isAppView && !(isEditor && route.name === 'editor' && route.id === 'draft')) {
      const current = window.location.hash.replace(/^#/, '') || '/'
      navigate(`/login?returnTo=${encodeURIComponent(current)}`)
    }
  }, [status, isAppView, isEditor, route])

  let content: React.ReactNode = null

  switch (route.name) {
    case 'landing':
      content = <Fallback><LandingView /></Fallback>
      break
    case 'templates':
      content = <Fallback><TemplatesView /></Fallback>
      break
    case 'pricing':
      content = <Fallback><PricingView /></Fallback>
      break
    case 'help':
      content = <Fallback><HelpView /></Fallback>
      break
    case 'privacy':
      content = <Fallback><PrivacyView /></Fallback>
      break
    case 'terms':
      content = <Fallback><TermsView /></Fallback>
      break
    case 'login':
      content = <Fallback><LoginView /></Fallback>
      break
    case 'signup':
      content = <Fallback><SignupView /></Fallback>
      break
    case 'forgot-password':
      content = <Fallback><ForgotPasswordView /></Fallback>
      break
    case 'reset-password':
      content = <Fallback><ResetPasswordView /></Fallback>
      break
    case 'dashboard':
      content = <Fallback><DashboardView /></Fallback>
      break
    case 'new':
      content = <Fallback><NewProjectView /></Fallback>
      break
    case 'editor':
      content = <Fallback><EditorView projectId={route.id} /></Fallback>
      break
    case 'settings':
      content = <Fallback><SettingsView /></Fallback>
      break
    case 'billing':
      content = <Fallback><BillingView /></Fallback>
      break
    default:
      content = <Fallback><NotFoundView /></Fallback>
  }

  return (
    <AppShell bare={isEditor}>
      {isAppView && status === 'loading' && !user ? <ViewSkeleton /> : content}
    </AppShell>
  )
}
