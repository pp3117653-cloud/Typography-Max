import type { Metadata, Viewport } from "next";
import {
  Inter,
  Space_Grotesk,
  Montserrat,
  Poppins,
  Playfair_Display,
  Lora,
  Bebas_Neue,
  Anton,
  Oswald,
  Dancing_Script,
  Caveat,
  JetBrains_Mono,
} from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { AppProviders } from "@/components/typography/providers";

/* UI fonts (preloaded) */
const inter = Inter({
  variable: "--font-inter",
  subsets: ["latin"],
  display: "swap",
});

const spaceGrotesk = Space_Grotesk({
  variable: "--font-space-grotesk",
  subsets: ["latin"],
  display: "swap",
});

/* Canvas template fonts — loaded on demand by the editor/preview, so
   preloading is disabled to keep first paint fast. All are open-license
   Google Fonts (SIL OFL). */
const montserrat = Montserrat({
  variable: "--font-montserrat",
  subsets: ["latin"],
  display: "swap",
  preload: false,
});
const poppins = Poppins({
  variable: "--font-poppins",
  subsets: ["latin"],
  weight: ["300", "400", "500", "600", "700", "800"],
  display: "swap",
  preload: false,
});
const playfair = Playfair_Display({
  variable: "--font-playfair",
  subsets: ["latin"],
  display: "swap",
  preload: false,
});
const lora = Lora({
  variable: "--font-lora",
  subsets: ["latin"],
  display: "swap",
  preload: false,
});
const bebas = Bebas_Neue({
  variable: "--font-bebas",
  subsets: ["latin"],
  weight: ["400"],
  display: "swap",
  preload: false,
});
const anton = Anton({
  variable: "--font-anton",
  subsets: ["latin"],
  weight: ["400"],
  display: "swap",
  preload: false,
});
const oswald = Oswald({
  variable: "--font-oswald",
  subsets: ["latin"],
  display: "swap",
  preload: false,
});
const dancingScript = Dancing_Script({
  variable: "--font-dancing-script",
  subsets: ["latin"],
  display: "swap",
  preload: false,
});
const caveat = Caveat({
  variable: "--font-caveat",
  subsets: ["latin"],
  display: "swap",
  preload: false,
});
const jetbrainsMono = JetBrains_Mono({
  variable: "--font-jetbrains-mono",
  subsets: ["latin"],
  display: "swap",
  preload: false,
});

const fontVariables = [
  inter.variable,
  spaceGrotesk.variable,
  montserrat.variable,
  poppins.variable,
  playfair.variable,
  lora.variable,
  bebas.variable,
  anton.variable,
  oswald.variable,
  dancingScript.variable,
  caveat.variable,
  jetbrainsMono.variable,
].join(" ");

const SITE_URL = process.env.APP_URL || "http://localhost:3000";

export const metadata: Metadata = {
  metadataBase: new URL(SITE_URL),
  title: {
    default: "Typography — Create Animated Text Videos in Minutes",
    template: "%s · Typography",
  },
  description:
    "Turn scripts, quotes, lyrics, and podcast clips into professional animated typography videos for Reels, TikTok, YouTube Shorts, and social media.",
  keywords: [
    "animated typography",
    "text video maker",
    "lyric video",
    "quote video",
    "Reels video editor",
    "TikTok text video",
    "YouTube Shorts",
  ],
  applicationName: "Typography",
  icons: { icon: "/favicon.svg", apple: "/favicon.svg" },
  openGraph: {
    title: "Typography — Create Animated Text Videos in Minutes",
    description:
      "Turn scripts, quotes, lyrics, and podcast clips into professional animated typography videos for Reels, TikTok, YouTube Shorts, and social media.",
    url: SITE_URL,
    siteName: "Typography",
    type: "website",
    images: [{ url: "/og.png", width: 1200, height: 630, alt: "Typography — animated text videos" }],
  },
  twitter: {
    card: "summary_large_image",
    title: "Typography — Create Animated Text Videos in Minutes",
    description:
      "Turn scripts, quotes, lyrics, and podcast clips into professional animated typography videos.",
    images: ["/og.png"],
  },
  robots: { index: true, follow: true },
};

export const viewport: Viewport = {
  themeColor: "#0a0a0c",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className={`${fontVariables} dark`} suppressHydrationWarning>
      <body className="font-sans antialiased bg-background text-foreground">
        <a
          href="#main-content"
          className="sr-only focus:not-sr-only focus:fixed focus:top-3 focus:left-3 focus:z-[100] focus:rounded-md focus:bg-primary focus:px-4 focus:py-2 focus:text-primary-foreground"
        >
          Skip to content
        </a>
        <AppProviders>
          {children}
          <Toaster />
        </AppProviders>
      </body>
    </html>
  );
}
