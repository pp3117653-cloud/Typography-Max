import { NextRequest, NextResponse } from 'next/server'
import { mkdir, writeFile } from 'fs/promises'
import path from 'path'
import { randomBytes } from 'crypto'
import { db } from '@/lib/db'
import { jsonError, requireUser, serverError } from '@/lib/server/api'
import { originAllowed } from '@/lib/server/auth'
import { clientKey, rateLimit } from '@/lib/server/rate-limit'

export const runtime = 'nodejs'

const UPLOAD_ROOT = path.join(process.cwd(), 'storage', 'uploads')

const AUDIO_TYPES = new Set(['audio/mpeg', 'audio/mp3', 'audio/wav', 'audio/x-wav', 'audio/wave'])
const IMAGE_TYPES = new Set(['image/png', 'image/jpeg', 'image/jpg', 'image/webp'])

const AUDIO_EXT: Record<string, string> = { 'audio/mpeg': 'mp3', 'audio/mp3': 'mp3', 'audio/wav': 'wav', 'audio/x-wav': 'wav', 'audio/wave': 'wav' }
const IMAGE_EXT: Record<string, string> = { 'image/png': 'png', 'image/jpeg': 'jpg', 'image/jpg': 'jpg', 'image/webp': 'webp' }

export async function POST(req: NextRequest) {
  if (!originAllowed(req)) return jsonError('Request blocked.', 403)
  const { user, res } = await requireUser(req)
  if (!user) return res

  const limit = rateLimit(clientKey(req, `upload:${user.id}`), 30, 60 * 60 * 1000)
  if (!limit.ok) {
    return NextResponse.json({ error: 'Too many uploads. Please wait a few minutes.' }, { status: 429 })
  }

  try {
    const form = await req.formData()
    const kind = String(form.get('kind') ?? '')
    const file = form.get('file')
    if (kind !== 'audio' && kind !== 'image') return jsonError('Invalid upload kind.')
    if (!(file instanceof File)) return jsonError('No file received.')

    const maxBytes = (Number(process.env.MAX_UPLOAD_MB) || 20) * 1024 * 1024
    if (file.size <= 0) return jsonError('The file is empty.')
    if (file.size > maxBytes) {
      return jsonError(`Files can be up to ${process.env.MAX_UPLOAD_MB || 20} MB. Yours is ${(file.size / 1024 / 1024).toFixed(1)} MB.`)
    }

    const mime = (file.type || '').toLowerCase()
    const extMap = kind === 'audio' ? AUDIO_EXT : IMAGE_EXT
    const allowedTypes = kind === 'audio' ? AUDIO_TYPES : IMAGE_TYPES
    const ext = extMap[mime]
    if (!allowedTypes.has(mime) || !ext) {
      return jsonError(
        kind === 'audio'
          ? 'Only MP3 and WAV audio files are supported.'
          : 'Only PNG, JPG and WebP images are supported.'
      )
    }

    // Basic magic-byte validation for the formats we accept.
    const head = Buffer.from(await file.slice(0, 16).arrayBuffer())
    const validMagic =
      kind === 'audio'
        ? isMp3(head) || isWav(head)
        : isPng(head) || isJpg(head) || isWebp(head)
    if (!validMagic) return jsonError('That file does not look like a valid ' + (kind === 'audio' ? 'MP3/WAV' : 'image') + '.')

    await mkdir(UPLOAD_ROOT, { recursive: true })
    const id = randomBytes(12).toString('hex')
    const storageName = `${id}.${ext}`
    const bytes = Buffer.from(await file.arrayBuffer())
    await writeFile(path.join(UPLOAD_ROOT, storageName), bytes)

    const record = await db.uploadFile.create({
      data: {
        id,
        userId: user.id,
        kind,
        fileName: file.name.slice(0, 180),
        mimeType: mime,
        sizeBytes: file.size,
        storagePath: storageName,
      },
    })

    return NextResponse.json({
      id: record.id,
      fileName: record.fileName,
      kind,
      sizeBytes: record.sizeBytes,
    })
  } catch (err) {
    return serverError('uploads/create', err)
  }
}

function isMp3(head: Buffer): boolean {
  // ID3 header or MP3 frame sync.
  return (head[0] === 0x49 && head[1] === 0x44 && head[2] === 0x33) || (head[0] === 0xff && (head[1] & 0xe0) === 0xe0)
}
function isWav(head: Buffer): boolean {
  return head.slice(0, 4).toString('ascii') === 'RIFF' && head.slice(8, 12).toString('ascii') === 'WAVE'
}
function isPng(head: Buffer): boolean {
  return head[0] === 0x89 && head[1] === 0x50 && head[2] === 0x4e && head[3] === 0x47
}
function isJpg(head: Buffer): boolean {
  return head[0] === 0xff && head[1] === 0xd8
}
function isWebp(head: Buffer): boolean {
  return head.slice(0, 4).toString('ascii') === 'RIFF' && head.slice(8, 12).toString('ascii') === 'WEBP'
}
