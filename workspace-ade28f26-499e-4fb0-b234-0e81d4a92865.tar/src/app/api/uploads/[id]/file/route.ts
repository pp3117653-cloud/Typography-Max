import { NextRequest, NextResponse } from 'next/server'
import { createReadStream } from 'fs'
import { stat } from 'fs/promises'
import path from 'path'
import { Readable } from 'stream'
import { db } from '@/lib/db'
import { jsonError, requireUser, serverError } from '@/lib/server/api'

export const runtime = 'nodejs'

const UPLOAD_ROOT = path.join(process.cwd(), 'storage', 'uploads')

export async function GET(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { user, res } = await requireUser(req)
  if (!user) return res
  try {
    const { id } = await params
    const record = await db.uploadFile.findFirst({ where: { id, userId: user.id } })
    if (!record) return jsonError('File not found.', 404)

    const filePath = path.join(UPLOAD_ROOT, record.storagePath)
    const info = await stat(filePath).catch(() => null)
    if (!info) return jsonError('File is no longer available.', 404)

    const stream = Readable.toWeb(createReadStream(filePath)) as ReadableStream
    return new NextResponse(stream, {
      headers: {
        'Content-Type': record.mimeType,
        'Content-Length': String(info.size),
        'Cache-Control': 'private, max-age=3600',
      },
    })
  } catch (err) {
    return serverError('uploads/serve', err)
  }
}

export async function DELETE(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { user, res } = await requireUser(req)
  if (!user) return res
  try {
    const { id } = await params
    const record = await db.uploadFile.findFirst({ where: { id, userId: user.id } })
    if (!record) return jsonError('File not found.', 404)
    await db.uploadFile.delete({ where: { id } })
    const { unlink } = await import('fs/promises')
    await unlink(path.join(UPLOAD_ROOT, record.storagePath)).catch(() => {})
    return NextResponse.json({ ok: true })
  } catch (err) {
    return serverError('uploads/delete', err)
  }
}
