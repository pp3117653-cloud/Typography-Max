import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireUser, serverError } from '@/lib/server/api'
import { getPlan } from '@/lib/typography/plans'

export const runtime = 'nodejs'

export async function GET(req: NextRequest) {
  const { user, res } = await requireUser(req)
  if (!user) return res
  try {
    const plan = getPlan(user.plan)

    const monthStart = new Date()
    monthStart.setUTCDate(1)
    monthStart.setUTCHours(0, 0, 0, 0)
    const nextMonth = new Date(monthStart)
    nextMonth.setUTCMonth(nextMonth.getUTCMonth() + 1)

    const [exportsUsed, projectsUsed] = await Promise.all([
      db.exportJob.count({
        where: { userId: user.id, createdAt: { gte: monthStart }, status: { not: 'failed' } },
      }),
      db.project.count({ where: { userId: user.id } }),
    ])

    return NextResponse.json({
      plan: user.plan,
      exportsUsed,
      exportsLimit: plan.exportsPerMonth,
      projectsUsed,
      projectsLimit: plan.maxProjects,
      periodLabel: monthStart.toLocaleString('en-IN', { month: 'long', timeZone: 'UTC' }),
      resetsAt: nextMonth.toISOString(),
    })
  } catch (err) {
    return serverError('usage', err)
  }
}
