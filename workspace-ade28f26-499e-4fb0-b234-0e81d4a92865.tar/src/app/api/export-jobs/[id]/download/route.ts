import { NextRequest, NextResponse } from 'next/server'
import { createReadStream } from 'fs'
import { stat } from 'fs/promises'
import path from 'path'
import { Readable } from 'stream'
import { db } from '@/lib/db'
import { jsonError, requireUser, serverError } from '@/lib/server/api'

export const runtime = 'nodejs'

const EXPORT_ROOT = path.join(process.cwd(), 'storage', 'exports')

export async function GET(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { user, res } = await requireUser(req)
  if (!user) return res
  try {
    const { id } = await params
    const job = await db.exportJob.findFirst({ where: { id, userId: user.id } })
    if (!job) return jsonError('Export not found.', 404)
    if (job.status === 'expired' || !job.filePath) {
      return jsonError('This export file is no longer available (files are kept for 7 days). Re-export from the editor.', 410)
    }
    if (job.status !== 'completed') return jsonError('This export has not finished yet.', 409)

    const filePath = path.join(EXPORT_ROOT, job.filePath)
    const info = await stat(filePath).catch(() => null)
    if (!info) return jsonError('This export file is no longer available. Re-export from the editor.', 410)

    const safeName = `${job.projectName.replace(/[^a-z0-9\-_ ]/gi, '').trim() || 'typography-video'}.mp4`
    const stream = Readable.toWeb(createReadStream(filePath)) as ReadableStream
    return new NextResponse(stream, {
      headers: {
        'Content-Type': 'video/mp4',
        'Content-Length': String(info.size),
        'Content-Disposition': `attachment; filename="${safeName}"`,
      },
    })
  } catch (err) {
    return serverError('exports/download', err)
  }
}
