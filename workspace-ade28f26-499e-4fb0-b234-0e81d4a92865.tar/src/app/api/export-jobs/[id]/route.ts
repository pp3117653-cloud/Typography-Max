import { NextRequest, NextResponse } from 'next/server'
import { z } from 'zod'
import { db } from '@/lib/db'
import { jsonError, requireUser, serverError } from '@/lib/server/api'
import { originAllowed } from '@/lib/server/auth'

export const runtime = 'nodejs'

const patchSchema = z.object({
  progress: z.number().int().min(0).max(100).optional(),
  status: z.enum(['failed']).optional(),
  error: z.string().max(500).optional(),
})

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  if (!originAllowed(req)) return jsonError('Request blocked.', 403)
  const { user, res } = await requireUser(req)
  if (!user) return res
  try {
    const { id } = await params
    const job = await db.exportJob.findFirst({ where: { id, userId: user.id } })
    if (!job) return jsonError('Export job not found.', 404)
    if (job.status !== 'processing') return jsonError('This export job can no longer be updated.')

    const body = await req.json().catch(() => null)
    const parsed = patchSchema.safeParse(body)
    if (!parsed.success) return jsonError(parsed.error.issues[0]?.message ?? 'Invalid input.')

    await db.exportJob.update({
      where: { id },
      data: {
        progress: parsed.data.progress ?? undefined,
        status: parsed.data.status ?? undefined,
        error: parsed.data.status === 'failed' ? parsed.data.error ?? 'Export failed.' : undefined,
      },
    })
    return NextResponse.json({ ok: true })
  } catch (err) {
    return serverError('exports/patch', err)
  }
}

export async function DELETE(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  if (!originAllowed(req)) return jsonError('Request blocked.', 403)
  const { user, res } = await requireUser(req)
  if (!user) return res
  try {
    const { id } = await params
    const job = await db.exportJob.findFirst({ where: { id, userId: user.id } })
    if (!job) return jsonError('Export job not found.', 404)

    if (job.filePath) {
      const { unlink } = await import('fs/promises')
      const path = await import('path')
      await unlink(path.join(process.cwd(), 'storage', 'exports', job.filePath)).catch(() => {})
    }
    await db.exportJob.delete({ where: { id } })
    return NextResponse.json({ ok: true })
  } catch (err) {
    return serverError('exports/delete', err)
  }
}
