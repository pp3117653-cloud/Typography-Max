import { NextRequest, NextResponse } from 'next/server'
import { z } from 'zod'
import { db } from '@/lib/db'
import { jsonError, requireUser, serverError } from '@/lib/server/api'
import { originAllowed } from '@/lib/server/auth'
import { getPlan, resolutionAllowed } from '@/lib/typography/plans'

export const runtime = 'nodejs'

const createSchema = z.object({
  projectId: z.string().trim().min(1).max(64).nullable().optional(),
  projectName: z.string().trim().min(1, 'Project name is required.').max(120),
  resolution: z.enum(['720', '1080', '2160']),
})

export async function GET(req: NextRequest) {
  const { user, res } = await requireUser(req)
  if (!user) return res
  try {
    await sweepStaleJobs()
    const jobs = await db.exportJob.findMany({
      where: { userId: user.id },
      orderBy: { createdAt: 'desc' },
      take: 100,
    })
    return NextResponse.json({
      jobs: jobs.map((j) => ({
        id: j.id,
        projectId: j.projectId,
        projectName: j.projectName,
        status: j.status,
        progress: j.progress,
        resolution: j.resolution,
        format: j.format,
        watermark: j.watermark,
        durationSec: j.durationSec,
        fileSizeBytes: j.fileSizeBytes,
        error: j.error,
        createdAt: j.createdAt.toISOString(),
        completedAt: j.completedAt?.toISOString() ?? null,
      })),
    })
  } catch (err) {
    return serverError('exports/list', err)
  }
}

export async function POST(req: NextRequest) {
  if (!originAllowed(req)) return jsonError('Request blocked.', 403)
  const { user, res } = await requireUser(req)
  if (!user) return res
  try {
    const body = await req.json().catch(() => null)
    const parsed = createSchema.safeParse(body)
    if (!parsed.success) return jsonError(parsed.error.issues[0]?.message ?? 'Invalid input.')
    const { projectId, projectName, resolution } = parsed.data

    const plan = getPlan(user.plan)
    if (!resolutionAllowed(user.plan, resolution)) {
      return NextResponse.json(
        {
          error: `${resolution === '2160' ? '4K' : '1080p HD'} export is not included in the ${plan.name} plan. Upgrade to unlock higher resolutions.`,
          code: 'RESOLUTION_LOCKED',
        },
        { status: 402 }
      )
    }

    const monthStart = new Date()
    monthStart.setUTCDate(1)
    monthStart.setUTCHours(0, 0, 0, 0)
    const usedThisMonth = await db.exportJob.count({
      where: { userId: user.id, createdAt: { gte: monthStart }, status: { not: 'failed' } },
    })
    if (usedThisMonth >= plan.exportsPerMonth) {
      return NextResponse.json(
        {
          error: `You've used all ${plan.exportsPerMonth} exports included in the ${plan.name} plan this month. Upgrade for more exports.`,
          code: 'EXPORT_LIMIT',
        },
        { status: 402 }
      )
    }

    if (projectId) {
      const project = await db.project.findFirst({ where: { id: projectId, userId: user.id } })
      if (!project) return jsonError('Project not found.', 404)
    }

    const job = await db.exportJob.create({
      data: {
        userId: user.id,
        projectId: projectId ?? null,
        projectName,
        resolution,
        format: 'mp4',
        watermark: plan.watermark,
        status: 'processing',
        progress: 0,
      },
    })

    return NextResponse.json({
      job: {
        id: job.id,
        projectId: job.projectId,
        projectName: job.projectName,
        status: job.status,
        progress: job.progress,
        resolution: job.resolution,
        format: job.format,
        watermark: job.watermark,
        durationSec: job.durationSec,
        fileSizeBytes: job.fileSizeBytes,
        error: job.error,
        createdAt: job.createdAt.toISOString(),
        completedAt: job.completedAt?.toISOString() ?? null,
      },
    })
  } catch (err) {
    return serverError('exports/create', err)
  }
}

/**
 * Housekeeping: mark jobs that never finished as failed and remove files that
 * passed their retention window. Runs at most once per hour per instance.
 */
let lastSweep = 0
async function sweepStaleJobs(): Promise<void> {
  const now = Date.now()
  if (now - lastSweep < 60 * 60 * 1000) return
  lastSweep = now
  try {
    const staleCutoff = new Date(now - 2 * 60 * 60 * 1000)
    await db.exportJob.updateMany({
      where: { status: 'processing', createdAt: { lt: staleCutoff } },
      data: { status: 'failed', error: 'Export did not finish (the browser tab may have been closed).' },
    })

    const ttlDays = Number(process.env.EXPORT_TTL_DAYS) || 7
    const ttlCutoff = new Date(now - ttlDays * 24 * 60 * 60 * 1000)
    const expired = await db.exportJob.findMany({
      where: { status: 'completed', createdAt: { lt: ttlCutoff }, filePath: { not: null } },
      select: { id: true, filePath: true },
      take: 200,
    })
    if (expired.length > 0) {
      const { unlink } = await import('fs/promises')
      const path = await import('path')
      for (const job of expired) {
        if (job.filePath) {
          await unlink(path.join(process.cwd(), 'storage', 'exports', job.filePath)).catch(() => {})
        }
      }
      await db.exportJob.updateMany({
        where: { id: { in: expired.map((j) => j.id) } },
        data: { filePath: null, status: 'expired' },
      })
    }
  } catch (err) {
    console.error('[exports/sweep]', err instanceof Error ? err.message : err)
  }
}
