import { NextRequest, NextResponse } from 'next/server'
import { z } from 'zod'
import { db } from '@/lib/db'
import { jsonError, requireUser, serverError } from '@/lib/server/api'
import { originAllowed } from '@/lib/server/auth'
import { getPlan } from '@/lib/typography/plans'
import { normalizeProject, defaultProject } from '@/lib/typography/defaults'
import { totalDuration } from '@/lib/typography/render-frame'

export const runtime = 'nodejs'

const createSchema = z.object({
  name: z.string().trim().min(1, 'Give your project a name.').max(120),
  data: z.unknown().optional(),
})

export async function GET(req: NextRequest) {
  const { user, res } = await requireUser(req)
  if (!user) return res
  try {
    const projects = await db.project.findMany({
      where: { userId: user.id },
      orderBy: { updatedAt: 'desc' },
      take: 100,
    })
    return NextResponse.json({
      projects: projects.map((p) => {
        const data = normalizeProject(safeParse(p.data))
        return {
          id: p.id,
          name: p.name,
          templateId: p.templateId,
          createdAt: p.createdAt.toISOString(),
          updatedAt: p.updatedAt.toISOString(),
          sceneCount: data.scenes.length,
          durationSec: Number(totalDuration(data).toFixed(1)),
          format: data.format,
          data,
        }
      }),
    })
  } catch (err) {
    return serverError('projects/list', err)
  }
}

export async function POST(req: NextRequest) {
  if (!originAllowed(req)) return jsonError('Request blocked.', 403)
  const { user, res } = await requireUser(req)
  if (!user) return res
  try {
    const body = await req.json().catch(() => null)
    const parsed = createSchema.safeParse(body)
    if (!parsed.success) return jsonError(parsed.error.issues[0]?.message ?? 'Invalid input.')

    const plan = getPlan(user.plan)
    const count = await db.project.count({ where: { userId: user.id } })
    if (count >= plan.maxProjects) {
      return NextResponse.json(
        {
          error: `Your ${plan.name} plan holds up to ${plan.maxProjects} saved projects. Delete an old project or upgrade to save more.`,
          code: 'PROJECT_LIMIT',
        },
        { status: 402 }
      )
    }

    const data = body && typeof body === 'object' && 'data' in body ? body.data : undefined
    const project = await db.project.create({
      data: {
        userId: user.id,
        name: parsed.data.name,
        data: JSON.stringify(data !== undefined ? normalizeProject(data) : defaultProject()),
        templateId: typeof data === 'object' && data && 'templateId' in data && typeof (data as { templateId: unknown }).templateId === 'string'
          ? (data as { templateId: string }).templateId
          : null,
      },
    })
    return NextResponse.json({ id: project.id })
  } catch (err) {
    return serverError('projects/create', err)
  }
}

function safeParse(value: string): unknown {
  try {
    return JSON.parse(value)
  } catch {
    return null
  }
}
