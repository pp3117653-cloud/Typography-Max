import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { jsonError, requireUser, serverError } from '@/lib/server/api'
import { originAllowed } from '@/lib/server/auth'
import { getPlan } from '@/lib/typography/plans'

export const runtime = 'nodejs'

export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  if (!originAllowed(req)) return jsonError('Request blocked.', 403)
  const { user, res } = await requireUser(req)
  if (!user) return res
  try {
    const { id } = await params
    const source = await db.project.findFirst({ where: { id, userId: user.id } })
    if (!source) return jsonError('Project not found.', 404)

    const plan = getPlan(user.plan)
    const count = await db.project.count({ where: { userId: user.id } })
    if (count >= plan.maxProjects) {
      return NextResponse.json(
        {
          error: `Your ${plan.name} plan holds up to ${plan.maxProjects} saved projects. Delete an old project or upgrade to duplicate.`,
          code: 'PROJECT_LIMIT',
        },
        { status: 402 }
      )
    }

    const copy = await db.project.create({
      data: {
        userId: user.id,
        name: `${source.name} (copy)`.slice(0, 120),
        data: source.data,
        templateId: source.templateId,
      },
    })
    return NextResponse.json({ id: copy.id })
  } catch (err) {
    return serverError('projects/duplicate', err)
  }
}
