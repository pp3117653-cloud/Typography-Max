import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { jsonError, requireUser, serverError } from '@/lib/server/api'
import { originAllowed } from '@/lib/server/auth'
import { normalizeProject } from '@/lib/typography/defaults'
import { totalDuration } from '@/lib/typography/render-frame'

export const runtime = 'nodejs'

type Params = { params: Promise<{ id: string }> }

function parseData(value: string): unknown {
  try {
    return JSON.parse(value)
  } catch {
    return null
  }
}

export async function GET(req: NextRequest, { params }: Params) {
  const { user, res } = await requireUser(req)
  if (!user) return res
  try {
    const { id } = await params
    const project = await db.project.findFirst({ where: { id, userId: user.id } })
    if (!project) return jsonError('Project not found.', 404)
    const data = normalizeProject(parseData(project.data))
    return NextResponse.json({
      project: {
        id: project.id,
        name: project.name,
        templateId: project.templateId,
        createdAt: project.createdAt.toISOString(),
        updatedAt: project.updatedAt.toISOString(),
        sceneCount: data.scenes.length,
        durationSec: Number(totalDuration(data).toFixed(1)),
        format: data.format,
        data,
      },
    })
  } catch (err) {
    return serverError('projects/get', err)
  }
}

export async function PATCH(req: NextRequest, { params }: Params) {
  if (!originAllowed(req)) return jsonError('Request blocked.', 403)
  const { user, res } = await requireUser(req)
  if (!user) return res
  try {
    const { id } = await params
    const body = (await req.json().catch(() => null)) as
      | { name?: unknown; data?: unknown }
      | null
    if (!body) return jsonError('Invalid request body.')

    const existing = await db.project.findFirst({ where: { id, userId: user.id } })
    if (!existing) return jsonError('Project not found.', 404)

    const update: { name?: string; data?: string; templateId?: string | null } = {}
    if (typeof body.name === 'string' && body.name.trim()) {
      update.name = body.name.trim().slice(0, 120)
    }
    if (body.data !== undefined) {
      const normalized = normalizeProject(body.data)
      update.data = JSON.stringify(normalized)
      update.templateId = normalized.templateId
    }
    if (Object.keys(update).length === 0) return jsonError('Nothing to update.')

    await db.project.update({ where: { id }, data: update })
    return NextResponse.json({ ok: true })
  } catch (err) {
    return serverError('projects/update', err)
  }
}

export async function DELETE(req: NextRequest, { params }: Params) {
  if (!originAllowed(req)) return jsonError('Request blocked.', 403)
  const { user, res } = await requireUser(req)
  if (!user) return res
  try {
    const { id } = await params
    const existing = await db.project.findFirst({ where: { id, userId: user.id } })
    if (!existing) return jsonError('Project not found.', 404)
    await db.project.delete({ where: { id } })
    return NextResponse.json({ ok: true })
  } catch (err) {
    return serverError('projects/delete', err)
  }
}
