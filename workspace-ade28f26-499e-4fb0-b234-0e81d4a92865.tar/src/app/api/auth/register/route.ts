import { NextRequest, NextResponse } from 'next/server'
import { z } from 'zod'
import { db } from '@/lib/db'
import { hashPassword, originAllowed, sessionCookieSet } from '@/lib/server/auth'
import { clientKey, rateLimit } from '@/lib/server/rate-limit'

const registerSchema = z.object({
  name: z.string().trim().min(1, 'Please enter your name.').max(80).optional(),
  email: z.string().trim().toLowerCase().email('Please enter a valid email address.'),
  password: z.string().min(8, 'Password must be at least 8 characters.').max(200),
})

export async function POST(req: NextRequest) {
  if (!originAllowed(req)) {
    return NextResponse.json({ error: 'Request blocked.' }, { status: 403 })
  }
  const limit = rateLimit(clientKey(req, 'register'), 10, 10 * 60 * 1000)
  if (!limit.ok) {
    return NextResponse.json(
      { error: `Too many attempts. Try again in ${limit.retryAfterSec}s.` },
      { status: 429 }
    )
  }

  let body: unknown
  try {
    body = await req.json()
  } catch {
    return NextResponse.json({ error: 'Invalid request body.' }, { status: 400 })
  }
  const parsed = registerSchema.safeParse(body)
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.issues[0]?.message ?? 'Invalid input.' }, { status: 400 })
  }
  const { name, email, password } = parsed.data

  const existing = await db.user.findUnique({ where: { email } })
  if (existing) {
    return NextResponse.json(
      { error: 'An account with this email already exists. Try logging in instead.' },
      { status: 409 }
    )
  }

  let user
  try {
    user = await db.user.create({
      data: { email, name: name ?? null, passwordHash: hashPassword(password) },
    })
  } catch (err) {
    // Unique-constraint race (same email registered concurrently).
    if (typeof err === 'object' && err !== null && 'code' in err && (err as { code?: string }).code === 'P2002') {
      return NextResponse.json(
        { error: 'An account with this email already exists. Try logging in instead.' },
        { status: 409 }
      )
    }
    console.error('Registration failed:', err)
    return NextResponse.json({ error: 'Could not create your account. Please try again.' }, { status: 500 })
  }

  // If cookie signing fails (e.g. misconfigured AUTH_SECRET), remove the user
  // again so a retry does not hit "email already exists" with no way in.
  let res: NextResponse
  try {
    res = NextResponse.json({
      user: {
        id: user.id,
        email: user.email,
        name: user.name,
        plan: user.plan,
        createdAt: user.createdAt.toISOString(),
      },
    })
    return sessionCookieSet(res, user.id, user.tokenVersion)
  } catch (err) {
    await db.user.delete({ where: { id: user.id } }).catch(() => undefined)
    console.error('Registration failed while creating the session:', err)
    return NextResponse.json(
      { error: 'Could not create your session. Please contact support if this keeps happening.' },
      { status: 500 }
    )
  }
}
