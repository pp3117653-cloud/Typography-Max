import { NextRequest, NextResponse } from 'next/server'
import { originAllowed, sessionCookieClear } from '@/lib/server/auth'

export async function POST(req: NextRequest) {
  if (!originAllowed(req)) {
    return NextResponse.json({ error: 'Request blocked.' }, { status: 403 })
  }
  return sessionCookieClear(NextResponse.json({ ok: true }))
}
