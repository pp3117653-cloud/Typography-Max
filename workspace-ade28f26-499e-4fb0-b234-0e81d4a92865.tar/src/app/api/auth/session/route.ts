import { NextRequest, NextResponse } from 'next/server'
import { getSessionUser } from '@/lib/server/auth'

export async function GET(req: NextRequest) {
  try {
    const user = await getSessionUser(req)
    return NextResponse.json({ user })
  } catch (err) {
    console.error('[auth/session] failed:', err instanceof Error ? err.message : err)
    return NextResponse.json({ error: 'Could not load session.' }, { status: 500 })
  }
}
