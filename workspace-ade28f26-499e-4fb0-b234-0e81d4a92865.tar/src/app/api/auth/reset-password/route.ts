import { NextRequest, NextResponse } from 'next/server'
import { z } from 'zod'
import { db } from '@/lib/db'
import { hashPassword, hashResetToken, originAllowed, sessionCookieSet } from '@/lib/server/auth'
import { clientKey, rateLimit } from '@/lib/server/rate-limit'

const schema = z.object({
  token: z.string().min(10, 'Invalid reset link.'),
  password: z.string().min(8, 'Password must be at least 8 characters.').max(200),
})

export async function POST(req: NextRequest) {
  if (!originAllowed(req)) {
    return NextResponse.json({ error: 'Request blocked.' }, { status: 403 })
  }
  const limit = rateLimit(clientKey(req, 'reset'), 10, 15 * 60 * 1000)
  if (!limit.ok) {
    return NextResponse.json(
      { error: `Too many attempts. Try again in ${limit.retryAfterSec}s.` },
      { status: 429 }
    )
  }

  let body: unknown
  try {
    body = await req.json()
  } catch {
    return NextResponse.json({ error: 'Invalid request body.' }, { status: 400 })
  }
  const parsed = schema.safeParse(body)
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.issues[0]?.message ?? 'Invalid input.' }, { status: 400 })
  }
  const { token, password } = parsed.data

  const tokenHash = hashResetToken(token)
  const record = await db.passwordResetToken.findUnique({ where: { tokenHash } })

  if (!record || record.usedAt || record.expiresAt < new Date()) {
    return NextResponse.json(
      { error: 'This reset link is invalid or has expired. Please request a new one.' },
      { status: 400 }
    )
  }

  const user = await db.user.update({
    where: { id: record.userId },
    data: { passwordHash: hashPassword(password), tokenVersion: { increment: 1 } },
  })
  await db.passwordResetToken.update({ where: { id: record.id }, data: { usedAt: new Date() } })

  const res = NextResponse.json({
    user: {
      id: user.id,
      email: user.email,
      name: user.name,
      plan: user.plan,
      createdAt: user.createdAt.toISOString(),
    },
  })
  return sessionCookieSet(res, user.id, user.tokenVersion)
}
