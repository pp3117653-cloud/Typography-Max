import { NextRequest, NextResponse } from 'next/server'
import { z } from 'zod'
import { db } from '@/lib/db'
import { createResetToken, originAllowed } from '@/lib/server/auth'
import { clientKey, rateLimit } from '@/lib/server/rate-limit'

const schema = z.object({
  email: z.string().trim().toLowerCase().email('Please enter a valid email address.'),
})

export async function POST(req: NextRequest) {
  if (!originAllowed(req)) {
    return NextResponse.json({ error: 'Request blocked.' }, { status: 403 })
  }
  const limit = rateLimit(clientKey(req, 'forgot'), 8, 15 * 60 * 1000)
  if (!limit.ok) {
    return NextResponse.json(
      { error: `Too many attempts. Try again in ${limit.retryAfterSec}s.` },
      { status: 429 }
    )
  }

  let body: unknown
  try {
    body = await req.json()
  } catch {
    return NextResponse.json({ error: 'Invalid request body.' }, { status: 400 })
  }
  const parsed = schema.safeParse(body)
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.issues[0]?.message ?? 'Invalid input.' }, { status: 400 })
  }
  const { email } = parsed.data

  const user = await db.user.findUnique({ where: { email } })

  // Always respond with the same generic message so we never reveal whether
  // an email is registered.
  const generic = {
    ok: true,
    message: 'If an account exists for that email, a reset link has been created.',
  }

  if (!user) return NextResponse.json(generic)

  const { token, tokenHash } = createResetToken()
  await db.passwordResetToken.create({
    data: {
      tokenHash,
      userId: user.id,
      expiresAt: new Date(Date.now() + 60 * 60 * 1000),
    },
  })

  const base = process.env.APP_URL || 'http://localhost:3000'
  const resetUrl = `${base}/#/reset-password?token=${token}`

  // Email delivery is not configured in this deployment. In development we
  // return the link directly (clearly labeled) so the flow is testable;
  // in production an SMTP provider must be connected (see .env.example).
  if (process.env.NODE_ENV !== 'production') {
    console.log(`[auth] password reset link for ${email}: ${resetUrl}`)
    return NextResponse.json({ ...generic, devResetUrl: resetUrl })
  }
  // Production without email: the token is stored, but there is no way to
  // deliver it — surface an honest error instead of pretending it was sent.
  console.error('[auth] password reset requested but email delivery is not configured')
  return NextResponse.json({
    ...generic,
    message:
      'Email delivery is not configured on this server, so the reset link could not be sent. Please contact support.',
  })
}
