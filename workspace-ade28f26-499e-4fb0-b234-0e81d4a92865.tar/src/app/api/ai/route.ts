import { NextRequest, NextResponse } from 'next/server'
import { z } from 'zod'
import { jsonError, requireUser, serverError } from '@/lib/server/api'
import { originAllowed } from '@/lib/server/auth'
import { clientKey, rateLimit } from '@/lib/server/rate-limit'
import { getPlan } from '@/lib/typography/plans'

export const runtime = 'nodejs'
export const maxDuration = 60

const bodySchema = z.object({
  tool: z.enum([
    'split-script',
    'hook',
    'rewrite-platform',
    'titles',
    'style-suggest',
    'quote-variants',
    'storyboard',
  ]),
  input: z.string().trim().min(3, 'Add some text first.').max(6000),
  platform: z.enum(['tiktok', 'reels', 'shorts']).optional(),
})

interface ToolSpec {
  system: string
  buildUser: (input: string, platform?: string) => string
  json?: boolean
}

const TOOLS: Record<string, ToolSpec> = {
  'split-script': {
    system:
      'You are a short-form video editor. You split scripts into punchy text-video scenes. Respond with valid JSON only: {"scenes":[{"text":"..."}]}. Each scene is 2-14 words, spoken style, preserves the original meaning. Never invent new claims.',
    buildUser: (input) =>
      `Split this script into scenes for an animated typography video. Keep the author\'s words — trim filler, keep the voice. 3-8 scenes depending on length:\n\n${input}`,
    json: true,
  },
  hook: {
    system:
      'You are a short-form content strategist. You rewrite opening lines into scroll-stopping hooks. Respond with valid JSON only: {"hooks":["...","...","..."]}. Exactly 3 hooks, each under 12 words, no clickbait lies, no emojis.',
    buildUser: (input) => `Suggest 3 stronger hooks for this video script:\n\n${input}`,
    json: true,
  },
  'rewrite-platform': {
    system:
      'You are a social media copywriter. You adapt scripts for vertical video platforms: short lines, strong rhythm, natural spoken language. Respond with valid JSON only: {"lines":["...","..."]} where each line is one on-screen beat.',
    buildUser: (input, platform) =>
      `Rewrite this for ${platform ?? 'tiktok'} — fast pace, 5-9 short beats, keep the core message:\n\n${input}`,
    json: true,
  },
  titles: {
    system:
      'You are a social media SEO specialist. Respond with valid JSON only: {"title":"...","caption":"...","hashtags":["#..."]}. Title under 60 chars, caption 1-2 sentences, 4-6 relevant hashtags.',
    buildUser: (input) => `Suggest a title, caption and hashtags for this video:\n\n${input}`,
    json: true,
  },
  'style-suggest': {
    system:
      'You are a typography art director. You recommend a design style based on text tone. Available fonts: inter (clean sans), space-grotesk (modern), montserrat (geometric), poppins (friendly), playfair (elegant serif), lora (bookish serif), bebas (condensed display), anton (heavy display), oswald (strong condensed), dancing-script (script), caveat (handwritten), jetbrains-mono (mono). Animations: fade, slideUp, slideLeft, slideRight, scaleIn, typewriter, wordReveal, letterReveal, bounce, highlightWord. Respond with valid JSON only: {"fontId":"...","fontWeight":700,"animationPreset":"...","mood":"one sentence explaining the choice","palette":{"textColor":"#FFFFFF","highlightColor":"#FF5A1F","backgroundFrom":"#17171C","backgroundTo":"#0A0A0D"}} using real hex colors.',
    buildUser: (input) => `Suggest a typography style for this text:\n\n${input}`,
    json: true,
  },
  'quote-variants': {
    system:
      'You are a quote editor. Respond with valid JSON only: {"variants":["...","...","..."]}. Exactly 3 tighter variations of the given quote, each under 18 words, keeping the original meaning and voice.',
    buildUser: (input) => `Write 3 shorter variations of this quote:\n\n${input}`,
    json: true,
  },
  storyboard: {
    system:
      'You are a video storyboard artist for text-animation videos. Respond with valid JSON only: {"scenes":[{"text":"...","visualNote":"one short note about pacing/emphasis"}]}. 4-8 scenes telling the input as a sequence. visualNote max 10 words.',
    buildUser: (input) => `Create a scene-by-scene storyboard for:\n\n${input}`,
    json: true,
  },
}

export async function POST(req: NextRequest) {
  if (!originAllowed(req)) return jsonError('Request blocked.', 403)
  const { user, res } = await requireUser(req)
  if (!user) return res

  const plan = getPlan(user.plan)
  const dailyLimit = plan.id === 'FREE' ? 15 : 60
  const limit = rateLimit(clientKey(req, `ai:${user.id}`), dailyLimit, 24 * 60 * 60 * 1000)
  if (!limit.ok) {
    return NextResponse.json(
      { error: `You've reached today's ${dailyLimit} AI suggestions (${plan.name} plan). They reset tomorrow.` },
      { status: 429 }
    )
  }

  try {
    const body = await req.json().catch(() => null)
    const parsed = bodySchema.safeParse(body)
    if (!parsed.success) return jsonError(parsed.error.issues[0]?.message ?? 'Invalid input.')

    const tool = TOOLS[parsed.data.tool]
    const userPrompt = tool.buildUser(parsed.data.input, parsed.data.platform)

    let content: string | null = null
    try {
      const { default: ZAI } = await import('z-ai-web-dev-sdk')
      const zai = await ZAI.create()
      const completion = await zai.chat.completions.create({
        messages: [
          { role: 'assistant', content: tool.system },
          { role: 'user', content: userPrompt },
        ],
        thinking: { type: 'disabled' },
      })
      content = completion.choices[0]?.message?.content ?? null
    } catch (err) {
      console.error('[ai] SDK call failed:', err instanceof Error ? err.message : err)
      return NextResponse.json(
        { error: 'The AI service is not available right now. Please try again in a moment.' },
        { status: 503 }
      )
    }

    if (!content || !content.trim()) {
      return NextResponse.json({ error: 'The AI returned an empty response. Please try again.' }, { status: 502 })
    }

    if (!tool.json) {
      return NextResponse.json({ text: content })
    }

    // Extract JSON defensively (models sometimes wrap in fences).
    const jsonText = extractJson(content)
    if (!jsonText) {
      return NextResponse.json({ error: 'Could not parse the AI response. Please retry.' }, { status: 502 })
    }
    return NextResponse.json({ data: jsonText, text: content })
  } catch (err) {
    return serverError('ai', err)
  }
}

function extractJson(content: string): unknown {
  const trimmed = content.trim()
  const attempts = [trimmed]
  const fence = trimmed.match(/```(?:json)?\s*([\s\S]*?)```/)
  if (fence) attempts.push(fence[1].trim())
  const firstBrace = trimmed.indexOf('{')
  const lastBrace = trimmed.lastIndexOf('}')
  if (firstBrace >= 0 && lastBrace > firstBrace) attempts.push(trimmed.slice(firstBrace, lastBrace + 1))

  for (const attempt of attempts) {
    try {
      return JSON.parse(attempt)
    } catch {
      // try next
    }
  }
  return null
}
