import { NextRequest, NextResponse } from 'next/server'
import { z } from 'zod'
import { db } from '@/lib/db'
import { jsonError, requireUser, serverError } from '@/lib/server/api'
import { originAllowed } from '@/lib/server/auth'

export const runtime = 'nodejs'

const PLAN_PRICE_ENV: Record<string, string | undefined> = {
  CREATOR: process.env.STRIPE_PRICE_CREATOR,
  PRO: process.env.STRIPE_PRICE_PRO,
  AGENCY: process.env.STRIPE_PRICE_AGENCY,
}

const checkoutSchema = z.object({
  plan: z.enum(['CREATOR', 'PRO', 'AGENCY']),
})

export async function GET() {
  const secret = process.env.STRIPE_SECRET_KEY
  const pricesReady = Boolean(
    process.env.STRIPE_PRICE_CREATOR && process.env.STRIPE_PRICE_PRO && process.env.STRIPE_PRICE_AGENCY
  )
  return NextResponse.json({
    configured: Boolean(secret && pricesReady),
    reason: !secret
      ? 'STRIPE_SECRET_KEY is not set on this server.'
      : !pricesReady
        ? 'Stripe price IDs are not fully configured (STRIPE_PRICE_CREATOR / PRO / AGENCY).'
        : null,
    devPlanSwitchEnabled:
      process.env.DEV_PLAN_SWITCH === 'true' && process.env.NODE_ENV !== 'production',
  })
}

export async function POST(req: NextRequest) {
  if (!originAllowed(req)) return jsonError('Request blocked.', 403)
  const { user, res } = await requireUser(req)
  if (!user) return res
  try {
    const body = await req.json().catch(() => null)
    const parsed = checkoutSchema.safeParse(body)
    if (!parsed.success) return jsonError('Invalid plan selection.')

    const { plan } = parsed.data
    const secret = process.env.STRIPE_SECRET_KEY
    const priceId = PLAN_PRICE_ENV[plan]

    if (!secret || !priceId) {
      return NextResponse.json(
        {
          error:
            'Payment setup required: Stripe is not configured on this server. Set STRIPE_SECRET_KEY and the STRIPE_PRICE_* variables (see .env.example) to enable checkout.',
          code: 'PAYMENT_NOT_CONFIGURED',
        },
        { status: 501 }
      )
    }

    const origin = process.env.APP_URL || 'http://localhost:3000'
    // Stripe Checkout Session via the REST API — no extra SDK dependency.
    const params = new URLSearchParams()
    params.set('mode', 'subscription')
    params.set('success_url', `${origin}/#/billing?checkout=success`)
    params.set('cancel_url', `${origin}/#/billing?checkout=cancelled`)
    params.set('customer_email', user.email)
    params.set('line_items[0][price]', priceId)
    params.set('line_items[0][quantity]', '1')
    params.set('client_reference_id', user.id)
    params.set('metadata[userId]', user.id)
    params.set('metadata[plan]', plan)

    const stripeRes = await fetch('https://api.stripe.com/v1/checkout/sessions', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${secret}`,
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: params.toString(),
    })

    if (!stripeRes.ok) {
      const detail = await stripeRes.text()
      console.error('[billing/checkout] Stripe error:', detail.slice(0, 400))
      return NextResponse.json(
        { error: 'Stripe rejected the checkout request. Check the server configuration and try again.' },
        { status: 502 }
      )
    }

    const session = (await stripeRes.json()) as { url?: string }
    if (!session.url) {
      return NextResponse.json({ error: 'Stripe did not return a checkout URL.' }, { status: 502 })
    }
    return NextResponse.json({ url: session.url })
  } catch (err) {
    return serverError('billing/checkout', err)
  }
}
