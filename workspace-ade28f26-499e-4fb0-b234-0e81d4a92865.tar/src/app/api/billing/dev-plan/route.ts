import { NextRequest, NextResponse } from 'next/server'
import { z } from 'zod'
import { db } from '@/lib/db'
import { jsonError, requireUser, serverError } from '@/lib/server/api'
import { originAllowed } from '@/lib/server/auth'

export const runtime = 'nodejs'

/**
 * DEVELOPMENT-ONLY plan switch used to test paid-plan UI states.
 * Gated behind DEV_PLAN_SWITCH=true AND non-production — real upgrades always
 * go through the billing flow. This never fakes a payment.
 */
const schema = z.object({ plan: z.enum(['FREE', 'CREATOR', 'PRO', 'AGENCY']) })

export async function POST(req: NextRequest) {
  if (!originAllowed(req)) return jsonError('Request blocked.', 403)
  const { user, res } = await requireUser(req)
  if (!user) return res
  try {
    if (process.env.NODE_ENV === 'production' || process.env.DEV_PLAN_SWITCH !== 'true') {
      return jsonError('Development plan switching is disabled on this server.', 403)
    }
    const body = await req.json().catch(() => null)
    const parsed = schema.safeParse(body)
    if (!parsed.success) return jsonError('Invalid plan.')

    await db.user.update({
      where: { id: user.id },
      data: { plan: parsed.data.plan, planUpdatedAt: new Date() },
    })
    return NextResponse.json({ ok: true, plan: parsed.data.plan })
  } catch (err) {
    return serverError('billing/dev-plan', err)
  }
}
