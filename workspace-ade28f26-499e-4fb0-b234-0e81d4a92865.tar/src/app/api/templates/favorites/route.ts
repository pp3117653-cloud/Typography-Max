import { NextRequest, NextResponse } from 'next/server'
import { z } from 'zod'
import { db } from '@/lib/db'
import { jsonError, requireUser, serverError } from '@/lib/server/api'
import { originAllowed } from '@/lib/server/auth'

export const runtime = 'nodejs'

export async function GET(req: NextRequest) {
  const { user, res } = await requireUser(req)
  if (!user) return res
  try {
    const favorites = await db.templateFavorite.findMany({
      where: { userId: user.id },
      select: { templateId: true },
    })
    return NextResponse.json({ ids: favorites.map((f) => f.templateId) })
  } catch (err) {
    return serverError('favorites/list', err)
  }
}

const toggleSchema = z.object({ templateId: z.string().trim().min(1).max(64) })

export async function POST(req: NextRequest) {
  if (!originAllowed(req)) return jsonError('Request blocked.', 403)
  const { user, res } = await requireUser(req)
  if (!user) return res
  try {
    const body = await req.json().catch(() => null)
    const parsed = toggleSchema.safeParse(body)
    if (!parsed.success) return jsonError('Invalid template.')

    const existing = await db.templateFavorite.findUnique({
      where: { userId_templateId: { userId: user.id, templateId: parsed.data.templateId } },
    })
    if (existing) {
      await db.templateFavorite.delete({ where: { id: existing.id } })
      return NextResponse.json({ favorited: false })
    }
    await db.templateFavorite.create({
      data: { userId: user.id, templateId: parsed.data.templateId },
    })
    return NextResponse.json({ favorited: true })
  } catch (err) {
    return serverError('favorites/toggle', err)
  }
}
