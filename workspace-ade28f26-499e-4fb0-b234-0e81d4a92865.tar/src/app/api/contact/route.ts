import { NextRequest, NextResponse } from 'next/server'
import { z } from 'zod'
import { db } from '@/lib/db'
import { jsonError, serverError } from '@/lib/server/api'
import { originAllowed } from '@/lib/server/auth'
import { clientKey, rateLimit } from '@/lib/server/rate-limit'

export const runtime = 'nodejs'

const schema = z.object({
  email: z.string().trim().toLowerCase().email('Please enter a valid email address.'),
  subject: z.string().trim().min(2, 'Please add a short subject.').max(160),
  message: z.string().trim().min(10, 'Please describe your question (at least 10 characters).').max(4000),
})

export async function POST(req: NextRequest) {
  if (!originAllowed(req)) return jsonError('Request blocked.', 403)
  const limit = rateLimit(clientKey(req, 'contact'), 5, 60 * 60 * 1000)
  if (!limit.ok) {
    return NextResponse.json({ error: 'Too many messages. Please try again later.' }, { status: 429 })
  }
  try {
    const body = await req.json().catch(() => null)
    const parsed = schema.safeParse(body)
    if (!parsed.success) return jsonError(parsed.error.issues[0]?.message ?? 'Invalid input.')

    await db.contactMessage.create({
      data: {
        email: parsed.data.email,
        subject: parsed.data.subject,
        message: parsed.data.message,
      },
    })
    return NextResponse.json({ ok: true })
  } catch (err) {
    return serverError('contact', err)
  }
}
