import { NextRequest, NextResponse } from 'next/server'
import { rm } from 'fs/promises'
import path from 'path'
import { z } from 'zod'
import { db } from '@/lib/db'
import { jsonError, requireUser, serverError } from '@/lib/server/api'
import { hashPassword, originAllowed, sessionCookieClear, verifyPassword } from '@/lib/server/auth'

export const runtime = 'nodejs'

const profileSchema = z.object({
  name: z.string().trim().max(80).optional(),
})

const passwordSchema = z.object({
  currentPassword: z.string().min(1, 'Enter your current password.'),
  newPassword: z.string().min(8, 'New password must be at least 8 characters.').max(200),
})

export async function PATCH(req: NextRequest) {
  if (!originAllowed(req)) return jsonError('Request blocked.', 403)
  const { user, res } = await requireUser(req)
  if (!user) return res
  try {
    const body = await req.json().catch(() => null)
    const parsed = profileSchema.safeParse(body)
    if (!parsed.success) return jsonError(parsed.error.issues[0]?.message ?? 'Invalid input.')
    if (parsed.data.name === undefined) return jsonError('Nothing to update.')

    await db.user.update({
      where: { id: user.id },
      data: { name: parsed.data.name || null },
    })
    return NextResponse.json({ ok: true })
  } catch (err) {
    return serverError('account/update', err)
  }
}

export async function POST(req: NextRequest) {
  if (!originAllowed(req)) return jsonError('Request blocked.', 403)
  const { user, res } = await requireUser(req)
  if (!user) return res
  try {
    const body = await req.json().catch(() => null)
    const parsed = passwordSchema.safeParse(body)
    if (!parsed.success) return jsonError(parsed.error.issues[0]?.message ?? 'Invalid input.')

    const record = await db.user.findUnique({ where: { id: user.id } })
    if (!record || !verifyPassword(parsed.data.currentPassword, record.passwordHash)) {
      return jsonError('Your current password is incorrect.', 401)
    }

    await db.user.update({
      where: { id: user.id },
      data: { passwordHash: hashPassword(parsed.data.newPassword), tokenVersion: { increment: 1 } },
    })
    return NextResponse.json({ ok: true })
  } catch (err) {
    return serverError('account/password', err)
  }
}

/** Full account deletion: database rows and every stored file are removed. */
export async function DELETE(req: NextRequest) {
  if (!originAllowed(req)) return jsonError('Request blocked.', 403)
  const { user, res } = await requireUser(req)
  if (!user) return res
  try {
    const uploads = await db.uploadFile.findMany({ where: { userId: user.id } })
    const jobs = await db.exportJob.findMany({
      where: { userId: user.id, filePath: { not: null } },
      select: { filePath: true },
    })

    // Cascading deletes remove projects, jobs, favorites, tokens, uploads.
    await db.user.delete({ where: { id: user.id } })

    // Best-effort file cleanup — failures are logged, not surfaced.
    for (const upload of uploads) {
      await rm(path.join(process.cwd(), 'storage', 'uploads', upload.storagePath), { force: true }).catch(() => {})
    }
    for (const job of jobs) {
      if (job.filePath) {
        await rm(path.join(process.cwd(), 'storage', 'exports', job.filePath), { force: true }).catch(() => {})
      }
    }

    return sessionCookieClear(NextResponse.json({ ok: true }))
  } catch (err) {
    return serverError('account/delete', err)
  }
}
