'use client'

// Lightweight hash-based router. The app is a single Next.js route ("/") that
// behaves like an SPA; hash routes are shareable and survive refreshes.

import { useCallback, useEffect, useLayoutEffect, useRef, useState } from 'react'

export type Route =
  | { name: 'landing' }
  | { name: 'templates' }
  | { name: 'pricing' }
  | { name: 'help' }
  | { name: 'privacy' }
  | { name: 'terms' }
  | { name: 'login'; returnTo: string | null }
  | { name: 'signup'; returnTo: string | null }
  | { name: 'forgot-password' }
  | { name: 'reset-password'; token: string }
  | { name: 'dashboard' }
  | { name: 'new' }
  | { name: 'editor'; id: string }
  | { name: 'settings' }
  | { name: 'billing' }
  | { name: 'not-found' }

export function parseHash(hash: string): { route: Route; anchor: string | null } {
  // Support secondary anchors like "#/help#faq".
  const raw = hash.replace(/^#/, '')
  const [beforeQuery, queryString] = raw.split('?')
  const anchorIndex = beforeQuery.indexOf('#')
  const anchor = anchorIndex >= 0 ? beforeQuery.slice(anchorIndex + 1) : null
  const path = anchorIndex >= 0 ? beforeQuery.slice(0, anchorIndex) : beforeQuery
  const params = new URLSearchParams(queryString ?? '')
  const parts = path.split('/').filter(Boolean)

  if (parts.length === 0) return { route: { name: 'landing' }, anchor }
  const [head, second] = parts

  switch (head) {
    case 'templates':
      return { route: { name: 'templates' }, anchor }
    case 'pricing':
      return { route: { name: 'pricing' }, anchor }
    case 'help':
      return { route: { name: 'help' }, anchor }
    case 'privacy':
      return { route: { name: 'privacy' }, anchor }
    case 'terms':
      return { route: { name: 'terms' }, anchor }
    case 'login':
      return { route: { name: 'login', returnTo: params.get('returnTo') }, anchor }
    case 'signup':
      return { route: { name: 'signup', returnTo: params.get('returnTo') }, anchor }
    case 'forgot-password':
      return { route: { name: 'forgot-password' }, anchor }
    case 'reset-password':
      return { route: { name: 'reset-password', token: params.get('token') ?? '' }, anchor }
    case 'dashboard':
      return { route: { name: 'dashboard' }, anchor }
    case 'new':
      return { route: { name: 'new' }, anchor }
    case 'editor':
      return {
        route: second ? { name: 'editor', id: decodeURIComponent(second) } : { name: 'new' },
        anchor,
      }
    case 'settings':
      return { route: { name: 'settings' }, anchor }
    case 'billing':
      return { route: { name: 'billing' }, anchor }
    default:
      return { route: { name: 'not-found' }, anchor }
  }
}

export function navigate(to: string): void {
  const target = to.startsWith('#') ? to : `#${to.startsWith('/') ? to : `/${to}`}`
  if (window.location.hash === target) return
  window.location.hash = target
}

/** Current in-app path (no query/anchor), e.g. "/editor/draft". */
export function currentHashPath(): string {
  if (typeof window === 'undefined') return '/'
  const raw = window.location.hash.replace(/^#/, '')
  return raw.split('?')[0]?.split('#')[0] || '/'
}

// The server cannot see the URL hash, so SSR (and the matching first client
// render during hydration) always renders the landing route. The real hash
// route is applied in a layout effect BEFORE first paint — this keeps hard
// reloads of any #/route free of hydration mismatches while still showing
// the correct view immediately (no visible landing flash).
const useIsomorphicLayoutEffect =
  typeof window !== 'undefined' ? useLayoutEffect : useEffect

export function useHashRoute(): { route: Route; anchor: string | null; navigate: typeof navigate } {
  // Initial state mirrors the server render (landing). See comment above.
  const [state, setState] = useState<{ route: Route; anchor: string | null }>({
    route: { name: 'landing' },
    anchor: null,
  })
  const didApplyHash = useRef(false)

  useIsomorphicLayoutEffect(() => {
    const onChange = () => {
      setState(parseHash(window.location.hash))
      window.scrollTo({ top: 0 })
    }

    if (!didApplyHash.current) {
      didApplyHash.current = true
      // Swap from the SSR landing tree to the actual hash route (pre-paint).
      const next = parseHash(window.location.hash)
      setState((prev) =>
        prev.route.name === 'landing' && next.route.name === 'landing' && prev.anchor === next.anchor
          ? prev // already the landing route — nothing to swap
          : next
      )
    }

    window.addEventListener('hashchange', onChange)
    return () => window.removeEventListener('hashchange', onChange)
  }, [])

  // Scroll to a secondary anchor (e.g. #/help#faq) once the view renders.
  // Views are lazy-loaded, so the target element may not exist yet — retry
  // with back-off until it does (max ~1.6s), then stop.
  useEffect(() => {
    if (!state.anchor) return
    let found = false
    const timers = [150, 400, 900, 1600].map((delay) =>
      window.setTimeout(() => {
        if (found) return
        const el = document.getElementById(state.anchor as string)
        if (el) {
          found = true
          el.scrollIntoView({ behavior: 'smooth', block: 'start' })
        }
      }, delay)
    )
    return () => {
      timers.forEach((timer) => window.clearTimeout(timer))
    }
  }, [state.anchor, state.route])

  return {
    route: state.route,
    anchor: state.anchor,
    navigate: useCallback((to: string) => navigate(to), []),
  }
}

export function routeToPath(route: Route): string {
  switch (route.name) {
    case 'landing':
      return '/'
    default:
      return `/${route.name}`
  }
}
