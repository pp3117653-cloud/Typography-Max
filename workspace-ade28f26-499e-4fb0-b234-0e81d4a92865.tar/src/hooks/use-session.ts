'use client'

import { useQuery, useQueryClient } from '@tanstack/react-query'
import { apiGet, apiSend } from '@/lib/api-client'
import type { PlanId, SessionUser, UsageInfo } from '@/lib/typography/types'
import { getPlan } from '@/lib/typography/plans'

export interface SessionState {
  user: SessionUser | null
  status: 'loading' | 'authenticated' | 'unauthenticated'
  refresh: () => Promise<void>
  logout: () => Promise<void>
  plan: ReturnType<typeof getPlan>
}

export function useSession(): SessionState {
  const queryClient = useQueryClient()
  const { data, isLoading } = useQuery({
    queryKey: ['session'],
    queryFn: () => apiGet<{ user: SessionUser | null }>('/api/auth/session'),
    staleTime: 30_000,
  })

  const refresh = async () => {
    await queryClient.invalidateQueries({ queryKey: ['session'] })
  }

  const logout = async () => {
    await apiSend('POST', '/api/auth/logout')
    await queryClient.invalidateQueries()
  }

  const user = data?.user ?? null
  return {
    user,
    status: isLoading ? 'loading' : user ? 'authenticated' : 'unauthenticated',
    refresh,
    logout,
    plan: getPlan(user?.plan as PlanId | undefined),
  }
}

export function useUsage() {
  const { user } = useSession()
  const { data, isLoading } = useQuery({
    queryKey: ['usage'],
    queryFn: () => apiGet<UsageInfo>('/api/usage'),
    enabled: !!user,
    staleTime: 15_000,
  })
  return { usage: data ?? null, isLoading }
}
