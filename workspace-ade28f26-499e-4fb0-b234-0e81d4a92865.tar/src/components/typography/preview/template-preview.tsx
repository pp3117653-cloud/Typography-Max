'use client'

// Live canvas preview of a template, driven by the same render engine used
// for exports. Pauses automatically when scrolled out of view.

import { useEffect, useMemo, useRef, useState } from 'react'
import { projectFromTemplate, type TemplateDef } from '@/lib/typography/templates'
import { createRenderer } from '@/lib/typography/render-frame'
import { ensureProjectFontsLoaded } from '@/lib/typography/fonts'
import { CANVAS_SIZES } from '@/lib/typography/types'

interface Props {
  template: TemplateDef
  /** Animate the preview in a loop (default true). */
  animated?: boolean
  className?: string
}

export function TemplatePreview({ template, animated = true, className }: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [fontsReady, setFontsReady] = useState(false)
  const [visible, setVisible] = useState(true)
  const wrapRef = useRef<HTMLDivElement>(null)

  const project = useMemo(() => projectFromTemplate(template), [template])
  const renderer = useMemo(
    () => (fontsReady ? createRenderer(project, {}) : null),
    [project, fontsReady]
  )

  useEffect(() => {
    let cancelled = false
    ensureProjectFontsLoaded(project.style.fontId, [project.style.fontWeight]).then(() => {
      if (!cancelled) setFontsReady(true)
    })
    return () => {
      cancelled = true
    }
  }, [project])

  useEffect(() => {
    const el = wrapRef.current
    if (!el || typeof IntersectionObserver === 'undefined') return
    const observer = new IntersectionObserver(
      (entries) => setVisible(entries.some((e) => e.isIntersecting)),
      { rootMargin: '120px' }
    )
    observer.observe(el)
    return () => observer.disconnect()
  }, [])

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas || !renderer) return
    const ctx = canvas.getContext('2d')
    if (!ctx) return

    const base = CANVAS_SIZES[project.format]
    let raf = 0
    let start = 0
    const stopped = !animated || !visible

    const drawFrame = (t: number) => {
      const dpr = Math.min(2, typeof window !== 'undefined' ? window.devicePixelRatio || 1 : 1)
      const rect = canvas.getBoundingClientRect()
      const w = Math.max(1, Math.round(rect.width * dpr))
      const h = Math.max(1, Math.round(rect.height * dpr))
      if (canvas.width !== w || canvas.height !== h) {
        canvas.width = w
        canvas.height = h
      }
      // Letterbox-fit inside whatever box we were given.
      const scale = Math.min(w / base.width, h / base.height)
      const offsetX = (w - base.width * scale) / 2
      const offsetY = (h - base.height * scale) / 2
      ctx.setTransform(1, 0, 0, 1, 0, 0)
      ctx.clearRect(0, 0, w, h)
      ctx.setTransform(scale, 0, 0, scale, offsetX, offsetY)
      renderer.render(ctx, t)
    }

    if (stopped) {
      // Static frame at an expressive moment.
      drawFrame(Math.min(1.4, renderer.duration * 0.35))
      return
    }

    const loop = (now: number) => {
      if (!start) start = now
      const elapsed = ((now - start) / 1000) % Math.max(0.5, renderer.duration + 0.6)
      drawFrame(elapsed)
      raf = requestAnimationFrame(loop)
    }
    raf = requestAnimationFrame(loop)
    return () => cancelAnimationFrame(raf)
  }, [renderer, animated, visible, project])

  return (
    <div
      ref={wrapRef}
      className={`relative mx-auto h-full ${className ?? ''}`}
      style={{ aspectRatio: project.format.replace(':', ' / ') }}
      aria-hidden="true"
    >
      <canvas ref={canvasRef} className="absolute inset-0 h-full w-full" />
    </div>
  )
}
