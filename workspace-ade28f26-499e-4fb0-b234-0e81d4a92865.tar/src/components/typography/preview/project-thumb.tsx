'use client'

// Static thumbnail of a project (mid-animation) used on dashboard cards.

import { useEffect, useMemo, useRef, useState } from 'react'
import type { ProjectData } from '@/lib/typography/types'
import { CANVAS_SIZES } from '@/lib/typography/types'
import { createRenderer } from '@/lib/typography/render-frame'
import { ensureProjectFontsLoaded } from '@/lib/typography/fonts'

interface Props {
  project: ProjectData
  className?: string
}

export function ProjectThumb({ project, className }: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [fontsReady, setFontsReady] = useState(false)

  const renderer = useMemo(
    () => (fontsReady ? createRenderer(project, {}) : null),
    [project, fontsReady]
  )

  useEffect(() => {
    let cancelled = false
    ensureProjectFontsLoaded(project.style.fontId, [project.style.fontWeight]).then(() => {
      if (!cancelled) setFontsReady(true)
    })
    return () => {
      cancelled = true
    }
  }, [project])

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas || !renderer) return
    const ctx = canvas.getContext('2d')
    if (!ctx) return
    const base = CANVAS_SIZES[project.format]
    const dpr = Math.min(2, typeof window !== 'undefined' ? window.devicePixelRatio || 1 : 1)
    const rect = canvas.getBoundingClientRect()
    const w = Math.max(1, Math.round(rect.width * dpr))
    const h = Math.max(1, Math.round(rect.height * dpr))
    canvas.width = w
    canvas.height = h
    const scale = Math.min(w / base.width, h / base.height)
    const offsetX = (w - base.width * scale) / 2
    const offsetY = (h - base.height * scale) / 2
    ctx.setTransform(scale, 0, 0, scale, offsetX, offsetY)
    renderer.render(ctx, Math.min(1.5, renderer.duration * 0.4))
  }, [renderer, project])

  return (
    <div
      className={`relative mx-auto h-full ${className ?? ''}`}
      style={{ aspectRatio: project.format.replace(':', ' / ') }}
    >
      <canvas ref={canvasRef} className="absolute inset-0 h-full w-full" aria-hidden="true" />
    </div>
  )
}
