'use client'

// Application chrome: top navigation + footer. The editor renders full-bleed
// (no nav/footer) to maximize canvas space.

import { useState } from 'react'
import {
  BadgeCheck,
  CreditCard,
  FileVideo,
  Film,
  LayoutDashboard,
  LogOut,
  Menu,
  Plus,
  Settings,
  ShieldCheck,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { Sheet, SheetContent, SheetTitle, SheetTrigger } from '@/components/ui/sheet'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { useSession } from '@/hooks/use-session'
import { navigate } from '@/hooks/use-hash-route'
import { getPlan } from '@/lib/typography/plans'
import { toast } from 'sonner'

export function Logo({ compact = false }: { compact?: boolean }) {
  return (
    <span className="inline-flex items-center gap-2.5">
      <svg viewBox="0 0 64 64" className="h-8 w-8 shrink-0" aria-hidden="true">
        <rect width="64" height="64" rx="14" fill="#141417" />
        <rect x="14" y="16" width="36" height="7" rx="3.5" fill="#FF5A1F" />
        <rect x="28.5" y="16" width="7" height="34" rx="3.5" fill="#FAFAFA" />
        <rect x="14" y="43" width="36" height="7" rx="3.5" fill="#FF5A1F" opacity="0.55" />
      </svg>
      {!compact && (
        <span className="font-display text-lg font-bold tracking-tight text-foreground">
          Typography
        </span>
      )}
    </span>
  )
}

function NavLink({ to, children }: { to: string; children: React.ReactNode }) {
  return (
    <button
      onClick={() => navigate(to)}
      className="rounded-md px-3 py-2 text-sm font-medium text-muted-foreground transition-colors hover:bg-accent hover:text-foreground"
    >
      {children}
    </button>
  )
}

export function TopNav() {
  const { user, status, logout, plan } = useSession()
  const [mobileOpen, setMobileOpen] = useState(false)

  const handleLogout = async () => {
    try {
      await logout()
      toast.success('Signed out')
      navigate('/')
    } catch {
      toast.error('Could not sign out. Please try again.')
    }
  }

  const links = (
    <>
      <NavLink to="/templates">Templates</NavLink>
      <NavLink to="/pricing">Pricing</NavLink>
      <NavLink to="/help">Help</NavLink>
    </>
  )

  return (
    <header className="sticky top-0 z-50 border-b border-border/80 bg-background/85 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between gap-3 px-4 sm:px-6">
        <button onClick={() => navigate('/')} aria-label="Typography — home" className="rounded-md">
          <Logo />
        </button>

        <nav className="hidden items-center gap-1 md:flex" aria-label="Main">
          {links}
        </nav>

        <div className="hidden items-center gap-2 md:flex">
          {status === 'loading' ? (
            <div className="h-9 w-36 animate-pulse rounded-md bg-muted" />
          ) : user ? (
            <>
              <Button size="sm" onClick={() => navigate('/new')}>
                <Plus className="mr-1.5 h-4 w-4" aria-hidden="true" />
                New video
              </Button>
              <Button variant="secondary" size="sm" onClick={() => navigate('/dashboard')}>
                <LayoutDashboard className="mr-1.5 h-4 w-4" aria-hidden="true" />
                Dashboard
              </Button>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <button
                    className="rounded-full ring-offset-background transition-shadow hover:ring-2 hover:ring-ring focus-visible:ring-2"
                    aria-label="Account menu"
                  >
                    <Avatar className="h-9 w-9 border border-border">
                      <AvatarFallback className="bg-secondary text-xs font-semibold text-secondary-foreground">
                        {(user.name || user.email).slice(0, 2).toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                  </button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  <DropdownMenuLabel>
                    <div className="truncate text-sm font-medium">{user.name || 'Creator'}</div>
                    <div className="truncate text-xs font-normal text-muted-foreground">{user.email}</div>
                    <div className="mt-1 text-[11px] font-medium text-brand">{plan.name} plan</div>
                  </DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={() => navigate('/settings')}>
                    <Settings className="mr-2 h-4 w-4" aria-hidden="true" /> Account settings
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => navigate('/billing')}>
                    <CreditCard className="mr-2 h-4 w-4" aria-hidden="true" /> Billing & usage
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={handleLogout}>
                    <LogOut className="mr-2 h-4 w-4" aria-hidden="true" /> Sign out
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </>
          ) : (
            <>
              <Button variant="ghost" size="sm" onClick={() => navigate('/login')}>
                Sign in
              </Button>
              <Button size="sm" onClick={() => navigate('/editor/draft')}>
                <Film className="mr-1.5 h-4 w-4" aria-hidden="true" />
                Start free
              </Button>
            </>
          )}
        </div>

        {/* Mobile */}
        <div className="md:hidden">
          <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" aria-label="Open menu">
                <Menu className="h-5 w-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-72">
              <SheetTitle className="sr-only">Navigation</SheetTitle>
              <div className="mt-2 flex flex-col gap-1">
                <button
                  onClick={() => {
                    setMobileOpen(false)
                    navigate('/')
                  }}
                  className="rounded-md px-3 py-2.5 text-left text-sm font-medium hover:bg-accent"
                >
                  Home
                </button>
                {[
                  ['/templates', 'Templates'],
                  ['/pricing', 'Pricing'],
                  ['/help', 'Help'],
                ].map(([to, label]) => (
                  <button
                    key={to}
                    onClick={() => {
                      setMobileOpen(false)
                      navigate(to)
                    }}
                    className="rounded-md px-3 py-2.5 text-left text-sm font-medium hover:bg-accent"
                  >
                    {label}
                  </button>
                ))}
                {user && (
                  <>
                    <button
                      onClick={() => {
                        setMobileOpen(false)
                        navigate('/dashboard')
                      }}
                      className="rounded-md px-3 py-2.5 text-left text-sm font-medium hover:bg-accent"
                    >
                      Dashboard
                    </button>
                    <Button
                      className="mt-1"
                      onClick={() => {
                        setMobileOpen(false)
                        navigate('/new')
                      }}
                    >
                      <Plus className="mr-1.5 h-4 w-4" aria-hidden="true" />
                      New video
                    </Button>
                  </>
                )}
                <div className="my-2 h-px bg-border" />
                {user ? (
                  <>
                    <button
                      onClick={() => {
                        setMobileOpen(false)
                        navigate('/settings')
                      }}
                      className="rounded-md px-3 py-2.5 text-left text-sm font-medium hover:bg-accent"
                    >
                      Account settings
                    </button>
                    <button
                      onClick={() => {
                        setMobileOpen(false)
                        navigate('/billing')
                      }}
                      className="rounded-md px-3 py-2.5 text-left text-sm font-medium hover:bg-accent"
                    >
                      Billing & usage
                    </button>
                    <button
                      onClick={() => {
                        setMobileOpen(false)
                        handleLogout()
                      }}
                      className="rounded-md px-3 py-2.5 text-left text-sm font-medium text-muted-foreground hover:bg-accent"
                    >
                      Sign out
                    </button>
                  </>
                ) : (
                  <>
                    <Button
                      variant="outline"
                      className="mt-1"
                      onClick={() => {
                        setMobileOpen(false)
                        navigate('/login')
                      }}
                    >
                      Sign in
                    </Button>
                    <Button
                      className="mt-1"
                      onClick={() => {
                        setMobileOpen(false)
                        navigate('/editor/draft')
                      }}
                    >
                      Start free
                    </Button>
                  </>
                )}
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  )
}

export function Footer() {
  return (
    <footer className="mt-auto border-t border-border/80 bg-background pb-[env(safe-area-inset-bottom)]">
      <div className="mx-auto max-w-6xl px-4 py-12 sm:px-6">
        <div className="grid gap-10 sm:grid-cols-2 lg:grid-cols-4">
          <div>
            <Logo />
            <p className="mt-4 max-w-xs text-sm leading-relaxed text-muted-foreground">
              Turn any script into an engaging animated typography video in minutes.
            </p>
            <ul
              className="mt-5 flex flex-wrap items-center gap-x-4 gap-y-2"
              aria-label="Product promises"
            >
              <li className="flex items-center gap-1.5 text-xs text-muted-foreground">
                <BadgeCheck className="size-3.5 shrink-0 text-brand" aria-hidden="true" />
                Licensed fonts (OFL)
              </li>
              <li className="flex items-center gap-1.5 text-xs text-muted-foreground">
                <FileVideo className="size-3.5 shrink-0 text-brand" aria-hidden="true" />
                Your exports belong to you
              </li>
              <li className="flex items-center gap-1.5 text-xs text-muted-foreground">
                <ShieldCheck className="size-3.5 shrink-0 text-brand" aria-hidden="true" />
                No credit card to start
              </li>
            </ul>
          </div>
          <nav aria-label="Product">
            <h3 className="text-sm font-semibold text-foreground">Product</h3>
            <ul className="mt-4 space-y-2.5 text-sm">
              <li><FooterLink to="/templates">Templates</FooterLink></li>
              <li><FooterLink to="/pricing">Pricing</FooterLink></li>
              <li><FooterLink to="/editor/draft">Try the editor</FooterLink></li>
              <li><FooterLink to="/dashboard">Dashboard</FooterLink></li>
            </ul>
          </nav>
          <nav aria-label="Support">
            <h3 className="text-sm font-semibold text-foreground">Support</h3>
            <ul className="mt-4 space-y-2.5 text-sm">
              <li><FooterLink to="/help">Help & contact</FooterLink></li>
              <li><FooterLink to="/help#faq">FAQ</FooterLink></li>
              <li><FooterLink to="/help#copyright">Copyright & audio use</FooterLink></li>
            </ul>
          </nav>
          <nav aria-label="Legal">
            <h3 className="text-sm font-semibold text-foreground">Legal</h3>
            <ul className="mt-4 space-y-2.5 text-sm">
              <li><FooterLink to="/privacy">Privacy Policy</FooterLink></li>
              <li><FooterLink to="/terms">Terms of Service</FooterLink></li>
            </ul>
          </nav>
        </div>
        <div className="mt-10 flex flex-col items-start justify-between gap-3 border-t border-border/60 pt-6 text-xs text-muted-foreground sm:flex-row sm:items-center">
          <p>© {new Date().getFullYear()} Typography. All rights reserved.</p>
          <p>
            Made for creators, coaches, musicians and marketers. Your videos are yours —
            fonts are OFL-licensed for commercial use.
          </p>
        </div>
      </div>
    </footer>
  )
}

function FooterLink({ to, children }: { to: string; children: React.ReactNode }) {
  return (
    <button
      onClick={() => navigate(to)}
      className="text-muted-foreground transition-colors hover:text-foreground"
    >
      {children}
    </button>
  )
}

export function AppShell({ children, bare }: { children: React.ReactNode; bare?: boolean }) {
  if (bare) {
    return <div className="flex min-h-screen flex-col bg-background">{children}</div>
  }
  return (
    <div className="flex min-h-screen flex-col bg-background">
      <TopNav />
      <main id="main-content" className="flex-1">
        {children}
      </main>
      <Footer />
    </div>
  )
}
