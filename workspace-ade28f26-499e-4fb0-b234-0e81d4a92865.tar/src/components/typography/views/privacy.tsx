'use client'

import type { ReactNode } from 'react'
import { navigate } from '@/hooks/use-hash-route'

function Section({ title, children }: { title: string; children: ReactNode }) {
  return (
    <section className="mt-10">
      <h2 className="font-display text-xl font-semibold tracking-tight">{title}</h2>
      <div className="mt-3 space-y-3 text-sm leading-6 text-muted-foreground">{children}</div>
    </section>
  )
}

export default function PrivacyView() {
  return (
    <div className="mx-auto max-w-3xl px-4 py-12 sm:px-6">
      <h1 className="font-display text-4xl font-bold tracking-tight">Privacy Policy</h1>
      <p className="mt-2 text-sm text-muted-foreground">Last updated: January 2025</p>
      <p className="mt-6 text-base leading-7">
        This policy explains, in plain language, what data Typography collects when you use our
        service, why we collect it, and the choices you have. Typography is a tool that turns
        scripts, quotes and lyrics into animated typography videos.
      </p>

      <Section title="What we collect">
        <p>
          <strong className="text-foreground">Account information.</strong> When you create an
          account we store your email address and an encrypted (hashed) version of your password.
          Your name is optional and only stored if you provide it.
        </p>
        <p>
          <strong className="text-foreground">Project content.</strong> The scripts, quotes or
          lyrics you type into the editor, along with your design choices (fonts, colors,
          animations), are saved so you can return to your work.
        </p>
        <p>
          <strong className="text-foreground">Uploaded files.</strong> Audio and image files you
          upload (for example background music or a background image) are stored on our servers so
          your projects can use them.
        </p>
        <p>
          <strong className="text-foreground">Export history.</strong> We keep a record of each
          video you export — which project it came from, the resolution, and when it happened — so
          we can enforce plan limits and show you your history.
        </p>
        <p>
          <strong className="text-foreground">Support messages.</strong> If you contact us, we keep
          your email address and message so we can reply.
        </p>
        <p>
          We do not sell your data, and we do not run advertising or cross-site tracking on this
          product.
        </p>
      </Section>

      <Section title="Why we collect it">
        <p>
          Everything above is collected to operate the service you signed up for: creating and
          storing your projects, rendering your exports, enforcing the limits of your plan,
          securing your account, and answering you when you write to us. We don&apos;t build
          advertising profiles from your content.
        </p>
      </Section>

      <Section title="AI features">
        <p>
          The editor includes optional AI writing tools (for example, turning a long script into
          scenes or suggesting a quote). When you use one of these tools, the text you submit is
          sent to a third-party AI service to generate the suggestion. The text sent is limited to
          what&apos;s needed for that request. Don&apos;t put anything into these tools that you
          wouldn&apos;t want processed by an AI provider — the tools are always optional, and you
          can create every video without them.
        </p>
      </Section>

      <Section title="How long we keep your files">
        <p>
          <strong className="text-foreground">Exported videos</strong> are stored for download for
          7 days after the export completes, then automatically deleted.
        </p>
        <p>
          <strong className="text-foreground">Uploaded audio and images</strong> are kept until you
          delete them (by deleting the project or the upload) or until you delete your account.
        </p>
        <p>
          <strong className="text-foreground">Projects and account data</strong> are kept until you
          delete them or close your account.
        </p>
      </Section>

      <Section title="Cookies">
        <p>
          We use a single session cookie to keep you signed in. It&apos;s marked httpOnly and is
          used only for authentication. We do not use tracking cookies, analytics pixels or
          third-party advertising tags.
        </p>
      </Section>

      <Section title="Who we share data with">
        <p>
          Very few parties. Our AI provider receives the text you submit to AI tools (see above).
          If you pay, our payment processor (Stripe) handles your card details — we never see or
          store them. Our hosting provider stores the servers and files. We may disclose
          information if legally required, or to protect the service and our users from abuse.
        </p>
      </Section>

      <Section title="Deleting your data">
        <p>
          You can delete individual projects, uploads and exports at any time from the app. To
          delete everything, use{' '}
          <strong className="text-foreground">Settings → Danger zone → Delete account</strong>.
          Account deletion permanently removes your account, all projects, exports and uploaded
          files from our systems — there is no undo. You can also write to us at{' '}
          <span className="text-foreground">support@typography.app</span> and we&apos;ll delete
          your account for you.
        </p>
      </Section>

      <Section title="Security">
        <p>
          Passwords are stored only as salted hashes, sessions are signed and expire, and uploads
          are validated by type. No system is perfect, but we apply reasonable technical measures
          and keep the amount of data we hold to a minimum.
        </p>
      </Section>

      <Section title="Changes to this policy">
        <p>
          If we make material changes we&apos;ll update the date at the top of this page and, for
          significant changes, notify you in the app. Continued use after a change means you accept
          the updated policy.
        </p>
      </Section>

      <Section title="Contact">
        <p>
          Questions about privacy? Email us at{' '}
          <span className="text-foreground">support@typography.app</span> or use the contact form
          on the{' '}
          <button
            type="button"
            onClick={() => navigate('/help')}
            className="font-medium text-brand hover:underline"
          >
            Help page
          </button>
          .
        </p>
      </Section>
    </div>
  )
}
