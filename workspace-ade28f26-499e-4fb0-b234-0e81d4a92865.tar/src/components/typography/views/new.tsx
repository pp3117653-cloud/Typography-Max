'use client'

// New project — one page, three ways to start: blank, pasted script or template.

import { useState } from 'react'
import {
  ArrowLeft,
  Check,
  ClipboardPaste,
  FileText,
  Film,
  Info,
  LayoutTemplate,
  Loader2,
  Sparkles,
} from 'lucide-react'
import { navigate } from '@/hooks/use-hash-route'
import { useSession } from '@/hooks/use-session'
import { apiSend, ApiError } from '@/lib/api-client'
import { TEMPLATES, getTemplate, projectFromTemplate } from '@/lib/typography/templates'
import { defaultProject, splitScriptIntoScenes } from '@/lib/typography/defaults'
import type { ProjectData } from '@/lib/typography/types'
import { TemplatePreview } from '@/components/typography/preview/template-preview'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Skeleton } from '@/components/ui/skeleton'
import { Textarea } from '@/components/ui/textarea'
import { toast } from 'sonner'
import { cn } from '@/lib/utils'

type StartMode = 'blank' | 'script' | 'template'

const START_OPTIONS: { id: StartMode; title: string; copy: string; icon: typeof FileText }[] = [
  { id: 'blank', title: 'Blank project', copy: 'A clean canvas with sample text to edit', icon: FileText },
  { id: 'script', title: 'Paste a script', copy: 'Split your text into scenes automatically', icon: ClipboardPaste },
  { id: 'template', title: 'Use a template', copy: 'Pick a designer style', icon: LayoutTemplate },
]

function isProjectLimit(err: unknown): err is ApiError {
  // The API answers plan-cap blocks with HTTP 402 + code 'PROJECT_LIMIT'.
  return err instanceof ApiError && err.status === 402
}

export default function NewProjectView() {
  const { status, plan } = useSession()

  const [name, setName] = useState('My first video')
  // Deep link: /new?start=script|template|blank preselects the start mode
  // (same pattern SignupView uses for returnTo).
  const [initialMode] = useState<StartMode>(() => {
    if (typeof window === 'undefined') return 'blank'
    const qs = window.location.hash.split('?')[1] || ''
    const v = new URLSearchParams(qs).get('start')
    return v === 'script' || v === 'template' || v === 'blank' ? (v as StartMode) : 'blank'
  })
  const [mode, setMode] = useState<StartMode>(initialMode)
  const [script, setScript] = useState('')
  const [templateId, setTemplateId] = useState<string | null>(null)
  const [scriptError, setScriptError] = useState<string | null>(null)
  const [templateError, setTemplateError] = useState<string | null>(null)
  const [creating, setCreating] = useState(false)
  const [upgrade, setUpgrade] = useState<{ open: boolean; message: string }>({ open: false, message: '' })

  /* Honest gate: guests can try the editor, but saving needs an account. */
  if (status === 'unauthenticated') {
    return (
      <div className="mx-auto max-w-6xl px-4 py-16 sm:px-6">
        <Card className="mx-auto max-w-lg">
          <CardContent className="flex flex-col items-center gap-4 py-12 text-center">
            <div className="rounded-full bg-brand-soft p-4">
              <Film className="h-7 w-7 text-brand" aria-hidden="true" />
            </div>
            <div>
              <h1 className="font-display text-2xl font-bold">Create a free account to save projects</h1>
              <p className="mx-auto mt-2 max-w-sm text-sm text-muted-foreground">
                Projects live in your account so you can pick them up on any device. You can also try the
                editor first — a guest draft stays in this browser.
              </p>
            </div>
            <div className="flex flex-col gap-3 sm:flex-row">
              <Button onClick={() => navigate('/signup')}>Create free account</Button>
              <Button variant="outline" onClick={() => navigate('/editor/draft')}>
                Continue in the editor without an account
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  if (status === 'loading') {
    return (
      <div className="mx-auto max-w-6xl px-4 py-10 sm:px-6 sm:py-12" aria-busy="true">
        <Skeleton className="h-10 w-64" />
        <Skeleton className="mt-3 h-5 w-96 max-w-full" />
        <div className="mt-10 space-y-8">
          <Skeleton className="h-10 w-full max-w-md" />
          <div className="grid gap-3 sm:grid-cols-3">
            <Skeleton className="h-32 rounded-lg" />
            <Skeleton className="h-32 rounded-lg" />
            <Skeleton className="h-32 rounded-lg" />
          </div>
        </div>
      </div>
    )
  }

  const fallbackName = (): string => {
    if (mode === 'template') {
      const tpl = getTemplate(templateId)
      if (tpl) return `${tpl.name} video`
    }
    if (mode === 'script') return 'Script video'
    return 'My first video'
  }

  const buildData = (): { data: ProjectData } | { error: string } => {
    if (mode === 'blank') return { data: defaultProject() }
    if (mode === 'script') {
      const scenes = splitScriptIntoScenes(script)
      if (scenes.length === 0) return { error: 'script' }
      return { data: { ...defaultProject(), scenes } }
    }
    const tpl = getTemplate(templateId)
    if (!tpl) return { error: 'template' }
    return { data: projectFromTemplate(tpl) }
  }

  const handleCreate = async () => {
    setScriptError(null)
    setTemplateError(null)
    const built = buildData()
    if ('error' in built) {
      if (built.error === 'script') setScriptError('Paste some text first — even one line works.')
      else setTemplateError('Pick a template to continue.')
      return
    }
    setCreating(true)
    try {
      const res = await apiSend<{ id: string }>('POST', '/api/projects', {
        name: name.trim() || fallbackName(),
        data: built.data,
      })
      navigate(`/editor/${res.id}`)
    } catch (err) {
      if (isProjectLimit(err)) {
        setUpgrade({ open: true, message: err.message })
      } else {
        toast.error(err instanceof ApiError ? err.message : 'Could not create the project. Please try again.')
      }
    } finally {
      setCreating(false)
    }
  }

  return (
    <div className="mx-auto max-w-3xl px-4 py-10 sm:px-6 sm:py-12">
      <Button variant="ghost" size="sm" className="-ml-2 text-muted-foreground" onClick={() => navigate('/dashboard')}>
        <ArrowLeft className="h-4 w-4" aria-hidden="true" /> Back to dashboard
      </Button>

      <header className="mt-4">
        <h1 className="font-display text-2xl font-bold sm:text-3xl">New project</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Set up the basics now — you can change everything in the editor.
        </p>
      </header>

      <div className="mt-8 space-y-8">
        {/* 1 — Name */}
        <div className="space-y-2">
          <Label htmlFor="project-name">Project name</Label>
          <Input
            id="project-name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            maxLength={120}
            placeholder="My first video"
          />
          <p className="text-xs text-muted-foreground">Only you see this — rename it any time.</p>
        </div>

        {/* 2 — Start from */}
        <fieldset>
          <legend className="text-sm font-medium">Start from</legend>
          <div className="mt-3 grid gap-3 sm:grid-cols-3">
            {START_OPTIONS.map((opt) => {
              const Icon = opt.icon
              const selected = mode === opt.id
              return (
                <label key={opt.id} className="block cursor-pointer">
                  <input
                    type="radio"
                    name="start-from"
                    value={opt.id}
                    checked={selected}
                    onChange={() => {
                      setMode(opt.id)
                      setScriptError(null)
                      setTemplateError(null)
                    }}
                    className="peer sr-only"
                    aria-label={opt.title}
                  />
                  <div
                    className={cn(
                      'h-full rounded-lg border bg-card p-4 transition-colors peer-focus-visible:ring-2 peer-focus-visible:ring-ring',
                      selected ? 'border-brand' : 'border-border hover:border-brand/50'
                    )}
                  >
                    <div className="flex items-center justify-between">
                      <Icon className="h-5 w-5 text-brand" aria-hidden="true" />
                      {selected && <Check className="h-4 w-4 text-brand" aria-hidden="true" />}
                    </div>
                    <p className="mt-3 text-sm font-medium">{opt.title}</p>
                    <p className="mt-1 text-xs text-muted-foreground">{opt.copy}</p>
                  </div>
                </label>
              )
            })}
          </div>
        </fieldset>

        {/* 3 — Script */}
        {mode === 'script' && (
          <div className="space-y-2">
            <Label htmlFor="script">Your script</Label>
            <Textarea
              id="script"
              rows={8}
              value={script}
              onChange={(e) => {
                setScript(e.target.value)
                if (scriptError) setScriptError(null)
              }}
              placeholder="Paste your script, quotes, or lyrics here…"
              aria-invalid={!!scriptError}
            />
            <div className="flex items-center justify-between gap-4 text-xs text-muted-foreground">
              <span>We&apos;ll split it into scenes — you can edit them after.</span>
              <span className="shrink-0 tabular-nums">{script.length.toLocaleString()} characters</span>
            </div>
            {scriptError && (
              <p className="text-sm text-destructive" role="alert">
                {scriptError}
              </p>
            )}
          </div>
        )}

        {/* 4 — Template picker */}
        {mode === 'template' && (
          <div className="space-y-2">
            <Label>Your template</Label>
            <div className="-mx-1 flex gap-3 overflow-x-auto px-1 pb-2 scrollbar-slim" role="group" aria-label="Pick a template">
              {TEMPLATES.map((tpl) => {
                const selected = templateId === tpl.id
                return (
                  <button
                    key={tpl.id}
                    type="button"
                    onClick={() => {
                      setTemplateId(tpl.id)
                      if (templateError) setTemplateError(null)
                    }}
                    aria-pressed={selected}
                    aria-label={`Use the ${tpl.name} template`}
                    className={cn(
                      'w-28 shrink-0 cursor-pointer overflow-hidden rounded-lg border text-left transition-colors',
                      selected ? 'border-brand ring-2 ring-brand' : 'border-border hover:border-brand/50'
                    )}
                  >
                    <span className="flex h-36 items-center justify-center bg-card">
                      <TemplatePreview template={tpl} animated={false} className="h-full" />
                    </span>
                    <span className="flex items-center justify-between gap-1 px-2 py-1.5">
                      <span className="truncate text-xs font-medium">{tpl.name}</span>
                      {tpl.premium && <span className="shrink-0 text-[10px] font-semibold uppercase text-brand">Pro</span>}
                    </span>
                  </button>
                )
              })}
            </div>
            {templateError && (
              <p className="text-sm text-destructive" role="alert">
                {templateError}
              </p>
            )}
          </div>
        )}

        {/* Create */}
        <div className="flex flex-col-reverse gap-4 sm:flex-row sm:items-center sm:justify-between">
          <p className="flex items-start gap-2 text-xs text-muted-foreground">
            <Info className="mt-0.5 h-3.5 w-3.5 shrink-0" aria-hidden="true" />
            {plan.id === 'FREE'
              ? 'Free plan includes 3 saved projects and 5 exports per month.'
              : `${plan.name} plan includes ${plan.maxProjects} saved projects and ${plan.exportsPerMonth} exports per month.`}
          </p>
          <Button size="lg" onClick={() => void handleCreate()} disabled={creating} className="shrink-0">
            {creating ? (
              <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />
            ) : (
              <Sparkles className="h-4 w-4" aria-hidden="true" />
            )}
            {creating ? 'Creating…' : 'Create project'}
          </Button>
        </div>
      </div>

      {/* 402 upgrade prompt */}
      <Dialog open={upgrade.open} onOpenChange={(open) => setUpgrade((u) => ({ ...u, open }))}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Project limit reached</DialogTitle>
            <DialogDescription>{upgrade.message}</DialogDescription>
          </DialogHeader>
          <DialogFooter className="flex-col gap-2 sm:flex-row">
            <Button
              variant="outline"
              onClick={() => {
                setUpgrade((u) => ({ ...u, open: false }))
                navigate('/pricing')
              }}
            >
              View pricing
            </Button>
            <Button
              onClick={() => {
                setUpgrade((u) => ({ ...u, open: false }))
                navigate('/billing')
              }}
            >
              Upgrade
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
