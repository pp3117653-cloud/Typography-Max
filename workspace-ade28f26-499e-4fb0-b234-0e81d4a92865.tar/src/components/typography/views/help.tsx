'use client'

import { useEffect, useState, type FormEvent } from 'react'
import {
  ArrowRight,
  Check,
  Clipboard,
  Film,
  LayoutTemplate,
  Loader2,
  Mail,
  Scale,
  Tag,
} from 'lucide-react'
import { toast } from 'sonner'
import { navigate } from '@/hooks/use-hash-route'
import { useSession } from '@/hooks/use-session'
import { apiSend, ApiError } from '@/lib/api-client'
import { Alert, AlertDescription } from '@/components/ui/alert'
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion'
import { Button } from '@/components/ui/button'
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Separator } from '@/components/ui/separator'
import { Textarea } from '@/components/ui/textarea'

const SUPPORT_EMAIL = 'support@typography.app'

const FAQ_ITEMS: { question: string; answer: string }[] = [
  {
    question: 'What can I do on the Free plan?',
    answer:
      'Everything you need to try the product: the full editor, all standard templates, audio upload and preview, AI writing tools (limited), 3 saved projects and 5 video exports per month at 720p. Paid plans raise the limits, unlock premium templates and remove the watermark.',
  },
  {
    question: 'Will my videos have a watermark?',
    answer:
      'Free-plan exports include a small Typography watermark. Creator, Pro and Agency exports are watermark-free — you can see the exact difference on the pricing page before upgrading.',
  },
  {
    question: 'What video formats and sizes can I export?',
    answer:
      'Every project exports as an MP4 in the aspect ratio you pick in the editor: 9:16 vertical for Reels, Shorts and TikTok, 1:1 square, or 16:9 wide. Resolution depends on your plan — 720p on Free, 1080p on Creator, and up to 4K on Pro and Agency.',
  },
  {
    question: "Can I use commercial music or someone else's lyrics?",
    answer:
      'Only if you own the rights or have a proper license. Typography does not host or license commercial music, and we cannot clear rights for you. You upload your own audio and type your own text, so the responsibility for using that material — including any claims or takedowns — stays with you. See “Copyright & audio use” below.',
  },
  {
    question: 'What fonts are available, and are they licensed for commercial use?',
    answer:
      'We ship 12 open-source Google Fonts covered by the SIL Open Font License, which permits both personal and commercial use. Any of them can be used in videos you monetize on a paid plan.',
  },
  {
    question: 'How many exports do I get, and when do limits reset?',
    answer:
      'Exports reset at the start of each billing period: 5 per month on Free, 30 on Creator, 100 on Pro and 500 on Agency. Project limits work the same way (3 / 25 / 100 / 500). Your current usage is always visible on the Billing & usage page.',
  },
  {
    question: 'Which browser should I use?',
    answer:
      'Typography works best in Chrome or Edge. Video export uses your browser’s built-in encoder, so keep the tab open — and visible — while an export runs. We show live progress so you know when it’s safe to close.',
  },
  {
    question: 'How do I delete my account and my data?',
    answer:
      'Go to Settings → Danger zone → Delete account. Deletion permanently removes your account, all projects, exports and uploaded files — there is no undo. If you just want a fresh start, you can also delete individual projects from the dashboard.',
  },
]

const QUICK_LINKS: { title: string; description: string; to: string; icon: typeof Film }[] = [
  {
    title: 'Browse templates',
    description: 'Start from a ready-made design.',
    to: '/templates',
    icon: LayoutTemplate,
  },
  {
    title: 'View pricing',
    description: 'Compare plans and limits.',
    to: '/pricing',
    icon: Tag,
  },
  {
    title: 'Create a video',
    description: 'Open the editor and try it free.',
    to: '/editor/draft',
    icon: Film,
  },
]

function SupportEmailRow() {
  async function copyEmail() {
    try {
      await navigator.clipboard.writeText(SUPPORT_EMAIL)
      toast.success('Copied')
    } catch {
      toast.error(`Could not copy — the address is ${SUPPORT_EMAIL}`)
    }
  }

  return (
    <div className="flex flex-wrap items-center justify-between gap-3 rounded-lg border border-border bg-card px-4 py-3">
      <p className="flex items-center gap-2 text-sm">
        <Mail className="h-4 w-4 text-brand" aria-hidden="true" />
        <span className="text-muted-foreground">Prefer email?</span>{' '}
        <span className="font-medium">{SUPPORT_EMAIL}</span>
      </p>
      <Button type="button" variant="outline" size="sm" onClick={copyEmail}>
        <Clipboard className="h-4 w-4" aria-hidden="true" />
        Copy
      </Button>
    </div>
  )
}

function ContactForm() {
  const { user } = useSession()
  const [email, setEmail] = useState('')
  const [subject, setSubject] = useState('')
  const [message, setMessage] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [sending, setSending] = useState(false)
  const [sent, setSent] = useState(false)

  // Prefill the email once the session loads, without overwriting edits.
  useEffect(() => {
    if (user?.email) setEmail((current) => current || user.email)
  }, [user])

  async function handleSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault()
    if (sending) return
    setError(null)

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
      setError('Please enter a valid email address.')
      return
    }
    if (subject.trim().length < 2) {
      setError('Please add a short subject.')
      return
    }
    if (message.trim().length < 10) {
      setError('Please describe your question (at least 10 characters).')
      return
    }

    setSending(true)
    try {
      await apiSend<{ ok: boolean }>('POST', '/api/contact', {
        email: email.trim(),
        subject: subject.trim(),
        message: message.trim(),
      })
      toast.success('Message sent')
      setSent(true)
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not send your message. Please try again.')
    } finally {
      setSending(false)
    }
  }

  if (sent) {
    return (
      <div role="status" className="flex flex-col items-center py-6 text-center">
        <span className="flex h-12 w-12 items-center justify-center rounded-full bg-brand-soft">
          <Check className="h-6 w-6 text-brand" aria-hidden="true" />
        </span>
        <h3 className="mt-4 font-display text-lg font-semibold">Message sent</h3>
        <p className="mt-2 max-w-sm text-sm leading-relaxed text-muted-foreground">
          Thanks for reaching out — we&apos;ll reply to <span className="text-foreground">{email}</span>{' '}
          within 2 business days.
        </p>
        <Button
          type="button"
          variant="outline"
          className="mt-6"
          onClick={() => {
            setSent(false)
            setSubject('')
            setMessage('')
          }}
        >
          Send another message
        </Button>
      </div>
    )
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4" noValidate>
      <div className="grid gap-4 sm:grid-cols-2">
        <div className="space-y-2">
          <Label htmlFor="contact-email">Your email</Label>
          <Input
            id="contact-email"
            type="email"
            inputMode="email"
            autoComplete="email"
            placeholder="you@example.com"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            disabled={sending}
            required
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="contact-subject">Subject</Label>
          <Input
            id="contact-subject"
            type="text"
            placeholder="Billing, a bug, feedback…"
            value={subject}
            onChange={(e) => setSubject(e.target.value)}
            disabled={sending}
            maxLength={160}
            required
          />
        </div>
      </div>
      <div className="space-y-2">
        <Label htmlFor="contact-message">Message</Label>
        <Textarea
          id="contact-message"
          placeholder="How can we help?"
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          disabled={sending}
          rows={5}
          maxLength={4000}
          required
        />
      </div>

      {error && (
        <Alert variant="destructive" aria-live="polite">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      <div className="flex flex-wrap items-center justify-between gap-3">
        <Button type="submit" disabled={sending}>
          {sending && <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />}
          Send message
        </Button>
        <p className="text-xs text-muted-foreground">
          Messages are stored securely and answered within 2 business days.
        </p>
      </div>
    </form>
  )
}

export default function HelpView() {
  return (
    <div className="mx-auto max-w-4xl px-4 py-12 sm:px-6">
      {/* Hero */}
      <div className="text-center">
        <h1 className="font-display text-4xl font-bold tracking-tight sm:text-5xl">
          How can we help?
        </h1>
        <p className="mx-auto mt-4 max-w-xl text-muted-foreground">
          Answers to common questions, plus a direct line to the team.
        </p>
      </div>

      {/* Quick links */}
      <div className="mt-10 grid gap-4 sm:grid-cols-3">
        {QUICK_LINKS.map((link) => (
          <button
            key={link.to}
            type="button"
            onClick={() => navigate(link.to)}
            className="group rounded-lg border border-border bg-card p-5 text-left transition-colors hover:border-brand/50 hover:bg-accent/40 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
          >
            <link.icon className="h-5 w-5 text-brand" aria-hidden="true" />
            <p className="mt-3 flex items-center gap-1 font-medium">
              {link.title}
              <ArrowRight
                className="h-4 w-4 text-muted-foreground transition-transform group-hover:translate-x-0.5"
                aria-hidden="true"
              />
            </p>
            <p className="mt-1 text-sm text-muted-foreground">{link.description}</p>
          </button>
        ))}
      </div>

      {/* FAQ */}
      <section id="faq" className="mt-14 scroll-mt-20" aria-labelledby="faq-heading">
        <h2 id="faq-heading" className="font-display text-2xl font-semibold tracking-tight">
          Frequently asked questions
        </h2>
        <Card className="mt-5 gap-0 py-2">
          <CardContent className="px-6">
            <Accordion type="single" collapsible className="divide-y divide-border">
              {FAQ_ITEMS.map((item, index) => (
                <AccordionItem key={index} value={`faq-${index}`} className="border-b-0">
                  <AccordionTrigger className="py-4 text-left">
                    {item.question}
                  </AccordionTrigger>
                  <AccordionContent className="pb-4 text-sm leading-6 text-muted-foreground">
                    {item.answer}
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </CardContent>
        </Card>
      </section>

      {/* Copyright notice */}
      <section id="copyright" className="mt-14 scroll-mt-20" aria-labelledby="copyright-heading">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <Scale className="h-4 w-4 text-brand" aria-hidden="true" />
              Copyright &amp; audio use
            </CardTitle>
            <CardDescription>
              A quick word on rights, because it matters.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-3 text-sm leading-6 text-muted-foreground">
            <p>
              You must own or have licensed every piece of music, audio or lyric text you upload or
              type into Typography. We don&apos;t host, distribute or license commercial music, and
              we can&apos;t clear rights on your behalf.
            </p>
            <p>
              If you publish a video that uses audio or lyrics you don&apos;t control, you are
              responsible for any copyright claims, takedowns, royalty obligations or licensing
              costs that follow. The fonts we provide are open-source and safe for commercial use —
              your uploaded material is a different story.
            </p>
          </CardContent>
        </Card>
      </section>

      <Separator className="mt-14" />

      {/* Contact */}
      <section id="contact" className="mt-10 scroll-mt-20" aria-labelledby="contact-heading">
        <h2 id="contact-heading" className="font-display text-2xl font-semibold tracking-tight">
          Contact us
        </h2>
        <p className="mt-2 text-sm text-muted-foreground">
          Bug reports, billing questions, feature ideas — all welcome.
        </p>
        <Card className="mt-5">
          <CardContent>
            <ContactForm />
          </CardContent>
        </Card>
        <div className="mt-4">
          <SupportEmailRow />
        </div>
      </section>
    </div>
  )
}
