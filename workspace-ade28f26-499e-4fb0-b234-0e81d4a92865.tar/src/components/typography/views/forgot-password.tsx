'use client'

import { useState, type FormEvent } from 'react'
import { CheckCircle2, Loader2, TerminalSquare } from 'lucide-react'
import { toast } from 'sonner'
import { navigate } from '@/hooks/use-hash-route'
import { apiSend, ApiError } from '@/lib/api-client'
import { Logo } from '@/components/typography/app-shell'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Button } from '@/components/ui/button'
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'

interface ForgotResult {
  message: string
  devResetUrl: string | null
}

/** Shown only when the server reports that email delivery is not configured
 *  (development). It links straight to the reset URL so the flow is testable. */
function DevResetNotice({ url }: { url: string }) {
  return (
    <div className="mt-6 rounded-lg border border-brand/40 bg-brand-soft p-4 text-left">
      <p className="flex items-center gap-2 text-sm font-medium">
        <TerminalSquare className="h-4 w-4 text-brand" aria-hidden="true" />
        Development mode — email delivery is not configured
      </p>
      <p className="mt-1.5 text-sm text-muted-foreground">
        Use the link below to test the flow:
      </p>
      <Button
        type="button"
        variant="outline"
        className="mt-3 w-full border-brand/50"
        onClick={() => {
          window.location.href = url
        }}
      >
        Development mode: open reset link
      </Button>
    </div>
  )
}

export default function ForgotPasswordView() {
  const [email, setEmail] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)
  const [sent, setSent] = useState<ForgotResult | null>(null)

  async function handleSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault()
    if (loading) return
    setError(null)
    setLoading(true)
    try {
      const res = await apiSend<ForgotResult>('POST', '/api/auth/forgot-password', { email })
      setSent({ message: res.message, devResetUrl: res.devResetUrl ?? null })
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not send the reset link. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="mx-auto flex min-h-[calc(100dvh-16rem)] w-full max-w-md flex-col items-center justify-center px-4 py-12 sm:px-6">
      <div className="mb-8">
        <button
          type="button"
          onClick={() => navigate('/')}
          aria-label="Typography — home"
          className="rounded-md focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
        >
          <Logo />
        </button>
      </div>

      <Card className="w-full">
        {sent ? (
          <CardContent className="flex flex-col items-center pt-6" role="status">
            <span className="flex h-12 w-12 items-center justify-center rounded-full bg-brand-soft">
              <CheckCircle2 className="h-6 w-6 text-brand" aria-hidden="true" />
            </span>
            <h1 className="mt-4 font-display text-xl font-semibold">Check your email</h1>
            <p className="mt-2 text-center text-sm leading-relaxed text-muted-foreground">
              {sent.message}
            </p>

            {sent.devResetUrl && <DevResetNotice url={sent.devResetUrl} />}

            <button
              type="button"
              onClick={() => navigate('/login')}
              className="mt-6 text-sm font-medium text-brand hover:underline"
            >
              Back to sign in
            </button>
          </CardContent>
        ) : (
          <>
            <CardHeader className="text-center">
              <CardTitle className="font-display text-2xl">Reset your password</CardTitle>
              <CardDescription>
                Enter your email and we&apos;ll send you a link to choose a new password.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-4" noValidate>
                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    inputMode="email"
                    autoComplete="email"
                    placeholder="you@example.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    disabled={loading}
                    required
                  />
                </div>

                {error && (
                  <Alert variant="destructive" aria-live="polite">
                    <AlertDescription>{error}</AlertDescription>
                  </Alert>
                )}

                <Button type="submit" className="w-full" disabled={loading}>
                  {loading && <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />}
                  Send reset link
                </Button>
              </form>
            </CardContent>
          </>
        )}
      </Card>

      {!sent && (
        <p className="mt-6 text-center text-sm text-muted-foreground">
          Remembered it?{' '}
          <button
            type="button"
            onClick={() => navigate('/login')}
            className="font-medium text-brand hover:underline"
          >
            Back to sign in
          </button>
        </p>
      )}
    </div>
  )
}
