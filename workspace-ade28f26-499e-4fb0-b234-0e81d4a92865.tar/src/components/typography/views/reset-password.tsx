'use client'

import { useEffect, useState, type FormEvent, type ReactNode } from 'react'
import { Eye, EyeOff, Loader2, ShieldX } from 'lucide-react'
import { toast } from 'sonner'
import { navigate } from '@/hooks/use-hash-route'
import { useSession } from '@/hooks/use-session'
import { apiSend, ApiError } from '@/lib/api-client'
import { Logo } from '@/components/typography/app-shell'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Button } from '@/components/ui/button'
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'

function PasswordField({
  id,
  label,
  value,
  onChange,
  autoComplete,
  disabled,
  helperText,
}: {
  id: string
  label: string
  value: string
  onChange: (value: string) => void
  autoComplete?: string
  disabled?: boolean
  helperText?: string
}) {
  const [visible, setVisible] = useState(false)
  return (
    <div className="space-y-2">
      <Label htmlFor={id}>{label}</Label>
      <div className="relative">
        <Input
          id={id}
          type={visible ? 'text' : 'password'}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          autoComplete={autoComplete}
          disabled={disabled}
          required
          minLength={8}
          aria-describedby={helperText ? `${id}-helper` : undefined}
          className="pr-11"
        />
        <button
          type="button"
          onClick={() => setVisible((v) => !v)}
          aria-label={visible ? 'Hide password' : 'Show password'}
          className="absolute inset-y-0 right-0 flex w-10 items-center justify-center rounded-r-md text-muted-foreground transition-colors hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
        >
          {visible ? (
            <EyeOff className="h-4 w-4" aria-hidden="true" />
          ) : (
            <Eye className="h-4 w-4" aria-hidden="true" />
          )}
        </button>
      </div>
      {helperText && (
        <p id={`${id}-helper`} className="text-xs text-muted-foreground">
          {helperText}
        </p>
      )}
    </div>
  )
}

function readTokenFromHash(): string {
  if (typeof window === 'undefined') return ''
  const hash = window.location.hash
  return new URLSearchParams(hash.split('?')[1] || '').get('token') ?? ''
}

export default function ResetPasswordView() {
  const { refresh } = useSession()
  // The reset link looks like #/reset-password?token=xyz — read it once on mount,
  // and re-read if the hash changes while this view stays mounted (SPA navigation).
  const [token, setToken] = useState<string>(() => readTokenFromHash())

  const [password, setPassword] = useState('')
  const [confirmPassword, setConfirmPassword] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [linkProblem, setLinkProblem] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    const onHashChange = () => setToken(readTokenFromHash())
    window.addEventListener('hashchange', onHashChange)
    return () => window.removeEventListener('hashchange', onHashChange)
  }, [])

  async function handleSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault()
    if (loading) return
    setError(null)

    if (password.length < 8) {
      setError('Password must be at least 8 characters.')
      return
    }
    if (password !== confirmPassword) {
      setError('Passwords do not match.')
      return
    }

    setLoading(true)
    try {
      await apiSend<{ user: unknown }>('POST', '/api/auth/reset-password', {
        token,
        password,
      })
    } catch (err) {
      if (err instanceof ApiError && err.status === 400) {
        setLinkProblem(err.message)
      } else {
        setError(err instanceof ApiError ? err.message : 'Could not update your password. Please try again.')
      }
      setLoading(false)
      return
    }
    toast.success('Password updated')
    try {
      await refresh()
    } catch {
      // Session will refetch on navigation anyway.
    }
    navigate('/dashboard')
  }

  const shell = (children: ReactNode) => (
    <div className="mx-auto flex min-h-[calc(100dvh-16rem)] w-full max-w-md flex-col items-center justify-center px-4 py-12 sm:px-6">
      <div className="mb-8">
        <button
          type="button"
          onClick={() => navigate('/')}
          aria-label="Typography — home"
          className="rounded-md focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
        >
          <Logo />
        </button>
      </div>
      {children}
    </div>
  )

  if (!token || linkProblem) {
    return shell(
      <Card className="w-full">
        <CardContent className="flex flex-col items-center pt-6 text-center" role="alert">
          <span className="flex h-12 w-12 items-center justify-center rounded-full bg-destructive/10">
            <ShieldX className="h-6 w-6 text-destructive" aria-hidden="true" />
          </span>
          <h1 className="mt-4 font-display text-xl font-semibold">This reset link is invalid.</h1>
          <p className="mt-2 max-w-xs text-sm leading-relaxed text-muted-foreground">
            {linkProblem ??
              'It may be missing its token, malformed, or the page was opened without one.'}
          </p>
          <Button
            type="button"
            className="mt-6 w-full"
            onClick={() => navigate('/forgot-password')}
          >
            Request a new reset link
          </Button>
        </CardContent>
      </Card>
    )
  }

  return shell(
    <>
      <Card className="w-full">
        <CardHeader className="text-center">
          <CardTitle className="font-display text-2xl">Choose a new password</CardTitle>
          <CardDescription>Pick something you haven&apos;t used before.</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4" noValidate>
            <PasswordField
              id="new-password"
              label="New password"
              value={password}
              onChange={setPassword}
              autoComplete="new-password"
              disabled={loading}
              helperText="At least 8 characters"
            />
            <PasswordField
              id="confirm-password"
              label="Confirm password"
              value={confirmPassword}
              onChange={setConfirmPassword}
              autoComplete="new-password"
              disabled={loading}
            />

            {error && (
              <Alert variant="destructive" aria-live="polite">
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            <Button type="submit" className="w-full" disabled={loading}>
              {loading && <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />}
              Update password
            </Button>
          </form>
        </CardContent>
      </Card>

      <p className="mt-6 text-center text-sm text-muted-foreground">
        Didn&apos;t request this?{' '}
        <button
          type="button"
          onClick={() => navigate('/login')}
          className="font-medium text-brand hover:underline"
        >
          Back to sign in
        </button>
      </p>
    </>
  )
}
