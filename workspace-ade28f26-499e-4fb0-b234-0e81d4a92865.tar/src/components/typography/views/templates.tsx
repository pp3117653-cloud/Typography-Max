'use client'

// Templates gallery — public. Browse, search, favorite and preview the twelve
// designer styles; "Use this template" starts a project (or a guest draft).

import { useEffect, useMemo, useState } from 'react'
import {
  Crown,
  Eye,
  Heart,
  Loader2,
  LogIn,
  Search,
  SearchX,
  Sparkles,
} from 'lucide-react'
import { navigate } from '@/hooks/use-hash-route'
import { useSession } from '@/hooks/use-session'
import { apiGet, apiSend, ApiError } from '@/lib/api-client'
import {
  TEMPLATES,
  TEMPLATE_CATEGORIES,
  projectFromTemplate,
  type TemplateDef,
  type TemplateCategory,
} from '@/lib/typography/templates'
import { TemplatePreview } from '@/components/typography/preview/template-preview'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Skeleton } from '@/components/ui/skeleton'
import { toast } from 'sonner'
import { cn } from '@/lib/utils'

/** Guest favorites live in localStorage; signed-in favorites live in the API. */
const GUEST_FAV_KEY = 'typo-fav-templates'
/** Guest "Use this template" hands the project to the editor via this key. */
const DRAFT_KEY = 'typo-draft-project'

type CategoryFilter = 'all' | 'favorites' | TemplateCategory

function categoryLabel(id: TemplateCategory): string {
  return TEMPLATE_CATEGORIES.find((c) => c.id === id)?.label ?? id
}

function prettifyPreset(preset: string | undefined): string {
  if (!preset) return '—'
  return preset
    .replace(/([a-z])([A-Z])/g, '$1 $2')
    .replace(/^./, (c) => c.toUpperCase())
}

function isProjectLimit(err: unknown): err is ApiError {
  // The API answers plan-cap blocks with HTTP 402 + code 'PROJECT_LIMIT'.
  return err instanceof ApiError && err.status === 402
}

/* ------------------------------------------------------------------ */
/* Template card                                                       */
/* ------------------------------------------------------------------ */

function TemplateCard({
  template,
  favorited,
  onPreview,
  onUse,
  onToggleFavorite,
}: {
  template: TemplateDef
  favorited: boolean
  onPreview: (t: TemplateDef) => void
  onUse: (t: TemplateDef) => void
  onToggleFavorite: (t: TemplateDef) => void
}) {
  return (
    <Card
      className={cn(
        'relative gap-0 overflow-hidden py-0 transition-colors hover:border-brand/50',
        template.premium ? 'border-brand/40' : 'border-border'
      )}
    >
      <div className="flex h-64 items-center justify-center rounded-t-lg bg-card">
        <TemplatePreview template={template} className="h-full" />
      </div>

      <div className="space-y-2 p-4">
        <div className="flex items-center justify-between gap-2">
          <h3 className="font-medium leading-tight">{template.name}</h3>
          {template.premium ? (
            <Badge className="gap-1 bg-brand text-white">
              <Crown className="h-3 w-3" aria-hidden="true" /> Pro
            </Badge>
          ) : (
            <Badge variant="outline" className="text-muted-foreground">Free</Badge>
          )}
        </div>
        <p className="text-xs uppercase tracking-wide text-muted-foreground">
          {categoryLabel(template.category)}
        </p>
        <p className="line-clamp-2 min-h-10 text-sm text-muted-foreground">{template.description}</p>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" className="relative z-20 flex-1" onClick={() => onPreview(template)}>
            <Eye className="h-4 w-4" aria-hidden="true" /> Preview
          </Button>
          <Button size="sm" className="relative z-20 flex-1" onClick={() => onUse(template)}>
            <Sparkles className="h-4 w-4" aria-hidden="true" /> Use template
          </Button>
        </div>
      </div>

      {/* Whole-card click target (kept as a sibling so the heart stays a real button). */}
      <button
        type="button"
        onClick={() => onPreview(template)}
        aria-label={`Preview the ${template.name} template`}
        className="absolute inset-0 z-10 cursor-pointer rounded-lg focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-none"
      />

      <button
        type="button"
        onClick={() => onToggleFavorite(template)}
        aria-label={`${favorited ? 'Remove' : 'Add'} ${template.name} ${favorited ? 'from' : 'to'} favorites`}
        aria-pressed={favorited}
        className="absolute right-2.5 top-2.5 z-20 cursor-pointer rounded-full bg-background/70 p-2 text-foreground backdrop-blur-sm transition-colors hover:bg-background hover:text-brand"
      >
        <Heart
          className={cn('h-4 w-4', favorited && 'fill-brand text-brand')}
          aria-hidden="true"
        />
      </button>
    </Card>
  )
}

/* ------------------------------------------------------------------ */
/* View                                                                */
/* ------------------------------------------------------------------ */

export default function TemplatesView() {
  const { status } = useSession()
  const isAuthed = status === 'authenticated'

  const [search, setSearch] = useState('')
  const [category, setCategory] = useState<CategoryFilter>('all')
  const [favorites, setFavorites] = useState<Set<string>>(new Set())
  const [favoritesLoaded, setFavoritesLoaded] = useState(false)
  const [preview, setPreview] = useState<TemplateDef | null>(null)
  const [creating, setCreating] = useState(false)
  const [upgrade, setUpgrade] = useState<{ open: boolean; message: string }>({ open: false, message: '' })

  /* Load favorites — from the API when signed in, localStorage for guests. */
  useEffect(() => {
    if (status === 'loading') return
    let cancelled = false
    if (status === 'authenticated') {
      apiGet<{ ids: string[] }>('/api/templates/favorites')
        .then((res) => {
          if (cancelled) return
          setFavorites(new Set(Array.isArray(res.ids) ? res.ids : []))
          setFavoritesLoaded(true)
        })
        .catch(() => {
          // Favorites are cosmetic — never block the gallery on them.
          if (!cancelled) setFavoritesLoaded(true)
        })
    } else {
      try {
        const raw = window.localStorage.getItem(GUEST_FAV_KEY)
        const ids = raw ? JSON.parse(raw) : []
        setFavorites(new Set(Array.isArray(ids) ? ids.filter((x): x is string => typeof x === 'string') : []))
      } catch {
        setFavorites(new Set())
      }
      setFavoritesLoaded(true)
    }
    return () => {
      cancelled = true
    }
  }, [status])

  const toggleFavorite = async (template: TemplateDef) => {
    if (status === 'authenticated') {
      const prev = new Set(favorites)
      const optimistic = new Set(prev)
      if (optimistic.has(template.id)) optimistic.delete(template.id)
      else optimistic.add(template.id)
      setFavorites(optimistic)
      try {
        const res = await apiSend<{ favorited: boolean }>('POST', '/api/templates/favorites', {
          templateId: template.id,
        })
        setFavorites((current) => {
          const next = new Set(current)
          if (res.favorited) next.add(template.id)
          else next.delete(template.id)
          return next
        })
      } catch {
        setFavorites(prev)
        toast.error('Could not update favorites. Please try again.')
      }
      return
    }
    setFavorites((current) => {
      const next = new Set(current)
      if (next.has(template.id)) next.delete(template.id)
      else next.add(template.id)
      try {
        window.localStorage.setItem(GUEST_FAV_KEY, JSON.stringify([...next]))
      } catch {
        // Private mode / storage full — the in-memory toggle still works.
      }
      return next
    })
  }

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase()
    return TEMPLATES.filter((t) => {
      if (category === 'favorites' && !favorites.has(t.id)) return false
      if (category !== 'all' && category !== 'favorites' && t.category !== category) return false
      if (q) {
        const hay = `${t.name} ${t.description} ${categoryLabel(t.category)}`.toLowerCase()
        if (!hay.includes(q)) return false
      }
      return true
    })
  }, [search, category, favorites])

  /** Use a template: create a saved project, or stash a guest draft. */
  const startWithTemplate = async (template: TemplateDef) => {
    if (status === 'authenticated') {
      setCreating(true)
      try {
        const res = await apiSend<{ id: string }>('POST', '/api/projects', {
          name: `${template.name} video`,
          data: projectFromTemplate(template),
        })
        navigate(`/editor/${res.id}`)
      } catch (err) {
        if (isProjectLimit(err)) {
          setUpgrade({ open: true, message: err.message })
        } else {
          toast.error(err instanceof ApiError ? err.message : 'Could not create the project. Please try again.')
        }
      } finally {
        setCreating(false)
      }
      return
    }
    // Guest: hand the template project to the editor via localStorage.
    try {
      window.localStorage.setItem(DRAFT_KEY, JSON.stringify(projectFromTemplate(template)))
    } catch {
      // Storage unavailable — the editor falls back to a clean draft.
    }
    navigate('/editor/draft')
  }

  const chips: { id: CategoryFilter; label: string }[] = [
    { id: 'all', label: 'All' },
    { id: 'favorites', label: 'Favorites' },
    ...TEMPLATE_CATEGORIES.map((c) => ({ id: c.id as CategoryFilter, label: c.label })),
  ]

  return (
    <div className="mx-auto max-w-6xl px-4 py-10 sm:px-6 sm:py-14">
      {/* Hero */}
      <header className="max-w-2xl">
        <h1 className="font-display text-3xl font-bold sm:text-4xl">Templates</h1>
        <p className="mt-3 text-base text-muted-foreground">
          Start from a designer-built style, then make it yours. Design applies to your text — your words are
          never replaced.
        </p>
      </header>

      {/* Controls */}
      <div className="mt-8 space-y-4">
        <div className="relative max-w-md">
          <Search
            className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground"
            aria-hidden="true"
          />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search templates…"
            aria-label="Search templates"
            className="pl-9"
          />
        </div>
        <div className="-mx-1 flex gap-2 overflow-x-auto px-1 pb-2 scrollbar-slim" role="group" aria-label="Filter by category">
          {chips.map((chip) => {
            const active = category === chip.id
            return (
              <button
                key={chip.id}
                type="button"
                onClick={() => setCategory(chip.id)}
                aria-pressed={active}
                className={cn(
                  'shrink-0 cursor-pointer rounded-full border px-3.5 py-1.5 text-sm font-medium transition-colors',
                  active
                    ? 'border-brand bg-brand text-white'
                    : 'border-border text-muted-foreground hover:border-brand/50 hover:text-foreground'
                )}
              >
                {chip.label}
              </button>
            )
          })}
        </div>
      </div>

      {/* Grid */}
      {!favoritesLoaded && status === 'loading' ? (
        <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4" aria-busy="true">
          {Array.from({ length: 8 }).map((_, i) => (
            <Card key={i} className="gap-0 overflow-hidden py-0">
              <Skeleton className="h-64 w-full rounded-none" />
              <div className="space-y-2.5 p-4">
                <Skeleton className="h-4 w-1/2" />
                <Skeleton className="h-3 w-1/3" />
                <Skeleton className="h-8 w-full" />
              </div>
            </Card>
          ))}
        </div>
      ) : filtered.length === 0 && category === 'favorites' ? (
        <Card className="mt-8 border-dashed">
          <div className="flex flex-col items-center gap-3 py-14 text-center">
            <Heart className="h-8 w-8 text-muted-foreground" aria-hidden="true" />
            <p className="text-sm text-muted-foreground">No favorites yet — tap the heart on a template.</p>
          </div>
        </Card>
      ) : filtered.length === 0 ? (
        <Card className="mt-8 border-dashed">
          <div className="flex flex-col items-center gap-3 py-14 text-center">
            <SearchX className="h-8 w-8 text-muted-foreground" aria-hidden="true" />
            <p className="text-sm text-muted-foreground">
              No templates match “{search.trim()}”. Try a different word or category.
            </p>
            <Button
              variant="outline"
              onClick={() => {
                setSearch('')
                setCategory('all')
              }}
            >
              Clear filters
            </Button>
          </div>
        </Card>
      ) : (
        <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {filtered.map((t) => (
            <TemplateCard
              key={t.id}
              template={t}
              favorited={favorites.has(t.id)}
              onPreview={setPreview}
              onUse={(tpl) => void startWithTemplate(tpl)}
              onToggleFavorite={(tpl) => void toggleFavorite(tpl)}
            />
          ))}
        </div>
      )}

      {/* Preview dialog */}
      <Dialog open={!!preview} onOpenChange={(open) => !open && setPreview(null)}>
        <DialogContent className="gap-0 overflow-hidden p-0 sm:max-w-4xl">
          {preview && (
            <div className="grid max-h-[85vh] overflow-y-auto sm:grid-cols-2 sm:overflow-hidden">
              <div className="flex h-[40vh] items-center justify-center border-b border-border bg-card p-4 sm:h-[70vh] sm:border-b-0 sm:border-r">
                <TemplatePreview template={preview} className="h-full" />
              </div>
              <div className="flex max-h-[45vh] flex-col p-6 sm:max-h-[70vh] sm:overflow-y-auto scrollbar-slim">
                <DialogHeader>
                  <DialogTitle className="font-display text-xl">{preview.name}</DialogTitle>
                  <DialogDescription>{preview.description}</DialogDescription>
                </DialogHeader>

                <dl className="mt-5 space-y-2.5 text-sm">
                  <div className="flex items-center justify-between gap-4">
                    <dt className="text-muted-foreground">Category</dt>
                    <dd>{categoryLabel(preview.category)}</dd>
                  </div>
                  <div className="flex items-center justify-between gap-4">
                    <dt className="text-muted-foreground">Format</dt>
                    <dd>{preview.design.format === '9:16' ? '9:16 — vertical' : preview.design.format}</dd>
                  </div>
                  <div className="flex items-center justify-between gap-4">
                    <dt className="text-muted-foreground">Animation</dt>
                    <dd>{prettifyPreset(preview.design.animation?.preset)}</dd>
                  </div>
                </dl>

                {preview.premium && (
                  <div className="mt-5 flex items-start gap-2.5 rounded-md border border-brand/30 bg-brand-soft p-3 text-sm">
                    <Crown className="mt-0.5 h-4 w-4 shrink-0 text-brand" aria-hidden="true" />
                    <p>Included in Creator and above plans.</p>
                  </div>
                )}

                <div className="mt-auto space-y-3 pt-6">
                  <Button className="w-full" size="lg" onClick={() => void startWithTemplate(preview)} disabled={creating}>
                    {creating ? (
                      <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />
                    ) : (
                      <Sparkles className="h-4 w-4" aria-hidden="true" />
                    )}
                    {creating ? 'Creating project…' : 'Use this template'}
                  </Button>
                  {!isAuthed && (
                    <Button
                      variant="outline"
                      className="w-full"
                      onClick={() => navigate('/login')}
                    >
                      <LogIn className="h-4 w-4" aria-hidden="true" /> Sign in to save projects
                    </Button>
                  )}
                  <p className="text-center text-xs text-muted-foreground">
                    You can edit every scene after you start.
                  </p>
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* 402 upgrade prompt */}
      <Dialog open={upgrade.open} onOpenChange={(open) => setUpgrade((u) => ({ ...u, open }))}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Project limit reached</DialogTitle>
            <DialogDescription>{upgrade.message}</DialogDescription>
          </DialogHeader>
          <DialogFooter className="flex-col gap-2 sm:flex-row">
            <Button
              variant="outline"
              onClick={() => {
                setUpgrade((u) => ({ ...u, open: false }))
                navigate('/pricing')
              }}
            >
              View pricing
            </Button>
            <Button
              onClick={() => {
                setUpgrade((u) => ({ ...u, open: false }))
                navigate('/billing')
              }}
            >
              Upgrade
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
