'use client'

// Pricing view: plan cards + full feature comparison table. Upgrades connect
// to the real billing flow — which reports an honest "payment setup required"
// state while Stripe is not configured.

import { Check, Minus, HelpCircle } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Card, CardContent, CardFooter, CardHeader } from '@/components/ui/card'
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion'
import { navigate } from '@/hooks/use-hash-route'
import { useSession } from '@/hooks/use-session'
import { PLANS, type PlanDef } from '@/lib/typography/plans'
import { cn } from '@/lib/utils'

const COMPARISON_ROWS: { label: string; key: (plan: PlanDef) => string }[] = [
  { label: 'Monthly exports', key: (p) => `${p.exportsPerMonth}` },
  { label: 'Saved projects', key: (p) => `${p.maxProjects}` },
  { label: 'Watermark', key: (p) => (p.watermark ? 'On exports' : 'None') },
  { label: 'Max resolution', key: (p) => (p.maxResolution >= 2160 ? '4K (2160p)' : p.maxResolution >= 1080 ? 'Full HD (1080p)' : 'HD (720p)') },
  { label: 'All templates', key: (p) => (p.premiumTemplates ? 'Included' : 'Standard set') },
  { label: 'Brand colors & logo', key: (p) => (p.brandKit ? 'Included' : '—') },
  { label: 'Commercial use', key: (p) => (p.id === 'PRO' || p.id === 'AGENCY' ? 'Included' : 'Personal use') },
  { label: 'AI suggestions', key: (p) => (p.id === 'FREE' ? '15 / day' : '60 / day') },
  { label: 'Priority rendering', key: (p) => (p.id === 'AGENCY' ? 'Included' : '—') },
  { label: 'Team members', key: (p) => (p.id === 'AGENCY' ? 'Coming soon' : '—') },
]

export default function PricingView() {
  const { user, plan } = useSession()

  return (
    <div className="mx-auto max-w-6xl px-4 py-14 sm:px-6 sm:py-20">
      {/* Header */}
      <div className="mx-auto max-w-2xl text-center">
        <Badge variant="outline" className="border-brand/40 text-brand">
          Pricing
        </Badge>
        <h1 className="mt-4 font-display text-4xl font-bold tracking-tight sm:text-5xl">
          Simple pricing that <span className="text-brand-gradient">scales with you</span>
        </h1>
        <p className="mt-4 text-base leading-relaxed text-muted-foreground sm:text-lg">
          Start free, upgrade when your content demands it. Every plan includes the full editor,
          all fonts and every animation.
        </p>
      </div>

      {/* Plan cards */}
      <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-4" role="list">
        {PLANS.map((p, idx) => {
          const isCurrent = user?.plan === p.id
          const prevPlan = idx > 0 ? PLANS[idx - 1] : undefined
          return (
            <Card
              key={p.id}
              role="listitem"
              className={cn(
                'relative flex flex-col border-border/70',
                p.highlight && 'border-brand/70 shadow-brand',
                isCurrent && 'ring-1 ring-brand/60'
              )}
            >
              {p.highlight && (
                <span className="absolute -top-3 left-1/2 -translate-x-1/2 rounded-full bg-brand px-3 py-1 text-[11px] font-semibold text-white">
                  Most popular
                </span>
              )}
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <h2 className="font-display text-lg font-semibold">{p.name}</h2>
                  {isCurrent && <Badge className="bg-brand/15 text-brand">Current</Badge>}
                </div>
                <div className="mt-2 flex items-baseline gap-1">
                  <span className="font-display text-3xl font-bold">{p.priceLabel}</span>
                  {p.priceValue > 0 && <span className="text-sm text-muted-foreground">/month</span>}
                </div>
                {p.priceValue > 0 && (
                  <p className="mt-1 text-xs text-muted-foreground">
                    ≈ ₹{Math.round(p.priceValue / 30)}/day · billed monthly
                  </p>
                )}
                <p className="mt-1.5 text-xs leading-relaxed text-muted-foreground">{p.tagline}</p>
              </CardHeader>
              <CardContent className="flex-1">
                {prevPlan && (
                  <p className="mb-3 text-xs font-medium text-muted-foreground">
                    Everything in {prevPlan.name}, plus:
                  </p>
                )}
                <ul className="space-y-2">
                  {p.features.slice(0, 6).map((f) => (
                    <li key={f.label} className="flex items-start gap-2 text-sm">
                      {f.included ? (
                        <Check className="mt-0.5 h-4 w-4 shrink-0 text-emerald-400" aria-hidden="true" />
                      ) : (
                        <Minus className="mt-0.5 h-4 w-4 shrink-0 text-muted-foreground/50" aria-hidden="true" />
                      )}
                      <span className={cn(f.included ? 'text-foreground/90' : 'text-muted-foreground/60')}>
                        {f.label}
                        {f.soon && <span className="ml-1 text-[10px] uppercase tracking-wide text-brand">(soon)</span>}
                      </span>
                    </li>
                  ))}
                </ul>
              </CardContent>
              <CardFooter>
                {isCurrent ? (
                  <Button variant="secondary" className="w-full" disabled aria-disabled="true">
                    Your current plan
                  </Button>
                ) : p.priceValue === 0 ? (
                  <Button
                    variant="outline"
                    className="w-full"
                    onClick={() => navigate(user ? '/editor/draft' : '/signup')}
                  >
                    {user ? 'Start a free video' : 'Create free account'}
                  </Button>
                ) : (
                  <Button
                    className={cn('w-full', !p.highlight && 'bg-secondary text-secondary-foreground hover:bg-secondary/80')}
                    variant={p.highlight ? 'default' : 'secondary'}
                    onClick={() => navigate(user ? '/billing' : '/signup')}
                  >
                    Upgrade to {p.name}
                  </Button>
                )}
              </CardFooter>
            </Card>
          )
        })}
      </div>

      <p className="mt-6 text-center text-xs text-muted-foreground">
        Prices in INR, billed monthly. Cancel anytime. Payments are processed securely by Stripe —
        we never see or store your card details.
      </p>

      {/* Comparison table */}
      <section className="mt-16" aria-labelledby="comparison-heading">
        <h2 id="comparison-heading" className="font-display text-2xl font-bold tracking-tight">
          Compare every plan
        </h2>
        <div className="mt-5 overflow-x-auto rounded-lg border border-border/70 scrollbar-slim">
          <table className="w-full min-w-[640px] border-collapse text-sm">
            <caption className="sr-only">Feature comparison of all Typography plans</caption>
            <thead>
              <tr className="border-b border-border/70 bg-card">
                <th scope="col" className="px-4 py-3 text-left font-medium text-muted-foreground">
                  Feature
                </th>
                {PLANS.map((p) => (
                  <th
                    scope="col"
                    key={p.id}
                    className={cn('px-4 py-3 text-center font-medium', p.highlight && 'text-brand')}
                  >
                    {p.name}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {COMPARISON_ROWS.map((row, i) => (
                <tr key={row.label} className={cn('border-b border-border/40', i % 2 === 1 && 'bg-card/40')}>
                  <th scope="row" className="px-4 py-2.5 text-left font-normal text-foreground/90">
                    {row.label}
                  </th>
                  {PLANS.map((p) => (
                    <td key={p.id} className="px-4 py-2.5 text-center text-muted-foreground">
                      {row.key(p)}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <p className="mt-3 text-xs text-muted-foreground">
          Team members and client spaces are in active development for the Agency plan.
        </p>
      </section>

      {/* Pricing FAQ */}
      <section className="mx-auto mt-16 max-w-3xl" aria-labelledby="pricing-faq">
        <h2 id="pricing-faq" className="flex items-center gap-2 font-display text-2xl font-bold tracking-tight">
          <HelpCircle className="h-5 w-5 text-brand" aria-hidden="true" />
          Pricing questions
        </h2>
        <Accordion type="single" collapsible className="mt-5">
          <AccordionItem value="q1">
            <AccordionTrigger>Can I use Typography for free?</AccordionTrigger>
            <AccordionContent className="text-muted-foreground">
              Yes — the free plan includes 5 exports per month with a small watermark, 3 saved
              projects and the complete editor. No credit card required.
            </AccordionContent>
          </AccordionItem>
          <AccordionItem value="q2">
            <AccordionTrigger>What happens when I hit my export limit?</AccordionTrigger>
            <AccordionContent className="text-muted-foreground">
              Your counter resets on the first day of each month. You can upgrade at any time for
              more exports — your projects and settings stay exactly the same.
            </AccordionContent>
          </AccordionItem>
          <AccordionItem value="q3">
            <AccordionTrigger>Can I cancel anytime?</AccordionTrigger>
            <AccordionContent className="text-muted-foreground">
              Yes. Plans are month-to-month with no lock-in. Contact support from the Help page and
              we&apos;ll process your cancellation.
            </AccordionContent>
          </AccordionItem>
          <AccordionItem value="q4">
            <AccordionTrigger>Do you offer refunds?</AccordionTrigger>
            <AccordionContent className="text-muted-foreground">
              If something isn&apos;t working as described, reach out within 14 days of your payment
              and we&apos;ll make it right.
            </AccordionContent>
          </AccordionItem>
        </Accordion>
      </section>

      {/* CTA */}
      <div className="panel-glass mt-16 rounded-lg px-6 py-10 text-center">
        <h2 className="font-display text-2xl font-bold">Still deciding?</h2>
        <p className="mx-auto mt-2 max-w-md text-sm text-muted-foreground">
          Make your first video on the free plan — it takes about two minutes and zero credit
          cards.
        </p>
        <div className="mt-5 flex flex-wrap justify-center gap-3">
          <Button size="lg" onClick={() => navigate('/editor/draft')}>
            Create your first video
          </Button>
          <Button size="lg" variant="outline" onClick={() => navigate('/help')}>
            Talk to us
          </Button>
        </div>
      </div>
    </div>
  )
}
