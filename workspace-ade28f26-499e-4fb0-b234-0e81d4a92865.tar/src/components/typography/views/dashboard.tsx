'use client'

// Dashboard — signed-in home: usage strip, projects grid and export history.

import { useEffect, useState } from 'react'
import { useQuery, useQueryClient } from '@tanstack/react-query'
import { format, formatDistanceToNow } from 'date-fns'
import {
  AlertTriangle,
  CheckCircle2,
  Clock,
  Copy,
  Crown,
  Download,
  FilePlus,
  FileText,
  Film,
  FolderOpen,
  LayoutTemplate,
  Loader2,
  MoreHorizontal,
  Pencil,
  Plus,
  RefreshCw,
  Sparkles,
  Trash2,
  X,
} from 'lucide-react'
import { navigate } from '@/hooks/use-hash-route'
import { useSession, useUsage } from '@/hooks/use-session'
import { apiGet, apiSend, ApiError } from '@/lib/api-client'
import type { ProjectSummary, ExportJobView } from '@/lib/typography/types'
import { ProjectThumb } from '@/components/typography/preview/project-thumb'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { Input } from '@/components/ui/input'
import { Progress } from '@/components/ui/progress'
import { Skeleton } from '@/components/ui/skeleton'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { toast } from 'sonner'
import { cn } from '@/lib/utils'

/* ------------------------------------------------------------------ */
/* Helpers                                                             */
/* ------------------------------------------------------------------ */

function errMessage(err: unknown): string {
  return err instanceof ApiError ? err.message : 'Something went wrong. Please try again.'
}

/**
 * The API answers plan-cap blocks with HTTP 402 + `code: 'PROJECT_LIMIT'`.
 * ApiError carries the status + server message, and 402 is only ever the
 * project cap on these endpoints — so it maps 1:1 to the upgrade prompt.
 */
function isProjectLimit(err: unknown): err is ApiError {
  return err instanceof ApiError && err.status === 402
}

function formatBytes(bytes: number | null): string {
  if (!bytes || bytes <= 0) return '—'
  const units = ['B', 'KB', 'MB', 'GB']
  let value = bytes
  let unit = 0
  while (value >= 1024 && unit < units.length - 1) {
    value /= 1024
    unit++
  }
  const rounded = value >= 100 || unit === 0 ? Math.round(value) : value.toFixed(1)
  return `${rounded} ${units[unit]}`
}

/** Shared 402 upgrade prompt (message comes straight from the API). */
function UpgradeDialog({
  open,
  message,
  onOpenChange,
}: {
  open: boolean
  message: string
  onOpenChange: (open: boolean) => void
}) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Project limit reached</DialogTitle>
          <DialogDescription>{message}</DialogDescription>
        </DialogHeader>
        <DialogFooter className="flex-col gap-2 sm:flex-row">
          <Button variant="outline" onClick={() => onOpenChange(false)}>Not now</Button>
          <Button
            variant="outline"
            onClick={() => {
              onOpenChange(false)
              navigate('/pricing')
            }}
          >
            View pricing
          </Button>
          <Button
            onClick={() => {
              onOpenChange(false)
              navigate('/billing')
            }}
          >
            Upgrade
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

/* ------------------------------------------------------------------ */
/* Usage strip                                                         */
/* ------------------------------------------------------------------ */

function UsageStrip() {
  const { usage, isLoading } = useUsage()
  const { plan } = useSession()

  if (isLoading || !usage) {
    return (
      <div className="grid gap-4 sm:grid-cols-3" aria-busy="true">
        <Card className="gap-0 py-4"><CardContent className="px-4"><Skeleton className="h-16 w-full" /></CardContent></Card>
        <Card className="gap-0 py-4"><CardContent className="px-4"><Skeleton className="h-16 w-full" /></CardContent></Card>
        <Card className="gap-0 py-4"><CardContent className="px-4"><Skeleton className="h-16 w-full" /></CardContent></Card>
      </div>
    )
  }

  const exportsPct = usage.exportsLimit > 0 ? Math.min(100, (usage.exportsUsed / usage.exportsLimit) * 100) : 0
  const projectsPct = usage.projectsLimit > 0 ? Math.min(100, (usage.projectsUsed / usage.projectsLimit) * 100) : 0
  const exportsNearLimit = usage.exportsLimit > 0 && usage.exportsUsed / usage.exportsLimit >= 0.8

  return (
    <div className="grid gap-4 sm:grid-cols-3">
      <Card className={cn('gap-0 py-4', exportsNearLimit && 'border-brand')}>
        <CardContent className="px-4">
          <div className="flex items-baseline justify-between gap-2">
            <span className="text-sm font-medium">Exports</span>
            <span className="text-sm tabular-nums text-muted-foreground">
              {usage.exportsUsed} / {usage.exportsLimit} <span className="hidden sm:inline">this month</span>
            </span>
          </div>
          <Progress value={exportsPct} className="mt-2.5 h-1.5" aria-label={`${usage.exportsUsed} of ${usage.exportsLimit} exports used`} />
          <p className="mt-2 text-xs text-muted-foreground">
            Resets {format(new Date(usage.resetsAt), 'd MMM')}
            {exportsNearLimit && (
              <>
                {' · '}
                <button onClick={() => navigate('/billing')} className="font-medium text-brand hover:underline">
                  Upgrade for more exports
                </button>
              </>
            )}
          </p>
        </CardContent>
      </Card>

      <Card className="gap-0 py-4">
        <CardContent className="px-4">
          <div className="flex items-baseline justify-between gap-2">
            <span className="text-sm font-medium">Projects</span>
            <span className="text-sm tabular-nums text-muted-foreground">
              {usage.projectsUsed} / {usage.projectsLimit}
            </span>
          </div>
          <Progress value={projectsPct} className="mt-2.5 h-1.5" aria-label={`${usage.projectsUsed} of ${usage.projectsLimit} projects used`} />
          <p className="mt-2 text-xs text-muted-foreground">
            {usage.projectsLimit - usage.projectsUsed > 0
              ? `${usage.projectsLimit - usage.projectsUsed} slot${usage.projectsLimit - usage.projectsUsed === 1 ? '' : 's'} free`
              : 'Project slots full — delete or upgrade'}
          </p>
        </CardContent>
      </Card>

      <Card className="gap-0 py-4">
        <CardContent className="flex h-full flex-col justify-between px-4">
          <div className="flex items-center justify-between gap-2">
            <span className="text-sm font-medium">Plan</span>
            <Badge className="bg-brand text-white">{plan.name}</Badge>
          </div>
          <div className="mt-2 flex items-center justify-between gap-2">
            <p className="text-xs text-muted-foreground">{usage.periodLabel}</p>
            <Button variant="link" size="sm" className="h-auto p-0 text-sm" onClick={() => navigate('/billing')}>
              Manage
            </Button>
          </div>
          {plan.id === 'FREE' && (
            <Button size="sm" className="mt-2.5 w-full" onClick={() => navigate('/billing')}>
              <Crown className="mr-1.5 h-3.5 w-3.5" aria-hidden="true" />
              Upgrade — no watermark, 1080p
            </Button>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

/* ------------------------------------------------------------------ */
/* Getting started (first-run checklist)                               */
/* ------------------------------------------------------------------ */

/**
 * Quiet first-run checklist. Steps are driven by real data only — step 3 is
 * a plain link because we don't track template visits. Dismissal is stored
 * per user; the card also hides itself for good once both core steps are done.
 */
function GettingStarted({
  userId,
  hasProjects,
  hasCompletedExport,
  firstProjectId,
}: {
  userId: string
  hasProjects: boolean
  hasCompletedExport: boolean
  firstProjectId: string | null
}) {
  const storageKey = `typo-gs-dismissed:${userId}`
  const [dismissed, setDismissed] = useState(() => {
    if (typeof window === 'undefined') return false
    try {
      return window.localStorage.getItem(storageKey) === '1'
    } catch {
      return false
    }
  })

  /* Both core steps done → persist the dismissal so the card never returns.
   * (Visibility itself is derived at render time below — no state needed.) */
  useEffect(() => {
    if (!hasProjects || !hasCompletedExport) return
    try {
      window.localStorage.setItem(storageKey, '1')
    } catch {
      // Storage unavailable — the render-time check below still hides the card.
    }
  }, [hasProjects, hasCompletedExport, storageKey])

  if (dismissed || (hasProjects && hasCompletedExport)) return null

  const dismiss = () => {
    try {
      window.localStorage.setItem(storageKey, '1')
    } catch {
      // Private mode / storage full — stays hidden until reload at worst.
    }
    setDismissed(true)
  }

  const step1Done = hasProjects
  const step2Done = hasCompletedExport

  return (
    <Card className="mt-8 gap-0 py-4">
      <CardContent className="px-4">
        <div className="flex items-center gap-2">
          <Sparkles className="h-4 w-4 text-brand" aria-hidden="true" />
          <span className="text-sm font-medium">Getting started</span>
          <Button
            variant="ghost"
            size="icon"
            className="ml-auto h-7 w-7"
            aria-label="Dismiss getting started guide"
            onClick={dismiss}
          >
            <X className="h-4 w-4" aria-hidden="true" />
          </Button>
        </div>

        <div className="mt-3 grid gap-3 sm:grid-cols-3">
          {/* 1 — Create your first project */}
          <div className="flex gap-2.5">
            {step1Done ? (
              <CheckCircle2 className="h-5 w-5 shrink-0 text-emerald-500" aria-hidden="true" />
            ) : (
              <span
                aria-hidden="true"
                className="flex size-5 shrink-0 items-center justify-center rounded-full border border-border text-[11px] text-muted-foreground"
              >
                1
              </span>
            )}
            <div className="min-w-0">
              <p className="text-sm">
                Create your first project
                {step1Done && <span className="sr-only"> (done)</span>}
              </p>
              <Button
                variant="link"
                size="sm"
                className="h-auto p-0 text-sm"
                onClick={() => navigate('/new?start=script')}
              >
                Start a video
              </Button>
            </div>
          </div>

          {/* 2 — Export your first video */}
          <div className="flex gap-2.5">
            {step2Done ? (
              <CheckCircle2 className="h-5 w-5 shrink-0 text-emerald-500" aria-hidden="true" />
            ) : (
              <span
                aria-hidden="true"
                className="flex size-5 shrink-0 items-center justify-center rounded-full border border-border text-[11px] text-muted-foreground"
              >
                2
              </span>
            )}
            <div className="min-w-0">
              <p className="text-sm">
                Export your first video
                {step2Done && <span className="sr-only"> (done)</span>}
              </p>
              <Button
                variant="link"
                size="sm"
                className="h-auto p-0 text-sm"
                onClick={() => navigate(firstProjectId ? `/editor/${firstProjectId}` : '/new?start=script')}
              >
                Open a project
              </Button>
            </div>
          </div>

          {/* 3 — Find your style (not trackable — plain link, no checkbox) */}
          <div className="flex gap-2.5">
            <LayoutTemplate className="h-5 w-5 shrink-0 text-muted-foreground" aria-hidden="true" />
            <div className="min-w-0">
              <p className="text-sm">Find your style</p>
              <Button
                variant="link"
                size="sm"
                className="h-auto p-0 text-sm"
                onClick={() => navigate('/templates')}
              >
                Browse templates
              </Button>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

/* ------------------------------------------------------------------ */
/* Project card                                                        */
/* ------------------------------------------------------------------ */

interface ProjectActions {
  onOpen: (p: ProjectSummary) => void
  onRename: (p: ProjectSummary) => void
  onDuplicate: (p: ProjectSummary) => void
  onDelete: (p: ProjectSummary) => void
}

function ProjectCard({ project, actions }: { project: ProjectSummary; actions: ProjectActions }) {
  const open = () => actions.onOpen(project)
  return (
    <Card className="group gap-0 overflow-hidden py-0 transition-colors hover:border-brand/50">
      <button type="button" onClick={open} className="block w-full cursor-pointer" aria-label={`Open ${project.name}`}>
        <ProjectThumb project={project.data} className="min-h-40 w-full rounded-t-lg object-cover" />
      </button>
      <div className="flex items-start justify-between gap-2 p-4">
        <button type="button" onClick={open} className="min-w-0 flex-1 cursor-pointer text-left">
          <span className="block truncate font-medium">{project.name}</span>
          <span className="mt-1 block text-xs text-muted-foreground">
            {project.sceneCount} {project.sceneCount === 1 ? 'scene' : 'scenes'} · {project.durationSec}s · updated{' '}
            {formatDistanceToNow(new Date(project.updatedAt), { addSuffix: true })}
          </span>
        </button>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="icon" className="shrink-0" aria-label="Project actions">
              <MoreHorizontal className="h-4 w-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-44">
            <DropdownMenuItem onClick={open}>
              <FolderOpen className="mr-2 h-4 w-4" /> Open
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => actions.onRename(project)}>
              <Pencil className="mr-2 h-4 w-4" /> Rename
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => actions.onDuplicate(project)}>
              <Copy className="mr-2 h-4 w-4" /> Duplicate
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={() => actions.onDelete(project)} className="text-destructive focus:text-destructive">
              <Trash2 className="mr-2 h-4 w-4" /> Delete
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </Card>
  )
}

/* ------------------------------------------------------------------ */
/* Export history row                                                  */
/* ------------------------------------------------------------------ */

function ExportStatusIcon({ job }: { job: ExportJobView }) {
  switch (job.status) {
    case 'processing':
      return <Loader2 className="h-5 w-5 shrink-0 animate-spin text-brand" aria-label="Processing" />
    case 'completed':
      return <CheckCircle2 className="h-5 w-5 shrink-0 text-emerald-500" aria-label="Completed" />
    case 'failed':
      return <AlertTriangle className="h-5 w-5 shrink-0 text-destructive" aria-label="Failed" />
    case 'expired':
      return <Clock className="h-5 w-5 shrink-0 text-muted-foreground" aria-label="Expired" />
  }
}

function ExportJobRow({ job, onDelete }: { job: ExportJobView; onDelete: (job: ExportJobView) => void }) {
  return (
    <li className="flex flex-wrap items-center gap-x-4 gap-y-2 py-4 first:pt-0 last:pb-0">
      <ExportStatusIcon job={job} />
      <div className="min-w-0 flex-1">
        <p className="truncate text-sm font-medium">{job.projectName}</p>
        <div className="mt-1 flex flex-wrap items-center gap-x-2 gap-y-1 text-xs text-muted-foreground">
          <Badge variant="outline" className="px-1.5 text-[11px]">{job.resolution}p</Badge>
          <Badge
            variant="outline"
            className={cn(
              'px-1.5 text-[11px]',
              job.watermark ? 'text-muted-foreground' : 'border-emerald-500/40 text-emerald-500'
            )}
          >
            {job.watermark ? 'Watermarked' : 'No watermark'}
          </Badge>
          {job.status === 'processing' && (
            <span className="tabular-nums" title={`Exporting — ${Math.round(job.progress)}%`}>
              {Math.round(job.progress)}% done
            </span>
          )}
          {job.status === 'completed' && (
            <span className="tabular-nums">
              {formatBytes(job.fileSizeBytes)} · {format(new Date(job.completedAt ?? job.createdAt), 'd MMM, p')}
            </span>
          )}
          {job.status === 'failed' && (
            <span className="block max-w-[16rem] truncate text-destructive sm:max-w-sm" title={job.error ?? undefined}>
              {job.error ?? 'Export failed'}
            </span>
          )}
          {job.status === 'expired' && <span>File expired (kept 7 days)</span>}
        </div>
        {job.status === 'failed' && job.projectId && (
          <button
            type="button"
            onClick={() => navigate(`/editor/${job.projectId}`)}
            className="mt-1.5 text-xs text-muted-foreground underline-offset-4 transition-colors hover:text-brand hover:underline"
          >
            Open the project to export again
          </button>
        )}
      </div>
      <div className="flex shrink-0 items-center gap-2">
        {job.status === 'completed' && (
          <Button asChild variant="secondary" size="sm">
            <a href={`/api/export-jobs/${job.id}/download`} download>
              <Download className="h-4 w-4" aria-hidden="true" /> Download
            </a>
          </Button>
        )}
        <Button variant="ghost" size="icon" aria-label={`Delete export of ${job.projectName}`} onClick={() => onDelete(job)}>
          <Trash2 className="h-4 w-4 text-muted-foreground" />
        </Button>
      </div>
    </li>
  )
}

/* ------------------------------------------------------------------ */
/* View                                                                */
/* ------------------------------------------------------------------ */

export default function DashboardView() {
  const { user, status } = useSession()
  const queryClient = useQueryClient()
  const isAuthed = status === 'authenticated'

  const [renaming, setRenaming] = useState<ProjectSummary | null>(null)
  const [renameValue, setRenameValue] = useState('')
  const [renameSaving, setRenameSaving] = useState(false)
  const [deleting, setDeleting] = useState<ProjectSummary | null>(null)
  const [deletingJob, setDeletingJob] = useState<ExportJobView | null>(null)
  const [upgrade, setUpgrade] = useState<{ open: boolean; message: string }>({ open: false, message: '' })
  const [tab, setTab] = useState('projects')

  const projectsQuery = useQuery({
    queryKey: ['projects'],
    queryFn: () => apiGet<{ projects: ProjectSummary[] }>('/api/projects'),
    enabled: isAuthed,
  })

  const jobsQuery = useQuery({
    queryKey: ['export-jobs'],
    queryFn: () => apiGet<{ jobs: ExportJobView[] }>('/api/export-jobs'),
    enabled: isAuthed,
    refetchInterval: (query) => {
      const jobs = query.state.data?.jobs ?? []
      return jobs.some((j) => j.status === 'processing') ? 4000 : false
    },
  })

  const refreshProjects = async () => {
    await Promise.all([
      queryClient.invalidateQueries({ queryKey: ['projects'] }),
      queryClient.invalidateQueries({ queryKey: ['usage'] }),
    ])
  }

  const projects = projectsQuery.data?.projects ?? []

  const startRename = (p: ProjectSummary) => {
    setRenameValue(p.name)
    setRenaming(p)
  }

  const submitRename = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!renaming) return
    const name = renameValue.trim()
    if (!name) {
      toast.error('Give your project a name.')
      return
    }
    setRenameSaving(true)
    try {
      await apiSend('PATCH', `/api/projects/${renaming.id}`, { name })
      toast.success('Project renamed')
      setRenaming(null)
      await refreshProjects()
    } catch (err) {
      toast.error(errMessage(err))
    } finally {
      setRenameSaving(false)
    }
  }

  const duplicate = async (p: ProjectSummary) => {
    try {
      await apiSend('POST', `/api/projects/${p.id}/duplicate`)
      toast.success(`Duplicated “${p.name}”`)
      await refreshProjects()
    } catch (err) {
      if (isProjectLimit(err)) {
        setUpgrade({ open: true, message: err.message })
        return
      }
      toast.error(errMessage(err))
    }
  }

  const confirmDelete = async () => {
    if (!deleting) return
    const target = deleting
    try {
      await apiSend('DELETE', `/api/projects/${target.id}`)
      toast.success(`Deleted “${target.name}”`)
      await refreshProjects()
    } catch (err) {
      toast.error(errMessage(err))
    } finally {
      setDeleting(null)
    }
  }

  const deleteExportJob = async () => {
    if (!deletingJob) return
    const target = deletingJob
    try {
      await apiSend('DELETE', `/api/export-jobs/${target.id}`)
      toast.success('Removed from history')
      await queryClient.invalidateQueries({ queryKey: ['export-jobs'] })
    } catch (err) {
      toast.error(errMessage(err))
    } finally {
      setDeletingJob(null)
    }
  }

  /* Guard: unauthenticated visitors (router normally redirects first). */
  if (status === 'unauthenticated') {
    return (
      <div className="mx-auto max-w-6xl px-4 py-16 sm:px-6">
        <Card>
          <CardContent className="flex flex-col items-center gap-4 py-12 text-center">
            <div className="rounded-full bg-brand-soft p-4">
              <Film className="h-7 w-7 text-brand" aria-hidden="true" />
            </div>
            <div>
              <h1 className="font-display text-2xl font-bold">Sign in to see your dashboard</h1>
              <p className="mt-1 text-sm text-muted-foreground">
                Your projects, usage and export history live here.
              </p>
            </div>
            <div className="flex flex-wrap justify-center gap-3">
              <Button onClick={() => navigate('/login')}>Sign in</Button>
              <Button variant="outline" onClick={() => navigate('/signup')}>Create a free account</Button>
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  const firstName = user?.name?.trim().split(/\s+/)[0] ?? ''
  const hasCompletedExport = jobsQuery.data?.jobs?.some((j) => j.status === 'completed') ?? false
  const listsLoaded = !projectsQuery.isLoading && !jobsQuery.isLoading
  const isFirstVisit = listsLoaded && projects.length === 0 && !hasCompletedExport

  return (
    <div className="mx-auto max-w-6xl px-4 py-10 sm:px-6 sm:py-12">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="font-display text-2xl font-bold sm:text-3xl">
            {isFirstVisit
              ? `Welcome to Typography${firstName ? `, ${firstName}` : ''}`
              : `Welcome back${firstName ? `, ${firstName}` : ''}`}
          </h1>
          <p className="mt-1 text-sm text-muted-foreground">
            {isFirstVisit
              ? 'Make your first animated video — it takes about two minutes.'
              : 'Pick up where you left off, or start something new.'}
          </p>
        </div>
        <Button onClick={() => navigate('/new')}>
          <Plus className="h-4 w-4" aria-hidden="true" /> New project
        </Button>
      </div>

      {/* Getting started (first-run checklist) */}
      {isAuthed && user && listsLoaded && (
        <GettingStarted
          key={user.id}
          userId={user.id}
          hasProjects={projects.length > 0}
          hasCompletedExport={hasCompletedExport}
          firstProjectId={projects[0]?.id ?? null}
        />
      )}

      {/* Usage */}
      <div className="mt-8">
        <UsageStrip />
      </div>

      {/* Tabs */}
      <Tabs value={tab} onValueChange={setTab} className="mt-8">
        <TabsList>
          <TabsTrigger value="projects">Projects</TabsTrigger>
          <TabsTrigger value="exports">Export history</TabsTrigger>
        </TabsList>

        <TabsContent value="projects" className="mt-6">
          {projectsQuery.isLoading ? (
            <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3" aria-busy="true">
              {Array.from({ length: 6 }).map((_, i) => (
                <Card key={i} className="gap-0 overflow-hidden py-0">
                  <Skeleton className="min-h-40 w-full rounded-none" />
                  <div className="space-y-2.5 p-4">
                    <Skeleton className="h-4 w-2/3" />
                    <Skeleton className="h-3 w-1/2" />
                  </div>
                </Card>
              ))}
            </div>
          ) : projectsQuery.isError ? (
            <Card className="border-dashed">
              <CardContent className="flex flex-col items-center gap-4 py-12 text-center">
                <AlertTriangle className="h-8 w-8 text-destructive" aria-hidden="true" />
                <p className="text-sm text-muted-foreground">We couldn&apos;t load your projects.</p>
                <Button variant="outline" onClick={() => projectsQuery.refetch()}>
                  <RefreshCw className="h-4 w-4" aria-hidden="true" /> Try again
                </Button>
              </CardContent>
            </Card>
          ) : projects.length === 0 ? (
            <Card className="border-dashed">
              <CardContent className="flex flex-col items-center gap-4 py-14 text-center">
                <div className="rounded-full bg-brand-soft p-4">
                  <Film className="h-7 w-7 text-brand" aria-hidden="true" />
                </div>
                <div>
                  <h2 className="font-display text-lg font-semibold">No projects yet</h2>
                  <p className="mx-auto mt-1 max-w-sm text-sm text-muted-foreground">
                    Create your first animated typography video — it takes about two minutes.
                  </p>
                </div>
                <div className="flex flex-wrap justify-center gap-2.5">
                  <Button onClick={() => navigate('/new?start=script')}>
                    <FileText className="h-4 w-4" aria-hidden="true" /> Start from a script
                  </Button>
                  <Button variant="outline" onClick={() => navigate('/new?start=template')}>
                    <LayoutTemplate className="h-4 w-4" aria-hidden="true" /> Use a template
                  </Button>
                  <Button variant="secondary" onClick={() => navigate('/new?start=blank')}>
                    <FilePlus className="h-4 w-4" aria-hidden="true" /> Start blank
                  </Button>
                </div>
              </CardContent>
            </Card>
          ) : (
            <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
              {projects.map((p) => (
                <ProjectCard
                  key={p.id}
                  project={p}
                  actions={{
                    onOpen: (proj) => navigate(`/editor/${proj.id}`),
                    onRename: startRename,
                    onDuplicate: duplicate,
                    onDelete: (proj) => setDeleting(proj),
                  }}
                />
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="exports" className="mt-6">
          {jobsQuery.isLoading ? (
            <Card className="gap-0 py-4">
              <CardContent className="space-y-6 px-6" aria-busy="true">
                {Array.from({ length: 3 }).map((_, i) => (
                  <div key={i} className="flex items-center gap-4">
                    <Skeleton className="h-5 w-5 rounded-full" />
                    <div className="flex-1 space-y-2">
                      <Skeleton className="h-4 w-1/3" />
                      <Skeleton className="h-3 w-1/2" />
                    </div>
                    <Skeleton className="h-8 w-24" />
                  </div>
                ))}
              </CardContent>
            </Card>
          ) : jobsQuery.isError ? (
            <Card className="border-dashed">
              <CardContent className="flex flex-col items-center gap-4 py-12 text-center">
                <AlertTriangle className="h-8 w-8 text-destructive" aria-hidden="true" />
                <p className="text-sm text-muted-foreground">We couldn&apos;t load your export history.</p>
                <Button variant="outline" onClick={() => jobsQuery.refetch()}>
                  <RefreshCw className="h-4 w-4" aria-hidden="true" /> Try again
                </Button>
              </CardContent>
            </Card>
          ) : (jobsQuery.data?.jobs ?? []).length === 0 ? (
            <Card className="border-dashed">
              <CardContent className="flex flex-col items-center gap-3 py-12 text-center">
                <Download className="h-8 w-8 text-muted-foreground" aria-hidden="true" />
                <p className="max-w-sm text-sm text-muted-foreground">
                  No exports yet — export a project and your MP4s will appear here for 7 days.
                </p>
                {projects.length > 0 ? (
                  <Button variant="outline" onClick={() => setTab('projects')}>
                    <FolderOpen className="h-4 w-4" aria-hidden="true" /> Open a project
                  </Button>
                ) : (
                  <Button variant="outline" onClick={() => navigate('/new?start=script')}>
                    Create your first video
                  </Button>
                )}
              </CardContent>
            </Card>
          ) : (
            <Card className="gap-0 py-4">
              <CardContent className="px-6">
                <ul className="divide-y divide-border">
                  {(jobsQuery.data?.jobs ?? []).map((job) => (
                    <ExportJobRow key={job.id} job={job} onDelete={(job) => setDeletingJob(job)} />
                  ))}
                </ul>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>

      {/* Rename dialog */}
      <Dialog open={!!renaming} onOpenChange={(open) => !open && setRenaming(null)}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Rename project</DialogTitle>
            <DialogDescription>Give this project a name you&apos;ll recognize later.</DialogDescription>
          </DialogHeader>
          <form onSubmit={submitRename}>
            <Input
              value={renameValue}
              onChange={(e) => setRenameValue(e.target.value)}
              maxLength={120}
              autoFocus
              aria-label="Project name"
            />
            <DialogFooter className="mt-4">
              <Button type="button" variant="ghost" onClick={() => setRenaming(null)}>Cancel</Button>
              <Button type="submit" disabled={renameSaving}>
                {renameSaving && <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />}
                Save changes
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Delete project confirm */}
      <AlertDialog open={!!deleting} onOpenChange={(open) => !open && setDeleting(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete project?</AlertDialogTitle>
            <AlertDialogDescription>
              This permanently removes “{deleting?.name}” and every scene in it. This can&apos;t be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={(e) => {
                // Keep the dialog open while the request runs; close on finish.
                e.preventDefault()
                void confirmDelete()
              }}
              className="bg-destructive text-white hover:bg-destructive/90"
            >
              Delete project
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Delete export record confirm */}
      <AlertDialog open={!!deletingJob} onOpenChange={(open) => !open && setDeletingJob(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Remove this export?</AlertDialogTitle>
            <AlertDialogDescription>
              “{deletingJob?.projectName}” will be removed from your history. The original project stays
              untouched. This can&apos;t be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={(e) => {
                e.preventDefault()
                void deleteExportJob()
              }}
              className="bg-destructive text-white hover:bg-destructive/90"
            >
              Remove
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* 402 upgrade prompt */}
      <UpgradeDialog
        open={upgrade.open}
        message={upgrade.message}
        onOpenChange={(open) => setUpgrade((u) => ({ ...u, open }))}
      />
    </div>
  )
}
