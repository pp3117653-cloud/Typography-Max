'use client'

import { useState, type FormEvent } from 'react'
import { Eye, EyeOff, Loader2 } from 'lucide-react'
import { toast } from 'sonner'
import { navigate } from '@/hooks/use-hash-route'
import { useSession } from '@/hooks/use-session'
import { apiSend, ApiError } from '@/lib/api-client'
import { Logo } from '@/components/typography/app-shell'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Button } from '@/components/ui/button'
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'

function PasswordField({
  id,
  label,
  value,
  onChange,
  autoComplete,
  disabled,
  helperText,
}: {
  id: string
  label: string
  value: string
  onChange: (value: string) => void
  autoComplete?: string
  disabled?: boolean
  helperText?: string
}) {
  const [visible, setVisible] = useState(false)
  return (
    <div className="space-y-2">
      <Label htmlFor={id}>{label}</Label>
      <div className="relative">
        <Input
          id={id}
          type={visible ? 'text' : 'password'}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          autoComplete={autoComplete}
          disabled={disabled}
          required
          minLength={8}
          aria-describedby={helperText ? `${id}-helper` : undefined}
          className="pr-11"
        />
        <button
          type="button"
          onClick={() => setVisible((v) => !v)}
          aria-label={visible ? 'Hide password' : 'Show password'}
          className="absolute inset-y-0 right-0 flex w-10 items-center justify-center rounded-r-md text-muted-foreground transition-colors hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
        >
          {visible ? (
            <EyeOff className="h-4 w-4" aria-hidden="true" />
          ) : (
            <Eye className="h-4 w-4" aria-hidden="true" />
          )}
        </button>
      </div>
      {helperText && (
        <p id={`${id}-helper`} className="text-xs text-muted-foreground">
          {helperText}
        </p>
      )}
    </div>
  )
}

export default function SignupView() {
  const { refresh } = useSession()
  // returnTo preserves context when a guest hits an auth gate (e.g. export),
  // e.g. #/signup?returnTo=%2Feditor%2Fdraft
  const [returnTo] = useState<string | null>(() => {
    if (typeof window === 'undefined') return null
    const hash = window.location.hash
    return new URLSearchParams(hash.split('?')[1] || '').get('returnTo')
  })
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)

  async function handleSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault()
    if (loading) return
    setError(null)

    if (password.length < 8) {
      setError('Password must be at least 8 characters.')
      return
    }

    setLoading(true)
    try {
      await apiSend<{ user: unknown }>('POST', '/api/auth/register', {
        name: name.trim() || undefined,
        email,
        password,
      })
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not create your account. Please try again.')
      setLoading(false)
      return
    }
    toast.success('Account created — welcome to Typography!')
    try {
      await refresh()
    } catch {
      // Session will refetch on navigation anyway.
    }
    navigate(returnTo || '/dashboard')
  }

  return (
    <div className="mx-auto flex min-h-[calc(100dvh-16rem)] w-full max-w-md flex-col items-center justify-center px-4 py-12 sm:px-6">
      <div className="mb-8">
        <button
          type="button"
          onClick={() => navigate('/')}
          aria-label="Typography — home"
          className="rounded-md focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
        >
          <Logo />
        </button>
      </div>

      <Card className="w-full">
        <CardHeader className="text-center">
          <CardTitle className="font-display text-2xl">Create your account</CardTitle>
          <CardDescription>
            Turn scripts, quotes and lyrics into animated typography videos.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4" noValidate>
            <div className="space-y-2">
              <Label htmlFor="name">
                Name <span className="font-normal text-muted-foreground">(optional)</span>
              </Label>
              <Input
                id="name"
                type="text"
                autoComplete="name"
                placeholder="Your name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                disabled={loading}
                maxLength={80}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                inputMode="email"
                autoComplete="email"
                placeholder="you@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                disabled={loading}
                required
              />
            </div>

            <PasswordField
              id="password"
              label="Password"
              value={password}
              onChange={setPassword}
              autoComplete="new-password"
              disabled={loading}
              helperText="At least 8 characters"
            />

            {error && (
              <Alert variant="destructive" aria-live="polite">
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            <Button type="submit" className="w-full" disabled={loading}>
              {loading && <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />}
              Create account
            </Button>

            <p className="text-center text-xs text-muted-foreground">
              Free plan: 5 exports/month · No credit card required · Upgrade only when you need more.
            </p>
          </form>
        </CardContent>
      </Card>

      <p className="mt-6 text-center text-sm text-muted-foreground">
        Already have an account?{' '}
        <button
          type="button"
          onClick={() => navigate('/login')}
          className="font-medium text-brand hover:underline"
        >
          Sign in
        </button>
      </p>

      <p className="mt-4 max-w-xs text-center text-xs leading-relaxed text-muted-foreground">
        By creating an account you agree to our{' '}
        <button
          type="button"
          onClick={() => navigate('/terms')}
          className="text-brand hover:underline"
        >
          Terms
        </button>{' '}
        and{' '}
        <button
          type="button"
          onClick={() => navigate('/privacy')}
          className="text-brand hover:underline"
        >
          Privacy Policy
        </button>
        .
      </p>
    </div>
  )
}
