'use client'

import { useState } from 'react'
import { useQuery, useQueryClient } from '@tanstack/react-query'
import {
  BadgeCheck,
  CircleAlert,
  Crown,
  Droplets,
  Film,
  FlaskConical,
  FolderOpen,
  Info,
  Loader2,
  MonitorPlay,
  X,
} from 'lucide-react'
import { toast } from 'sonner'
import { navigate } from '@/hooks/use-hash-route'
import { useSession, useUsage } from '@/hooks/use-session'
import { apiGet, apiSend, ApiError } from '@/lib/api-client'
import { PLANS, formatINR, getPlan, planRank } from '@/lib/typography/plans'
import type { PlanId } from '@/lib/typography/types'
import { cn } from '@/lib/utils'
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { Progress } from '@/components/ui/progress'
import { Skeleton } from '@/components/ui/skeleton'

interface BillingStatus {
  configured: boolean
  reason: string | null
  devPlanSwitchEnabled: boolean
}

function formatDate(iso: string): string {
  const date = new Date(iso)
  if (Number.isNaN(date.getTime())) return iso
  return date.toLocaleDateString(undefined, { day: 'numeric', month: 'short', year: 'numeric' })
}

function CheckoutBanner({
  kind,
  onDismiss,
}: {
  kind: 'success' | 'cancelled'
  onDismiss: () => void
}) {
  const success = kind === 'success'
  return (
    <div
      role="status"
      className={cn(
        'flex items-start justify-between gap-4 rounded-lg border px-4 py-3 text-sm',
        success ? 'border-brand/40 bg-brand-soft' : 'border-border bg-card'
      )}
    >
      <div className="flex items-start gap-3">
        {success ? (
          <BadgeCheck className="mt-0.5 h-4 w-4 shrink-0 text-brand" aria-hidden="true" />
        ) : (
          <Info className="mt-0.5 h-4 w-4 shrink-0 text-muted-foreground" aria-hidden="true" />
        )}
        <div>
          {success ? (
            <p>
              Checkout completed. If your plan hasn&apos;t updated yet,{' '}
              <button
                type="button"
                onClick={() => navigate('/help')}
                className="font-medium text-brand hover:underline"
              >
                contact support
              </button>
              .
            </p>
          ) : (
            <p>Checkout cancelled.</p>
          )}
        </div>
      </div>
      <button
        type="button"
        onClick={onDismiss}
        aria-label="Dismiss"
        className="rounded-md p-1 text-muted-foreground transition-colors hover:text-foreground"
      >
        <X className="h-4 w-4" aria-hidden="true" />
      </button>
    </div>
  )
}

function DevPlanSwitcher({
  currentPlanId,
  onSwitched,
}: {
  currentPlanId: PlanId
  onSwitched: () => Promise<void>
}) {
  const queryClient = useQueryClient()
  const [busyPlan, setBusyPlan] = useState<PlanId | null>(null)

  async function switchPlan(planId: PlanId) {
    if (busyPlan) return
    setBusyPlan(planId)
    try {
      await apiSend<{ ok: boolean; plan: PlanId }>('POST', '/api/billing/dev-plan', { plan: planId })
      toast.success(`Development plan switched to ${getPlan(planId).name}`)
      await onSwitched()
      await queryClient.invalidateQueries({ queryKey: ['usage'] })
    } catch (err) {
      toast.error(err instanceof ApiError ? err.message : 'Could not switch plan.')
    } finally {
      setBusyPlan(null)
    }
  }

  return (
    <Card className="border-dashed border-amber-500/50 bg-amber-500/5">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-base">
          <FlaskConical className="h-4 w-4 text-amber-400" aria-hidden="true" />
          Development tools — test paid plan UIs
        </CardTitle>
        <CardDescription>
          Development only — for testing paid UI states. Never available in production. These
          buttons switch your plan instantly, without payment, so you can preview paid features.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="flex flex-wrap gap-2">
          {PLANS.map((p) => {
            const isCurrent = p.id === currentPlanId
            return (
              <Button
                key={p.id}
                type="button"
                variant={isCurrent ? 'secondary' : 'outline'}
                size="sm"
                disabled={isCurrent || busyPlan !== null}
                onClick={() => switchPlan(p.id)}
                aria-label={`Switch development plan to ${p.name}`}
              >
                {busyPlan === p.id && <Loader2 className="h-3.5 w-3.5 animate-spin" aria-hidden="true" />}
                {p.name}
                {isCurrent && <span className="text-xs text-muted-foreground">(current)</span>}
              </Button>
            )
          })}
        </div>
      </CardContent>
    </Card>
  )
}

function BillingSkeleton() {
  return (
    <div className="mx-auto max-w-6xl px-4 py-10 sm:px-6" aria-busy="true" aria-label="Loading billing">
      <Skeleton className="h-9 w-64" />
      <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {[0, 1, 2, 3].map((i) => (
          <Skeleton key={i} className="h-32 rounded-lg" />
        ))}
      </div>
      <div className="mt-10 grid gap-6 md:grid-cols-2 xl:grid-cols-4">
        {[0, 1, 2, 3].map((i) => (
          <Skeleton key={i} className="h-80 rounded-lg" />
        ))}
      </div>
    </div>
  )
}

export default function BillingView() {
  const { user, status, refresh, plan } = useSession()
  const { usage, isLoading: usageLoading } = useUsage()

  // Stripe redirects back with #/billing?checkout=success|cancelled
  const [banner, setBanner] = useState<'success' | 'cancelled' | null>(() => {
    if (typeof window === 'undefined') return null
    const qs = window.location.hash.split('?')[1] || ''
    const value = new URLSearchParams(qs).get('checkout')
    return value === 'success' ? 'success' : value === 'cancelled' ? 'cancelled' : null
  })
  const [paySetupMessage, setPaySetupMessage] = useState<string | null>(null)
  const [busyPlan, setBusyPlan] = useState<PlanId | null>(null)

  const billingStatus = useQuery({
    queryKey: ['billing-status'],
    queryFn: () => apiGet<BillingStatus>('/api/billing/checkout'),
    staleTime: 60_000,
  })

  function dismissBanner() {
    setBanner(null)
    if (typeof window !== 'undefined' && window.location.hash.includes('checkout=')) {
      // Strip the ?checkout= param so the banner doesn't reappear on refresh.
      window.history.replaceState(null, '', `${window.location.pathname}#/billing`)
    }
  }

  async function startCheckout(planId: PlanId) {
    if (busyPlan) return
    if (planId === 'FREE') return // free plan can't be checked out — handled via support
    setBusyPlan(planId)
    try {
      const res = await apiSend<{ url: string }>('POST', '/api/billing/checkout', { plan: planId })
      window.location.href = res.url
    } catch (err) {
      if (err instanceof ApiError && err.status === 501) {
        setPaySetupMessage(err.message)
      } else {
        toast.error(
          err instanceof ApiError ? err.message : 'Could not start checkout. Please try again.'
        )
      }
    } finally {
      setBusyPlan(null)
    }
  }

  if (!user) {
    if (status !== 'unauthenticated') return <BillingSkeleton />
    return (
      <div className="mx-auto max-w-6xl px-4 py-16 sm:px-6">
        <Card className="mx-auto max-w-md">
          <CardHeader className="text-center">
            <CardTitle className="font-display text-xl">Please sign in</CardTitle>
            <CardDescription>You must be signed in to view billing.</CardDescription>
          </CardHeader>
          <CardContent>
            <Button className="w-full" onClick={() => navigate('/login?returnTo=%2Fbilling')}>
              Sign in
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  const currentPlanId = plan.id
  const exportsPct =
    usage && usage.exportsLimit > 0
      ? Math.min(100, (usage.exportsUsed / usage.exportsLimit) * 100)
      : 0
  const projectsPct =
    usage && usage.projectsLimit > 0
      ? Math.min(100, (usage.projectsUsed / usage.projectsLimit) * 100)
      : 0

  return (
    <div className="mx-auto max-w-6xl px-4 py-10 sm:px-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-3xl font-bold tracking-tight">Billing &amp; usage</h1>
          <p className="mt-2 text-muted-foreground">Your plan, monthly usage and upgrade options.</p>
        </div>
        <Badge className="border-brand/40 bg-brand-soft px-3 py-1 text-sm text-brand">
          {plan.name} plan
        </Badge>
      </div>

      {banner && <div className="mt-6"><CheckoutBanner kind={banner} onDismiss={dismissBanner} /></div>}

      {/* Usage */}
      <section className="mt-10" aria-labelledby="usage-heading">
        <h2 id="usage-heading" className="font-display text-xl font-semibold">
          Usage{usage ? <span className="ml-2 text-sm font-normal text-muted-foreground">· {usage.periodLabel}</span> : null}
        </h2>
        {usageLoading && !usage ? (
          <div className="mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {[0, 1, 2, 3].map((i) => (
              <Skeleton key={i} className="h-32 rounded-lg" />
            ))}
          </div>
        ) : (
          <div className="mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <Card className="gap-3 py-5">
              <CardContent className="px-5">
                <p className="flex items-center gap-2 text-sm font-medium text-muted-foreground">
                  <Film className="h-4 w-4 text-brand" aria-hidden="true" />
                  Exports this month
                </p>
                <p className="mt-2 font-display text-2xl font-bold">
                  {usage ? usage.exportsUsed : '—'}
                  <span className="text-sm font-normal text-muted-foreground">
                    {' '}/ {usage ? usage.exportsLimit : '—'}
                  </span>
                </p>
                {usage && <Progress value={exportsPct} className="mt-3 h-1.5" />}
                <p className="mt-2 text-xs text-muted-foreground">
                  {usage
                    ? `${usage.exportsUsed} of ${usage.exportsLimit} used · resets ${formatDate(usage.resetsAt)}`
                    : ' '}
                </p>
              </CardContent>
            </Card>

            <Card className="gap-3 py-5">
              <CardContent className="px-5">
                <p className="flex items-center gap-2 text-sm font-medium text-muted-foreground">
                  <FolderOpen className="h-4 w-4 text-brand" aria-hidden="true" />
                  Projects
                </p>
                <p className="mt-2 font-display text-2xl font-bold">
                  {usage ? usage.projectsUsed : '—'}
                  <span className="text-sm font-normal text-muted-foreground">
                    {' '}/ {usage ? usage.projectsLimit : '—'}
                  </span>
                </p>
                {usage && <Progress value={projectsPct} className="mt-3 h-1.5" />}
                <p className="mt-2 text-xs text-muted-foreground">
                  {usage ? `${usage.projectsUsed} of ${usage.projectsLimit} saved projects` : ' '}
                </p>
              </CardContent>
            </Card>

            <Card className="gap-3 py-5">
              <CardContent className="px-5">
                <p className="flex items-center gap-2 text-sm font-medium text-muted-foreground">
                  <Droplets className="h-4 w-4 text-brand" aria-hidden="true" />
                  Watermark
                </p>
                <p className="mt-2 text-sm font-semibold">
                  {plan.watermark ? 'Watermark on exports' : 'No watermark'}
                </p>
                <p className="mt-2 text-xs text-muted-foreground">
                  {plan.watermark
                    ? 'Free plan exports include the Typography watermark.'
                    : `Included with the ${plan.name} plan.`}
                </p>
              </CardContent>
            </Card>

            <Card className="gap-3 py-5">
              <CardContent className="px-5">
                <p className="flex items-center gap-2 text-sm font-medium text-muted-foreground">
                  <MonitorPlay className="h-4 w-4 text-brand" aria-hidden="true" />
                  Max resolution
                </p>
                <p className="mt-2 text-sm font-semibold">
                  {plan.maxResolution >= 2160 ? 'Up to 4K' : `Up to ${plan.maxResolution}p`}
                </p>
                <p className="mt-2 text-xs text-muted-foreground">
                  Exports render at up to {plan.maxResolution}p short-side.
                </p>
              </CardContent>
            </Card>
          </div>
        )}
      </section>

      {/* Plans */}
      <section className="mt-12" aria-labelledby="plans-heading">
        <h2 id="plans-heading" className="font-display text-xl font-semibold">
          Plans
        </h2>
        <p className="mt-1 text-sm text-muted-foreground">
          Prices in INR per month. Upgrade any time — your limits apply immediately.
        </p>

        {billingStatus.data && !billingStatus.data.configured && (
          <Alert className="mt-4">
            <Info aria-hidden="true" />
            <AlertTitle>Checkout is not enabled on this server</AlertTitle>
            <AlertDescription>
              {billingStatus.data.reason ??
                'Stripe is not configured on this server.'}{' '}
              Choosing a paid plan will show the setup details instead of a payment page.
            </AlertDescription>
          </Alert>
        )}

        {/* Conversion hub for free users — honest pitch, reuses the same
            startCheckout (never fakes success). */}
        {plan.id === 'FREE' && (
          <Card className="mt-4 border-brand/50 bg-gradient-to-b from-brand/[0.07] to-transparent">
            <CardContent className="flex flex-col gap-4 p-5 sm:flex-row sm:items-center sm:justify-between">
              <div>
                <p className="flex items-center gap-2 font-display text-base font-semibold">
                  <Crown className="h-4 w-4 text-brand" aria-hidden="true" />
                  Unlock watermark-free 1080p exports
                </p>
                <p className="mt-1.5 text-sm text-muted-foreground">
                  Creator is ₹499/month (≈ ₹17/day): 30 exports, 25 projects, every template — cancel
                  anytime.
                </p>
              </div>
              <div className="flex shrink-0 gap-2">
                <Button onClick={() => startCheckout('CREATOR')} disabled={busyPlan !== null}>
                  {busyPlan === 'CREATOR' && <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />}
                  Upgrade to Creator
                </Button>
                <Button variant="outline" onClick={() => navigate('/pricing')}>
                  Compare plans
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        <div className="mt-6 grid gap-6 md:grid-cols-2 xl:grid-cols-4">
          {PLANS.map((p) => {
            const isCurrent = p.id === currentPlanId
            const isUpgrade = planRank(p.id) > planRank(currentPlanId)
            return (
              <Card
                key={p.id}
                className={cn(
                  'relative flex flex-col',
                  isCurrent && 'border-brand/60 shadow-brand',
                  p.highlight && !isCurrent && 'border-primary/40'
                )}
              >
                {p.highlight && !isCurrent && (
                  <Badge className="absolute -top-2.5 left-4">Most popular</Badge>
                )}
                <CardHeader>
                  <CardTitle className="flex items-center justify-between font-display text-lg">
                    {p.name}
                    {isCurrent && (
                      <Badge
                        variant="outline"
                        className="border-brand/40 bg-brand-soft text-brand"
                      >
                        Current plan
                      </Badge>
                    )}
                  </CardTitle>
                  <p className="mt-1">
                    <span className="font-display text-3xl font-bold">
                      {formatINR(p.priceValue)}
                    </span>
                    <span className="text-sm text-muted-foreground"> /month</span>
                  </p>
                  {p.priceValue > 0 && (
                    <p className="mt-1 text-xs text-muted-foreground">
                      ≈ ₹{Math.round(p.priceValue / 30)}/day
                    </p>
                  )}
                  <CardDescription>{p.tagline}</CardDescription>
                </CardHeader>
                <CardContent className="flex flex-1 flex-col">
                  <ul className="space-y-2.5 text-sm">
                    {p.features.map((f) => (
                      <li
                        key={f.label}
                        className={cn('flex items-start gap-2', !f.included && 'text-muted-foreground')}
                      >
                        {f.included ? (
                          <BadgeCheck className="mt-0.5 h-4 w-4 shrink-0 text-brand" aria-hidden="true" />
                        ) : (
                          <X className="mt-0.5 h-4 w-4 shrink-0 opacity-50" aria-hidden="true" />
                        )}
                        <span>
                          {f.label}
                          {f.soon ? ' — coming soon' : ''}
                        </span>
                      </li>
                    ))}
                  </ul>

                  <div className="mt-auto pt-6">
                    {isCurrent ? (
                      <Button type="button" variant="secondary" disabled className="w-full">
                        Current plan
                      </Button>
                    ) : p.id === 'FREE' ? (
                      <Button
                        type="button"
                        variant="outline"
                        className="w-full"
                        onClick={() => navigate('/help')}
                      >
                        Contact support
                      </Button>
                    ) : (
                      <Button
                        type="button"
                        className="w-full"
                        disabled={busyPlan !== null}
                        onClick={() => startCheckout(p.id)}
                      >
                        {busyPlan === p.id && (
                          <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />
                        )}
                        {isUpgrade ? `Upgrade to ${p.name}` : `Switch to ${p.name}`}
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>
            )
          })}
        </div>

        <p className="mt-6 flex items-start gap-2 text-sm text-muted-foreground">
          <CircleAlert className="mt-0.5 h-4 w-4 shrink-0" aria-hidden="true" />
          To cancel or change your subscription, contact support from the{' '}
          <button
            type="button"
            onClick={() => navigate('/help')}
            className="font-medium text-brand hover:underline"
          >
            Help page
          </button>
          .
        </p>
      </section>

      {billingStatus.data?.devPlanSwitchEnabled && (
        <section className="mt-12" aria-label="Development plan tools">
          <DevPlanSwitcher currentPlanId={currentPlanId} onSwitched={refresh} />
        </section>
      )}

      {/* Honest state when Stripe is not configured on this deployment */}
      <Dialog open={paySetupMessage !== null} onOpenChange={(open) => !open && setPaySetupMessage(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="font-display">Payment setup required</DialogTitle>
            <DialogDescription>
              Stripe is not configured on this server. This is a development deployment; see
              .env.example for the STRIPE_* variables needed to enable real checkout.
            </DialogDescription>
          </DialogHeader>
          {paySetupMessage && (
            <p className="rounded-md border border-border bg-muted/40 p-3 text-xs leading-relaxed text-muted-foreground">
              {paySetupMessage}
            </p>
          )}
          <DialogFooter>
            <Button type="button" onClick={() => setPaySetupMessage(null)}>
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
