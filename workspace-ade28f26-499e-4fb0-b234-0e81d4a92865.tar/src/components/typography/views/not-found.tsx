'use client'

// 404 — friendly dead end.

import { Home, LayoutTemplate } from 'lucide-react'
import { navigate } from '@/hooks/use-hash-route'
import { Button } from '@/components/ui/button'

export default function NotFoundView() {
  return (
    <div className="mx-auto flex min-h-[60vh] max-w-6xl flex-col items-center justify-center px-4 py-24 text-center sm:px-6">
      <p className="font-display text-7xl font-bold tracking-tight text-brand sm:text-8xl" aria-hidden="true">
        404
      </p>
      <h1 className="mt-4 font-display text-2xl font-bold sm:text-3xl">This page took a wrong turn.</h1>
      <p className="mt-2 max-w-md text-sm text-muted-foreground">
        The page you were looking for doesn&apos;t exist or may have moved.
      </p>
      <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
        <Button onClick={() => navigate('/')}>
          <Home className="h-4 w-4" aria-hidden="true" /> Home
        </Button>
        <Button variant="outline" onClick={() => navigate('/templates')}>
          <LayoutTemplate className="h-4 w-4" aria-hidden="true" /> Templates
        </Button>
      </div>
    </div>
  )
}
