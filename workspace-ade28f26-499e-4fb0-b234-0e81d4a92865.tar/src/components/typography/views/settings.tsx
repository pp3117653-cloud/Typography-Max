'use client'

import { useState, type FormEvent } from 'react'
import { Eye, EyeOff, Loader2, Save, ShieldAlert, User } from 'lucide-react'
import { toast } from 'sonner'
import { navigate } from '@/hooks/use-hash-route'
import { useSession } from '@/hooks/use-session'
import { apiSend, ApiError } from '@/lib/api-client'
import type { SessionUser } from '@/lib/typography/types'
import { Alert, AlertDescription } from '@/components/ui/alert'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Separator } from '@/components/ui/separator'
import { Skeleton } from '@/components/ui/skeleton'

function PasswordField({
  id,
  label,
  value,
  onChange,
  autoComplete,
  disabled,
}: {
  id: string
  label: string
  value: string
  onChange: (value: string) => void
  autoComplete?: string
  disabled?: boolean
}) {
  const [visible, setVisible] = useState(false)
  return (
    <div className="space-y-2">
      <Label htmlFor={id}>{label}</Label>
      <div className="relative">
        <Input
          id={id}
          type={visible ? 'text' : 'password'}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          autoComplete={autoComplete}
          disabled={disabled}
          required
          className="pr-11"
        />
        <button
          type="button"
          onClick={() => setVisible((v) => !v)}
          aria-label={visible ? 'Hide password' : 'Show password'}
          className="absolute inset-y-0 right-0 flex w-10 items-center justify-center rounded-r-md text-muted-foreground transition-colors hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
        >
          {visible ? (
            <EyeOff className="h-4 w-4" aria-hidden="true" />
          ) : (
            <Eye className="h-4 w-4" aria-hidden="true" />
          )}
        </button>
      </div>
    </div>
  )
}

function ProfileCard({ user, onSaved }: { user: SessionUser; onSaved: () => Promise<void> }) {
  const [name, setName] = useState(user.name ?? '')
  const [saving, setSaving] = useState(false)

  async function handleSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault()
    if (saving) return
    setSaving(true)
    try {
      await apiSend<{ ok: boolean }>('PATCH', '/api/account', { name: name.trim() })
      toast.success('Profile updated')
      await onSaved()
    } catch (err) {
      toast.error(err instanceof ApiError ? err.message : 'Could not save your profile. Please try again.')
    } finally {
      setSaving(false)
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-base">
          <User className="h-4 w-4 text-brand" aria-hidden="true" />
          Profile
        </CardTitle>
        <CardDescription>How your name appears across Typography.</CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="flex flex-col gap-3 sm:flex-row sm:items-end">
          <div className="flex-1 space-y-2">
            <Label htmlFor="profile-name">Name</Label>
            <Input
              id="profile-name"
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Your name"
              maxLength={80}
              disabled={saving}
            />
          </div>
          <Button type="submit" disabled={saving} className="sm:w-auto">
            {saving ? (
              <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />
            ) : (
              <Save className="h-4 w-4" aria-hidden="true" />
            )}
            Save
          </Button>
        </form>
      </CardContent>
    </Card>
  )
}

function EmailCard({ user }: { user: SessionUser }) {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-base">Email</CardTitle>
        <CardDescription>Your sign-in email.</CardDescription>
      </CardHeader>
      <CardContent>
        <p className="rounded-md border border-border bg-muted/40 px-3 py-2 text-sm">{user.email}</p>
        <p className="mt-2 text-xs text-muted-foreground">Contact support to change your email.</p>
      </CardContent>
    </Card>
  )
}

function PasswordCard() {
  const [currentPassword, setCurrentPassword] = useState('')
  const [newPassword, setNewPassword] = useState('')
  const [confirmPassword, setConfirmPassword] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [saving, setSaving] = useState(false)

  async function handleSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault()
    if (saving) return
    setError(null)

    if (newPassword.length < 8) {
      setError('New password must be at least 8 characters.')
      return
    }
    if (newPassword !== confirmPassword) {
      setError('New passwords do not match.')
      return
    }

    setSaving(true)
    try {
      await apiSend<{ ok: boolean }>('POST', '/api/account', { currentPassword, newPassword })
      toast.success('Password updated. Please sign in again with your new password.')
      setCurrentPassword('')
      setNewPassword('')
      setConfirmPassword('')
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not change your password. Please try again.')
    } finally {
      setSaving(false)
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-base">Password</CardTitle>
        <CardDescription>
          Changing your password signs out all sessions — including this one — so you&apos;ll sign
          in again with the new password.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4" noValidate>
          <PasswordField
            id="current-password"
            label="Current password"
            value={currentPassword}
            onChange={setCurrentPassword}
            autoComplete="current-password"
            disabled={saving}
          />
          <div className="grid gap-4 sm:grid-cols-2">
            <PasswordField
              id="settings-new-password"
              label="New password"
              value={newPassword}
              onChange={setNewPassword}
              autoComplete="new-password"
              disabled={saving}
            />
            <PasswordField
              id="settings-confirm-password"
              label="Confirm new password"
              value={confirmPassword}
              onChange={setConfirmPassword}
              autoComplete="new-password"
              disabled={saving}
            />
          </div>

          {error && (
            <Alert variant="destructive" aria-live="polite">
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          <Button type="submit" disabled={saving}>
            {saving && <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />}
            Update password
          </Button>
        </form>
      </CardContent>
    </Card>
  )
}

function PlanCard({ planName, priceLabel }: { planName: string; priceLabel: string }) {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-base">Plan</CardTitle>
        <CardDescription>Your current subscription and its limits.</CardDescription>
      </CardHeader>
      <CardContent className="flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <Badge className="border-brand/40 bg-brand-soft text-brand">{planName} plan</Badge>
          <span className="text-sm text-muted-foreground">
            {priceLabel === '₹0' ? 'Free forever' : `${priceLabel} / month`}
          </span>
        </div>
        <Button variant="outline" onClick={() => navigate('/billing')}>
          Manage billing
        </Button>
      </CardContent>
    </Card>
  )
}

function DangerZoneCard({ onDeleted }: { onDeleted: () => Promise<void> }) {
  const [open, setOpen] = useState(false)
  const [confirmText, setConfirmText] = useState('')
  const [deleting, setDeleting] = useState(false)

  async function handleDelete() {
    if (deleting) return
    setDeleting(true)
    try {
      await apiSend<{ ok: boolean }>('DELETE', '/api/account')
      setOpen(false)
      toast.success('Account deleted')
      await onDeleted()
      navigate('/')
    } catch (err) {
      toast.error(err instanceof ApiError ? err.message : 'Could not delete your account. Please try again.')
      setDeleting(false)
    }
  }

  return (
    <Card className="border-destructive/40">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-base text-destructive">
          <ShieldAlert className="h-4 w-4" aria-hidden="true" />
          Danger zone
        </CardTitle>
        <CardDescription>
          Permanently deletes your account, all projects, exports and uploaded files. This cannot
          be undone.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <AlertDialog
          open={open}
          onOpenChange={(next) => {
            setOpen(next)
            if (!next) setConfirmText('')
          }}
        >
          <AlertDialogTrigger asChild>
            <Button variant="destructive">Delete account</Button>
          </AlertDialogTrigger>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Delete your account?</AlertDialogTitle>
              <AlertDialogDescription>
                Permanently deletes your account, all projects, exports and uploaded files. This
                cannot be undone.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <div className="space-y-2">
              <Label htmlFor="delete-confirm">Type DELETE to confirm</Label>
              <Input
                id="delete-confirm"
                type="text"
                value={confirmText}
                onChange={(e) => setConfirmText(e.target.value)}
                placeholder="DELETE"
                autoComplete="off"
                disabled={deleting}
                aria-invalid={confirmText.length > 0 && confirmText !== 'DELETE'}
              />
            </div>
            <AlertDialogFooter>
              <AlertDialogCancel disabled={deleting}>Cancel</AlertDialogCancel>
              <AlertDialogAction
                disabled={confirmText !== 'DELETE' || deleting}
                onClick={(e) => {
                  e.preventDefault() // keep the dialog open until the request settles
                  handleDelete()
                }}
                className="bg-destructive text-white hover:bg-destructive/90"
              >
                {deleting && <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />}
                Permanently delete
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </CardContent>
    </Card>
  )
}

function SettingsSkeleton() {
  return (
    <div className="mx-auto max-w-3xl px-4 py-10 sm:px-6" aria-busy="true" aria-label="Loading settings">
      <Skeleton className="h-9 w-56" />
      <div className="mt-8 space-y-6">
        {[0, 1, 2, 3].map((i) => (
          <Skeleton key={i} className="h-40 rounded-lg" />
        ))}
      </div>
    </div>
  )
}

function SignInRequiredCard() {
  return (
    <div className="mx-auto max-w-3xl px-4 py-16 sm:px-6">
      <Card className="mx-auto max-w-md">
        <CardHeader className="text-center">
          <CardTitle className="font-display text-xl">Please sign in</CardTitle>
          <CardDescription>You must be signed in to view account settings.</CardDescription>
        </CardHeader>
        <CardContent>
          <Button className="w-full" onClick={() => navigate('/login?returnTo=%2Fsettings')}>
            Sign in
          </Button>
        </CardContent>
      </Card>
    </div>
  )
}

export default function SettingsView() {
  const { user, status, refresh, plan } = useSession()

  if (!user) {
    return status === 'unauthenticated' ? <SignInRequiredCard /> : <SettingsSkeleton />
  }

  return (
    <div className="mx-auto max-w-3xl px-4 py-10 sm:px-6">
      <h1 className="font-display text-3xl font-bold tracking-tight">Account settings</h1>
      <p className="mt-2 text-muted-foreground">
        Manage your profile, security, plan and account data.
      </p>

      <div className="mt-8 space-y-6">
        <ProfileCard user={user} onSaved={refresh} />
        <EmailCard user={user} />
        <PasswordCard />
        <PlanCard planName={plan.name} priceLabel={plan.priceLabel} />
        <Separator />
        <DangerZoneCard onDeleted={refresh} />
      </div>

      <p className="mt-8 text-xs text-muted-foreground">
        Need help with your account?{' '}
        <button type="button" onClick={() => navigate('/help')} className="text-brand hover:underline">
          Contact support
        </button>
      </p>
    </div>
  )
}
