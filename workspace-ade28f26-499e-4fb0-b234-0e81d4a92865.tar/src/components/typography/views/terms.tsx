'use client'

import type { ReactNode } from 'react'
import { navigate } from '@/hooks/use-hash-route'

function Section({ title, children }: { title: string; children: ReactNode }) {
  return (
    <section className="mt-10">
      <h2 className="font-display text-xl font-semibold tracking-tight">{title}</h2>
      <div className="mt-3 space-y-3 text-sm leading-6 text-muted-foreground">{children}</div>
    </section>
  )
}

export default function TermsView() {
  return (
    <div className="mx-auto max-w-3xl px-4 py-12 sm:px-6">
      <h1 className="font-display text-4xl font-bold tracking-tight">Terms of Service</h1>
      <p className="mt-2 text-sm text-muted-foreground">Last updated: January 2025</p>
      <p className="mt-6 text-base leading-7">
        These terms are a contract between you and Typography. By creating an account or using the
        service you agree to them. In short: be the copyright holder of what you upload, don&apos;t
        abuse the service, and the rest of this page explains the details in plain language.
      </p>

      <Section title="The service">
        <p>
          Typography is a web application that turns scripts, quotes and lyrics into animated
          typography videos. You create projects in the editor, optionally upload audio, and export
          the result as a video file. We host your projects and exports subject to the retention
          rules in our{' '}
          <button
            type="button"
            onClick={() => navigate('/privacy')}
            className="font-medium text-brand hover:underline"
          >
            Privacy Policy
          </button>
          .
        </p>
      </Section>

      <Section title="Your account">
        <p>
          You need an account to save projects and export videos. Keep your password safe — you are
          responsible for activity under your account. You must give an accurate email address so
          we can reach you about your account (for example password resets). You can delete your
          account at any time from Settings, which permanently removes your projects, exports and
          uploads.
        </p>
      </Section>

      <Section title="Acceptable use">
        <p>
          Don&apos;t use Typography to break the law or to harm the service. That includes
          uploading content that is illegal, harassing, or that infringes other people&apos;s
          rights; trying to bypass plan limits or access controls; reselling access to the service
          without an agreement; or attacking, overloading or reverse-engineering our systems. We
          may suspend accounts that put the service or other users at risk.
        </p>
      </Section>

      <Section title="Your content and copyright responsibility">
        <p>
          You keep ownership of everything you create and upload: your scripts, lyrics, images,
          audio and exported videos. By using the service you give us the limited permission we
          need to store that content, render it into video for you, and serve it back to you.
        </p>
        <p>
          <strong className="text-foreground">
            You must own or have a license for any audio, music or lyrics you use.
          </strong>{' '}
          Typography does not host, distribute or license commercial music, and it cannot clear
          rights for you. If you upload a popular song or type in someone else&apos;s lyrics, you
          are responsible for having the rights to do so — including any royalties, claims,
          takedowns or legal costs that result from publishing that video.
        </p>
      </Section>

      <Section title="Plans and billing">
        <p>
          The Free plan is available at no cost with monthly limits (currently 5 exports, 3 saved
          projects, 720p with watermark). Paid plans — Creator, Pro and Agency — are billed in
          Indian Rupees per month and raise those limits. Plan limits apply from the moment your
          subscription activates. Monthly usage counters reset at the start of each billing period.
        </p>
        <p>
          To cancel or change a subscription, contact support from the Help page. Cancellation
          stops future renewals; you keep access until the end of the paid period. We don&apos;t
          provide refunds for partial months, but if something went clearly wrong on our side,
          write to us and we&apos;ll make it right.
        </p>
      </Section>

      <Section title="Watermark and licensing">
        <p>
          Videos exported on the Free plan carry a small Typography watermark and are meant for
          personal, non-commercial use. Paid plans export without the watermark and include a
          commercial-use license for the videos you create with the service. The fonts we ship are
          open-source (Google Fonts under the SIL Open Font License) and are safe to use in
          commercial videos — but the{' '}
          <em>audio and text you add</em> remain your responsibility, as described above.
        </p>
      </Section>

      <Section title="Changes to the service">
        <p>
          We improve Typography continuously, so features, templates and limits will evolve. We may
          adjust plan pricing for new subscribers; existing subscriptions keep their price until
          renewal. If we ever remove a major feature you rely on, we&apos;ll give reasonable notice
          in the app.
        </p>
      </Section>

      <Section title="Limitation of liability">
        <p>
          The service is provided &quot;as is.&quot; We work hard to keep it available and your
          files safe, but we can&apos;t promise the service will be uninterrupted or error-free.
          Exports render in your browser, so results can depend on your device. To the maximum
          extent permitted by law, our total liability to you for any claim related to the service
          is limited to the amount you paid us in the 12 months before the claim. We are not liable
          for indirect or consequential damages, including lost profits, lost content beyond our
          stated retention, or disputes arising from videos you publish.
        </p>
      </Section>

      <Section title="Termination">
        <p>
          You may stop using Typography and delete your account at any time. We may suspend or
          close accounts that violate these terms or create legal risk for us or our users. When an
          account closes, your projects, exports and uploads are deleted as described in the
          Privacy Policy.
        </p>
      </Section>

      <Section title="Contact">
        <p>
          Questions about these terms? Email{' '}
          <span className="text-foreground">support@typography.app</span> or use the contact form
          on the{' '}
          <button
            type="button"
            onClick={() => navigate('/help')}
            className="font-medium text-brand hover:underline"
          >
            Help page
          </button>
          . If any part of these terms is unenforceable, the rest still applies.
        </p>
      </Section>
    </div>
  )
}
