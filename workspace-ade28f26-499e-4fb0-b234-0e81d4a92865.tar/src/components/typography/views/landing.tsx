'use client'

// Landing page — public marketing view for Typography.
// Rendered inside AppShell (TopNav + Footer + <main>), so this view only
// contains its own <section> landmarks and never repeats chrome.

import { useEffect, useState, type ReactNode } from 'react'
import { motion, useReducedMotion } from 'framer-motion'
import {
  ArrowRight,
  AudioWaveform,
  Briefcase,
  Check,
  Crown,
  Download,
  Globe,
  LayoutTemplate,
  ShieldCheck,
  Smartphone,
  Type,
  X,
  Zap,
  type LucideIcon,
} from 'lucide-react'

import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion'
import { TemplatePreview } from '@/components/typography/preview/template-preview'
import { navigate } from '@/hooks/use-hash-route'
import { useSession } from '@/hooks/use-session'
import { PLANS, type PlanDef } from '@/lib/typography/plans'
import {
  TEMPLATES,
  TEMPLATE_CATEGORIES,
  type TemplateDef,
} from '@/lib/typography/templates'
import { cn } from '@/lib/utils'

// ---------------------------------------------------------------------------
// Page copy (kept at module scope so the view below stays structural)
// ---------------------------------------------------------------------------

/** Hero preview rotates slowly through three visually distinct templates. */
const HERO_ROTATION: TemplateDef[] = [
  TEMPLATES[0], // Ignite — motivational, hot orange highlight
  TEMPLATES[1], // Essence — light, minimal quotes
  TEMPLATES[4], // Noir — cinematic serif
]

const SHOWCASE_IDS = [
  'ignite',
  'essence',
  'airtime',
  'lyric-wave',
  'noir',
  'did-you-know',
  'lumiere',
  'reps',
]

const SHOWCASE: TemplateDef[] = SHOWCASE_IDS.map((id) =>
  TEMPLATES.find((t) => t.id === id)
).filter((t): t is TemplateDef => Boolean(t))

const AUDIENCES = [
  'Short-form creators',
  'Podcasters',
  'Coaches',
  'Musicians',
  'Agencies',
]

const FEATURES: { icon: LucideIcon; title: string; description: string }[] = [
  {
    icon: Zap,
    title: 'Fast text-to-video creation',
    description: 'Paste your script, pick a template, export in minutes.',
  },
  {
    icon: LayoutTemplate,
    title: 'Professional templates',
    description: '12 designer-built starting points for every niche.',
  },
  {
    icon: Type,
    title: 'Custom fonts and colors',
    description: '12 licensed fonts, full color and layout control.',
  },
  {
    icon: Smartphone,
    title: 'Social-ready export',
    description: 'Vertical 9:16, square and 16:9 MP4 exports.',
  },
  {
    icon: AudioWaveform,
    title: 'Audio synchronization',
    description: 'Add music or voiceover and time scenes to it.',
  },
  {
    icon: Briefcase,
    title: 'Brand controls for businesses',
    description: 'Logo, brand colors and watermark-free exports on paid plans.',
  },
]

const STEPS = [
  {
    number: '01',
    title: 'Add your text',
    description: 'Type or paste your script. Split it into scenes automatically.',
  },
  {
    number: '02',
    title: 'Customize the design',
    description: 'Pick a template, then tune fonts, colors, and animation.',
  },
  {
    number: '03',
    title: 'Download your video',
    description: 'Export a vertical MP4, ready for Reels, Shorts and TikTok.',
  },
]

const FAQS = [
  {
    q: 'Do I need video editing experience?',
    a: 'None at all. Typography is built for people who have never touched a video editor: paste your text, pick a template, and the animation, timing and layout are handled for you. If you can write a caption, you can make a video.',
  },
  {
    q: 'Is there a free plan?',
    a: 'Yes — and it is a real plan, not a trial. The free plan includes 5 video exports per month, 3 saved projects, 720p exports and a small Typography watermark, with no credit card required.',
  },
  {
    q: 'Can I remove the watermark?',
    a: 'Yes. Watermark-free exports start on the Creator plan (₹499/month), which also unlocks 1080p exports and every template. Pro and Agency include the same benefit at higher limits.',
  },
  {
    q: 'What video formats can I export?',
    a: 'Every plan exports standard MP4 files in three aspect ratios: 9:16 vertical for Reels, Shorts and TikTok, 1:1 square, and 16:9 widescreen. Resolution scales with your plan — 720p on Free, 1080p on Creator, and up to 4K on Pro and Agency.',
  },
  {
    q: 'Can I use my own music?',
    a: 'Yes. Upload an MP3 or WAV you own or have the rights to, and time your scenes to it in the editor. We do not provide licensed music, and we never host copyrighted audio you do not have the rights to use.',
  },
  {
    q: 'Do you offer refunds?',
    a: 'Plans are billed monthly and you can cancel anytime — you keep access until the end of your billing period. If something goes wrong with a payment, contact support via the Help page and we will work it out with you.',
  },
]

function categoryLabel(category: TemplateDef['category']): string {
  return TEMPLATE_CATEGORIES.find((c) => c.id === category)?.label ?? category
}

// ---------------------------------------------------------------------------
// Motion helper — subtle fade-in-up on section entry (≤ 0.4s), disabled
// entirely when the user prefers reduced motion.
// ---------------------------------------------------------------------------

function FadeIn({
  children,
  className,
  delay = 0,
}: {
  children: ReactNode
  className?: string
  delay?: number
}) {
  const prefersReducedMotion = useReducedMotion()

  if (prefersReducedMotion) {
    return <div className={className}>{children}</div>
  }

  return (
    <motion.div
      className={className}
      initial={{ opacity: 0, y: 16 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-64px' }}
      transition={{ duration: 0.4, delay, ease: 'easeOut' }}
    >
      {children}
    </motion.div>
  )
}

// ---------------------------------------------------------------------------
// Pricing card
// ---------------------------------------------------------------------------

function PlanCard({ plan, signedIn }: { plan: PlanDef; signedIn: boolean }) {
  const included = plan.features.filter((f) => f.included).slice(0, 5)
  const excluded = plan.features.filter((f) => !f.included)
  // Plan one rank below — used to frame this card as "what more you get".
  const prev = PLANS[PLANS.findIndex((p) => p.id === plan.id) - 1]

  const ctaLabel = plan.id === 'FREE' ? 'Start free' : `Start with ${plan.name}`
  // Billing needs an account: signed-out visitors go to signup, signed-in
  // users go straight to billing where checkout lives.
  const ctaTarget = plan.id === 'FREE' ? '/editor/draft' : signedIn ? '/billing' : '/signup'

  return (
    <Card
      className={cn(
        'relative h-full rounded-lg border-border/70 bg-card/60 shadow-none transition-all duration-300 hover:-translate-y-0.5 hover:border-foreground/20 hover:bg-card',
        plan.highlight &&
          'z-10 border-brand/60 bg-gradient-to-b from-brand/[0.07] to-transparent hover:border-brand md:scale-[1.02]'
      )}
    >
      {plan.highlight && (
        <Badge className="absolute -top-3 left-1/2 -translate-x-1/2 border-transparent bg-brand px-2.5 text-white shadow-md">
          Most popular
        </Badge>
      )}
      <CardHeader>
        <CardTitle className="font-display text-base font-semibold tracking-tight">
          {plan.name}
        </CardTitle>
        <CardDescription className="text-sm leading-relaxed">
          {plan.tagline}
        </CardDescription>
      </CardHeader>
      <CardContent className="flex flex-1 flex-col">
        <p className="flex items-baseline gap-1.5">
          <span className="font-display text-3xl font-bold tracking-tight">
            {plan.priceLabel}
          </span>
          <span className="text-sm text-muted-foreground">
            {plan.priceValue > 0 ? '/month' : 'forever'}
          </span>
        </p>
        {plan.priceValue > 0 && (
          <p className="mt-1 text-xs text-muted-foreground">
            ≈ ₹{Math.round(plan.priceValue / 30)}/day · billed monthly · cancel anytime
          </p>
        )}
        {plan.priceValue > 0 && prev && (
          <p className="mt-4 text-xs font-medium text-muted-foreground">
            Everything in {prev.name}, plus:
          </p>
        )}

        <ul className="mt-5 flex flex-1 flex-col gap-2.5">
          {included.map((feature) => (
            <li key={feature.label} className="flex items-start gap-2.5 text-sm">
              <Check className="mt-0.5 size-4 shrink-0 text-brand" aria-hidden="true" />
              <span>{feature.label}</span>
            </li>
          ))}
          {excluded.map((feature) => (
            <li
              key={feature.label}
              className="flex items-start gap-2.5 text-sm text-muted-foreground/70"
            >
              {feature.soon ? (
                <span className="mt-0.5 inline-flex h-4 shrink-0 items-center rounded bg-secondary px-1.5 text-[10px] font-medium uppercase tracking-wide text-muted-foreground">
                  soon
                </span>
              ) : (
                <X className="mt-0.5 size-4 shrink-0" aria-hidden="true" />
              )}
              <span>{feature.label}</span>
            </li>
          ))}
        </ul>

        <Button
          className="mt-6 w-full"
          variant={
            plan.highlight ? 'default' : plan.id === 'FREE' ? 'secondary' : 'outline'
          }
          onClick={() => navigate(ctaTarget)}
        >
          {ctaLabel}
        </Button>
      </CardContent>
    </Card>
  )
}

// ---------------------------------------------------------------------------
// View
// ---------------------------------------------------------------------------

export default function LandingView() {
  const { user } = useSession()
  const prefersReducedMotion = useReducedMotion()
  const [previewIndex, setPreviewIndex] = useState(0)

  // Slowly rotate the hero preview between a few templates. Skipped for
  // users who prefer reduced motion.
  useEffect(() => {
    if (prefersReducedMotion) return
    if (
      typeof window !== 'undefined' &&
      window.matchMedia('(prefers-reduced-motion: reduce)').matches
    ) {
      return
    }
    const id = window.setInterval(() => {
      setPreviewIndex((i) => (i + 1) % HERO_ROTATION.length)
    }, 8000)
    return () => window.clearInterval(id)
  }, [prefersReducedMotion])

  const heroTemplate = HERO_ROTATION[previewIndex] ?? HERO_ROTATION[0]

  return (
    <div className="bg-background">
      {/* ------------------------------------------------------------- Hero */}
      <section aria-labelledby="hero-heading" className="relative overflow-hidden">
        <div className="hero-glow absolute inset-0" aria-hidden="true" />
        <div
          className="grid-noise absolute inset-0 [mask-image:radial-gradient(ellipse_70%_60%_at_50%_0%,black,transparent)]"
          aria-hidden="true"
        />
        <div className="relative mx-auto max-w-6xl px-4 pb-16 pt-14 sm:px-6 sm:pt-20 lg:pb-20 lg:pt-24">
          <div className="grid items-center gap-14 lg:grid-cols-[1.05fr_0.95fr] lg:gap-12">
            <FadeIn className="max-w-2xl">
              <span className="inline-flex items-center gap-2.5 rounded-md border border-border/80 bg-secondary/30 px-3 py-1.5 text-xs font-medium tracking-wide text-muted-foreground">
                <span className="size-1.5 rounded-full bg-brand" aria-hidden="true" />
                Text-to-video for short-form creators
              </span>
              <h1
                id="hero-heading"
                className="mt-6 font-display text-4xl font-bold leading-[1.08] tracking-tight sm:text-5xl lg:text-6xl"
              >
                Turn any script into an engaging{' '}
                <span className="text-brand-gradient">animated typography video</span> in
                minutes.
              </h1>
              <p className="mt-6 max-w-xl text-base leading-relaxed text-muted-foreground sm:text-lg">
                Create scroll-stopping text videos for Reels, Shorts, TikTok, podcasts,
                music, quotes, and marketing.
              </p>
              <div className="mt-8 flex flex-col gap-3 sm:flex-row sm:items-center">
                <Button
                  size="lg"
                  className="w-full sm:w-auto"
                  onClick={() => navigate('/editor/draft')}
                >
                  Create your first video
                  <ArrowRight aria-hidden="true" />
                </Button>
                <Button
                  size="lg"
                  variant="outline"
                  className="w-full sm:w-auto"
                  onClick={() => navigate('/templates')}
                >
                  View templates
                </Button>
              </div>
              <ul
                className="mt-6 flex flex-wrap items-center gap-x-4 gap-y-2 sm:gap-x-5"
                aria-label="What you get for free"
              >
                <li className="flex items-center gap-1.5 text-xs text-muted-foreground sm:text-sm">
                  <ShieldCheck className="size-3.5 shrink-0 text-brand" aria-hidden="true" />
                  No credit card needed
                </li>
                <li className="flex items-center gap-1.5 text-xs text-muted-foreground sm:text-sm">
                  <Zap className="size-3.5 shrink-0 text-brand" aria-hidden="true" />
                  5 free exports every month
                </li>
                <li className="flex items-center gap-1.5 text-xs text-muted-foreground sm:text-sm">
                  <Download className="size-3.5 shrink-0 text-brand" aria-hidden="true" />
                  Real MP4 downloads
                </li>
                <li className="flex items-center gap-1.5 text-xs text-muted-foreground sm:text-sm">
                  <Globe className="size-3.5 shrink-0 text-brand" aria-hidden="true" />
                  Runs in your browser
                </li>
              </ul>
            </FadeIn>

            {/* Live preview — phone-style frame */}
            <FadeIn delay={0.1} className="relative mx-auto w-full max-w-[300px] sm:max-w-[315px]">
              <div
                className="absolute -inset-6 -z-10 rounded-full bg-brand/10 blur-3xl"
                aria-hidden="true"
              />
              <div className="overflow-hidden rounded-xl border border-white/10 bg-card shadow-2xl shadow-black/60 ring-1 ring-white/5">
                <TemplatePreview
                  key={heroTemplate.id}
                  template={heroTemplate}
                  className="aspect-[9/16] w-full animate-in fade-in duration-500"
                />
              </div>
              <p className="mt-3.5 flex items-center justify-center gap-2 text-center text-xs text-muted-foreground">
                <span
                  className={cn(
                    'size-1.5 rounded-full bg-brand',
                    !prefersReducedMotion && 'animate-pulse'
                  )}
                  aria-hidden="true"
                />
                Live preview — {heroTemplate.name} template
              </p>
            </FadeIn>
          </div>
        </div>
      </section>

      {/* ------------------------------------------------- Social proof strip */}
      <section
        aria-label="Who Typography is built for"
        className="border-y border-border/60 bg-secondary/20"
      >
        <div className="mx-auto max-w-6xl px-4 py-6 sm:px-6">
          <div className="flex flex-wrap items-center justify-center gap-x-3 gap-y-2">
            <span className="mr-1 text-xs font-medium uppercase tracking-wider text-muted-foreground/70">
              Built for
            </span>
            {AUDIENCES.map((audience) => (
              <Badge
                key={audience}
                variant="outline"
                className="border-border/70 bg-transparent px-3 py-1 text-xs font-normal text-muted-foreground"
              >
                {audience}
              </Badge>
            ))}
          </div>
        </div>
      </section>

      {/* ------------------------------------------------------ Feature cards */}
      <section aria-labelledby="features-heading" className="py-16 sm:py-20 lg:py-24">
        <div className="mx-auto max-w-6xl px-4 sm:px-6">
          <FadeIn>
            <div className="max-w-2xl">
              <h2
                id="features-heading"
                className="font-display text-3xl font-bold tracking-tight sm:text-4xl"
              >
                Everything you need to make text move
              </h2>
              <p className="mt-3 text-base leading-relaxed text-muted-foreground sm:text-lg">
                From a blank page to a finished video — without opening a timeline or
                learning a video editor.
              </p>
            </div>
          </FadeIn>
          <FadeIn delay={0.05}>
            <div className="mt-10 grid gap-4 sm:grid-cols-2 sm:gap-5 lg:grid-cols-3">
              {FEATURES.map((feature) => {
                const Icon = feature.icon
                return (
                  <Card
                    key={feature.title}
                    className="h-full rounded-lg border-border/70 bg-card/50 shadow-none transition-all duration-300 hover:-translate-y-0.5 hover:border-brand/40 hover:bg-card"
                  >
                    <CardContent className="flex flex-col gap-4">
                      <div className="flex size-10 shrink-0 items-center justify-center rounded-lg border border-brand/20 bg-brand-soft text-brand">
                        <Icon className="size-5" aria-hidden="true" />
                      </div>
                      <div>
                        <h3 className="font-display text-base font-semibold tracking-tight">
                          {feature.title}
                        </h3>
                        <p className="mt-1.5 text-sm leading-relaxed text-muted-foreground">
                          {feature.description}
                        </p>
                      </div>
                    </CardContent>
                  </Card>
                )
              })}
            </div>
          </FadeIn>
        </div>
      </section>

      {/* -------------------------------------------------------- How it works */}
      <section
        aria-labelledby="how-heading"
        className="border-y border-border/50 bg-secondary/[0.15] py-16 sm:py-20 lg:py-24"
      >
        <div className="mx-auto max-w-6xl px-4 sm:px-6">
          <FadeIn>
            <div className="max-w-2xl">
              <h2
                id="how-heading"
                className="font-display text-3xl font-bold tracking-tight sm:text-4xl"
              >
                How it works
              </h2>
              <p className="mt-3 text-base leading-relaxed text-muted-foreground sm:text-lg">
                Three steps between your script and a finished video.
              </p>
            </div>
          </FadeIn>
          <FadeIn delay={0.05}>
            <ol className="mt-12 grid gap-10 md:grid-cols-3 md:gap-8">
              {STEPS.map((step) => (
                <li key={step.number} className="group border-t border-border pt-6">
                  <span className="font-display text-5xl font-bold tracking-tight text-muted-foreground/25 transition-colors duration-300 group-hover:text-brand/60">
                    {step.number}
                  </span>
                  <h3 className="mt-4 font-display text-lg font-semibold tracking-tight">
                    {step.title}
                  </h3>
                  <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                    {step.description}
                  </p>
                </li>
              ))}
            </ol>
            <p className="mt-10 text-center text-sm text-muted-foreground">
              A first video takes about two minutes — most of that time is your words.
            </p>
          </FadeIn>
        </div>
      </section>

      {/* --------------------------------------------------- Template showcase */}
      <section aria-labelledby="templates-heading" className="py-16 sm:py-20 lg:py-24">
        <div className="mx-auto max-w-6xl px-4 sm:px-6">
          <FadeIn>
            <div className="max-w-2xl">
              <h2
                id="templates-heading"
                className="font-display text-3xl font-bold tracking-tight sm:text-4xl"
              >
                Start from a template, not a blank canvas
              </h2>
              <p className="mt-3 text-base leading-relaxed text-muted-foreground sm:text-lg">
                Twelve designer-built styles for quotes, podcasts, lyrics, launches and
                more. Every preview below is rendered live by the same engine that
                exports your video.
              </p>
            </div>
          </FadeIn>

          <FadeIn delay={0.05}>
            <ul
              aria-label="Template previews — scroll horizontally to see more"
              className="scrollbar-slim -mx-4 mt-10 flex list-none gap-4 overflow-x-auto px-4 pb-4 sm:-mx-6 sm:px-6"
            >
              {SHOWCASE.map((template) => (
                <li key={template.id} className="w-40 shrink-0 sm:w-48">
                  {/* Real anchor (hash route) so the card is keyboard- and
                      middle-click friendly. */}
                  <a
                    href="#/templates"
                    className="group block rounded-lg outline-offset-4"
                  >
                    <span className="block overflow-hidden rounded-lg border border-border/70 transition-all duration-300 group-hover:-translate-y-1 group-hover:border-brand/50 group-hover:shadow-lg group-hover:shadow-black/40">
                      <TemplatePreview
                        template={template}
                        className="aspect-[9/16] w-full"
                      />
                    </span>
                    <span className="mt-2.5 flex items-center justify-between gap-2">
                      <span className="text-sm font-medium text-foreground">
                        {template.name}
                      </span>
                      {template.premium && (
                        <Badge className="gap-1 border-brand/30 bg-brand-soft px-1.5 text-[10px] font-semibold text-brand">
                          <Crown className="size-3" aria-hidden="true" />
                          Pro
                        </Badge>
                      )}
                    </span>
                    <span className="mt-0.5 block text-xs text-muted-foreground">
                      {categoryLabel(template.category)}
                    </span>
                  </a>
                </li>
              ))}
            </ul>
          </FadeIn>

          <div className="mt-8 flex justify-center">
            <Button variant="outline" onClick={() => navigate('/templates')}>
              Browse all templates
              <ArrowRight aria-hidden="true" />
            </Button>
          </div>
        </div>
      </section>

      {/* ------------------------------------------------------------ Pricing */}
      <section
        aria-labelledby="pricing-heading"
        className="border-t border-border/50 py-16 sm:py-20 lg:py-24"
      >
        <div className="mx-auto max-w-6xl px-4 sm:px-6">
          <FadeIn>
            <div className="mx-auto max-w-2xl text-center">
              <h2
                id="pricing-heading"
                className="font-display text-3xl font-bold tracking-tight sm:text-4xl"
              >
                Simple pricing that scales with you
              </h2>
              <p className="mt-3 text-base leading-relaxed text-muted-foreground sm:text-lg">
                Start free and upgrade when you publish more. Paid plans remove the
                watermark and unlock higher resolutions.
              </p>
            </div>
          </FadeIn>
          <FadeIn delay={0.05} className="mt-12">
            <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-4">
              {PLANS.map((plan) => (
                <PlanCard key={plan.id} plan={plan} signedIn={!!user} />
              ))}
            </div>
          </FadeIn>
          <div className="mt-10 text-center">
            <p className="text-xs text-muted-foreground">
              Prices in INR, billed monthly. Cancel anytime. Payment processing is handled
              securely by Stripe.
            </p>
            <button
              onClick={() => navigate('/pricing')}
              className="mt-3 inline-flex items-center gap-1.5 text-sm font-medium text-brand underline-offset-4 transition-colors hover:text-brand/80 hover:underline"
            >
              See full plan comparison
              <ArrowRight className="size-4" aria-hidden="true" />
            </button>
          </div>
        </div>
      </section>

      {/* ---------------------------------------------------------------- FAQ */}
      <section aria-labelledby="faq-heading" className="py-16 sm:py-20 lg:py-24">
        <div className="mx-auto max-w-3xl px-4 sm:px-6">
          <FadeIn>
            <h2
              id="faq-heading"
              className="text-center font-display text-3xl font-bold tracking-tight sm:text-4xl"
            >
              Frequently asked questions
            </h2>
          </FadeIn>
          <FadeIn delay={0.05}>
            <Accordion type="single" collapsible defaultValue="faq-0" className="mt-10 w-full">
              {FAQS.map((faq, index) => (
                <AccordionItem key={faq.q} value={`faq-${index}`} className="border-border/70">
                  <AccordionTrigger className="text-left text-sm font-medium sm:text-base">
                    {faq.q}
                  </AccordionTrigger>
                  <AccordionContent className="text-sm leading-relaxed text-muted-foreground">
                    {faq.a}
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
            <p className="mt-8 text-center text-sm text-muted-foreground">
              Still have questions?{' '}
              <button
                onClick={() => navigate('/help')}
                className="font-medium text-brand underline-offset-4 transition-colors hover:text-brand/80 hover:underline"
              >
                Visit the Help page
              </button>
            </p>
          </FadeIn>
        </div>
      </section>

      {/* -------------------------------------------------------- Final CTA band */}
      <section aria-labelledby="cta-heading" className="pb-20 sm:pb-24 lg:pb-28">
        <div className="mx-auto max-w-6xl px-4 sm:px-6">
          <FadeIn>
            <div className="panel-glass relative overflow-hidden rounded-lg px-6 py-14 text-center sm:px-12 sm:py-16">
              <div className="hero-glow absolute inset-0 opacity-70" aria-hidden="true" />
              <div className="relative flex flex-col items-center">
                <h2
                  id="cta-heading"
                  className="max-w-2xl font-display text-3xl font-bold tracking-tight sm:text-4xl"
                >
                  Your next scroll-stopper is one script away.
                </h2>
                <Button
                  size="lg"
                  className="mt-8"
                  onClick={() => navigate('/editor/draft')}
                >
                  Create your first video
                  <ArrowRight aria-hidden="true" />
                </Button>
                <p className="mt-4 text-xs text-muted-foreground sm:text-sm">
                  Free forever plan · No credit card required
                </p>
              </div>
            </div>
          </FadeIn>
        </div>
      </section>
    </div>
  )
}
