'use client'

// Editor view: project chrome (name, autosave, export), panel tabs and the
// live preview. Desktop: side-by-side; mobile: stacked with sticky preview.

import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import {
  ArrowLeft,
  AudioWaveform,
  Check,
  Cloud,
  CloudOff,
  Crown,
  Download,
  Film,
  LayoutTemplate,
  Loader2,
  PenLine,
  Sparkles,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { toast } from 'sonner'
import { cn } from '@/lib/utils'
import { useEditorStore } from './editor-store'
import { PreviewPlayer } from './preview-player'
import { TextPanel } from './panels/text-panel'
import { DesignPanel } from './panels/design-panel'
import { AudioPanel } from './panels/audio-panel'
import { TemplatesPanel } from './panels/templates-panel'
import { AiPanel } from './panels/ai-panel'
import { ExportDialog } from './export-dialog'
import { navigate, currentHashPath } from '@/hooks/use-hash-route'
import { useSession } from '@/hooks/use-session'
import { useIsDesktop } from '@/hooks/use-desktop'
import { apiGet, apiSend, ApiError } from '@/lib/api-client'
import { normalizeProject, defaultProject } from '@/lib/typography/defaults'
import type { ProjectData, ProjectSummary } from '@/lib/typography/types'

const DRAFT_KEY = 'typo-draft-project'
const DRAFT_NAME_KEY = 'typo-draft-name'

export default function EditorView({ projectId }: { projectId: string }) {
  const { user, status, plan } = useSession()
  const store = useEditorStore()
  const { project, projectName, saveState, loaded, loadError } = store
  const [exportOpen, setExportOpen] = useState(false)
  const [mobileTab, setMobileTab] = useState('text')
  // One-time onboarding banner — dismissed per browser, never nags again.
  const [showTour, setShowTour] = useState(() => {
    if (typeof window === 'undefined') return false
    return !window.localStorage.getItem('typo-editor-tour-done')
  })
  const isDesktop = useIsDesktop()
  const saveTimer = useRef<ReturnType<typeof setTimeout> | null>(null)
  const hydrated = useRef(false)
  // True when the draft route loaded an existing localStorage draft (vs. a
  // fresh default project). Used to auto-claim it into a signed-in account.
  const hadStoredDraft = useRef(false)

  const isDraft = projectId === 'draft'

  /* ------------------------------ load ------------------------------ */
  useEffect(() => {
    if (hydrated.current) return
    if (isDraft) {
      if (typeof window !== 'undefined') {
        const stored = window.localStorage.getItem(DRAFT_KEY)
        const name = window.localStorage.getItem(DRAFT_NAME_KEY) || 'My draft video'
        let data: ProjectData | null = null
        if (stored) {
          try {
            data = normalizeProject(JSON.parse(stored))
          } catch {
            data = null
          }
        }
        hadStoredDraft.current = (() => {
          if (!data) return false
          // A pristine default draft (nothing edited) should not be auto-claimed
          // into an account — only real work is. Compared structurally against
          // the current default so sample content is never mistaken for work.
          const def = defaultProject()
          const isPristine =
            data.templateId === null &&
            data.scenes.length === def.scenes.length &&
            data.scenes.every((s, i) => s.text === def.scenes[i].text) &&
            (name === 'My draft video' || !name)
          return !isPristine
        })()
        store.init({ projectId: null, project: data ?? defaultProject(), name })
        // NOTE: the draft is intentionally kept in localStorage (not removed)
        // so a reload restores it; it is cleared only after the draft is
        // claimed into a signed-in account (see claimDraft below).
      }
      hydrated.current = true
      return
    }
    if (status === 'loading') return
    if (!user) return
    let cancelled = false
    apiGet<{ project: ProjectSummary }>(`/api/projects/${projectId}`)
      .then((res) => {
        if (cancelled) return
        store.init({
          projectId: res.project.id,
          project: normalizeProject(res.project.data),
          name: res.project.name,
        })
        hydrated.current = true
      })
      .catch((err) => {
        if (cancelled) return
        store.setLoadError(
          err instanceof ApiError && err.status === 404
            ? 'This project does not exist or belongs to another account.'
            : 'Could not load this project. Please go back and try again.'
        )
        hydrated.current = true
      })
    return () => {
      cancelled = true
    }
     
  }, [projectId, status, user])

  /* ---------------------------- autosave ---------------------------- */
  const saveNow = useCallback(async () => {
    const state = useEditorStore.getState()
    if (!state.projectId || !user) return
    state.setSaveState('saving')
    try {
      await apiSend('PATCH', `/api/projects/${state.projectId}`, {
        name: state.projectName,
        data: state.project,
      })
      const stillSame = useEditorStore.getState().project === state.project
      useEditorStore.getState().setSaveState(stillSame ? 'saved' : 'unsaved')
    } catch (err) {
      useEditorStore.getState().setSaveState('error')
      if (err instanceof ApiError && err.status === 401) {
        toast.error('Your session expired — sign in again to keep editing.')
      }
    }
  }, [user])

  useEffect(() => {
    if (!loaded || !user || !store.projectId) return
    if (saveState !== 'unsaved') return
    if (saveTimer.current) clearTimeout(saveTimer.current)
    saveTimer.current = setTimeout(() => void saveNow(), 1400)
    return () => {
      if (saveTimer.current) clearTimeout(saveTimer.current)
    }
  }, [project, projectName, saveState, loaded, user, store.projectId, saveNow])

  // Draft persistence — for guests AND signed-in users on the draft route,
  // so a reload never loses work. (A claimed draft navigates to /editor/:id
  // and is then covered by server autosave.)
  useEffect(() => {
    if (!loaded || !isDraft) return
    const timer = setTimeout(() => {
      try {
        window.localStorage.setItem(DRAFT_KEY, JSON.stringify(project))
        window.localStorage.setItem(DRAFT_NAME_KEY, projectName)
      } catch {
        /* storage full — drafts simply won't persist */
      }
    }, 800)
    return () => clearTimeout(timer)
  }, [project, projectName, loaded, isDraft])

  // Warn before losing unsaved changes.
  useEffect(() => {
    const handler = (e: BeforeUnloadEvent) => {
      if (saveState === 'unsaved' || saveState === 'saving') {
        e.preventDefault()
      }
    }
    window.addEventListener('beforeunload', handler)
    return () => window.removeEventListener('beforeunload', handler)
  }, [saveState])

  /* --------------------------- draft save --------------------------- */
  const claimingRef = useRef(false)
  const saveDraftToAccount = async () => {
    if (!user) {
      toast.info('Create a free account to save this project.')
      navigate(`/signup?returnTo=${encodeURIComponent(currentHashPath())}`)
      return
    }
    if (claimingRef.current) return // already saving — never double-create
    claimingRef.current = true
    const state = useEditorStore.getState()
    try {
      const res = await apiSend<{ id: string }>('POST', '/api/projects', {
        name: state.projectName || 'My video',
        data: state.project,
      })
      // The draft now lives in the account — clear the local copy.
      try {
        window.localStorage.removeItem(DRAFT_KEY)
        window.localStorage.removeItem(DRAFT_NAME_KEY)
      } catch {
        /* ignore */
      }
      toast.success('Project saved to your account')
      navigate(`/editor/${res.id}`)
    } catch (err) {
      if (err instanceof ApiError && err.status === 402) {
        toast.error(err.message)
        navigate('/billing')
      } else {
        toast.error(err instanceof Error ? err.message : 'Could not save the project.')
      }
    } finally {
      claimingRef.current = false
    }
  }

  // A signed-in user who just arrived back on the draft route with real work
  // (e.g. right after signing up from an auth gate) gets their draft claimed
  // into their account automatically — no silent data loss on reload.
  useEffect(() => {
    if (!loaded || !user || !isDraft) return
    if (!hadStoredDraft.current || store.projectId) return
    let cancelled = false
    const timer = setTimeout(() => {
      // Re-check inside the callback: deps may have re-run this effect and the
      // claim may already be in flight (guards against double POSTs).
      if (cancelled || !hadStoredDraft.current || useEditorStore.getState().projectId) return
      hadStoredDraft.current = false // claim only once
      void saveDraftToAccount()
    }, 600)
    return () => {
      cancelled = true
      clearTimeout(timer)
    }
  }, [loaded, user, isDraft, store.projectId])

  const saveStatusView = useMemo(() => {
    switch (saveState) {
      case 'saving':
        return (
          <span className="flex items-center gap-1.5 text-xs text-muted-foreground" role="status">
            <Loader2 className="h-3.5 w-3.5 animate-spin" aria-hidden="true" /> Saving…
          </span>
        )
      case 'saved':
        return (
          <span className="flex items-center gap-1.5 text-xs text-muted-foreground" role="status">
            <Check className="h-3.5 w-3.5 text-emerald-400" aria-hidden="true" /> Saved
          </span>
        )
      case 'unsaved':
        return (
          <span className="flex items-center gap-1.5 text-xs text-muted-foreground" role="status">
            <Cloud className="h-3.5 w-3.5" aria-hidden="true" /> Unsaved changes
          </span>
        )
      case 'error':
        return (
          <button className="flex items-center gap-1.5 text-xs text-amber-400 hover:underline" onClick={() => void saveNow()} role="status">
            <CloudOff className="h-3.5 w-3.5" aria-hidden="true" /> Save failed — retry
          </button>
        )
      default:
        return (
          <span className="flex items-center gap-1.5 text-xs text-muted-foreground" role="status">
            <CloudOff className="h-3.5 w-3.5" aria-hidden="true" /> Draft (not saved)
          </span>
        )
    }
  }, [saveState, saveNow])

  /* ------------------------------ views ----------------------------- */

  if (loadError) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center gap-4 px-4 text-center">
        <p className="font-display text-xl font-semibold">{loadError}</p>
        <Button onClick={() => navigate(user ? '/dashboard' : '/')}>
          <ArrowLeft className="mr-2 h-4 w-4" aria-hidden="true" />
          {user ? 'Back to dashboard' : 'Back to home'}
        </Button>
      </div>
    )
  }

  if (!loaded || (status === 'loading' && !isDraft)) {
    return (
      <div className="flex min-h-screen items-center justify-center" aria-busy="true">
        <Loader2 className="h-6 w-6 animate-spin text-brand" aria-label="Loading project" />
      </div>
    )
  }

  const tabsList = (
    <TabsList className="grid w-full grid-cols-5">
      <TabsTrigger value="text" aria-label="Text and scenes">
        <PenLine className="mr-1 h-3.5 w-3.5 sm:mr-1.5" />
        <span className="hidden sm:inline">Text</span>
      </TabsTrigger>
      <TabsTrigger value="design" aria-label="Design controls">
        <LayoutTemplate className="mr-1 h-3.5 w-3.5 sm:mr-1.5" />
        <span className="hidden sm:inline">Design</span>
      </TabsTrigger>
      <TabsTrigger value="audio" aria-label="Audio controls">
        <AudioWaveform className="mr-1 h-3.5 w-3.5 sm:mr-1.5" />
        <span className="hidden sm:inline">Audio</span>
      </TabsTrigger>
      <TabsTrigger value="templates" aria-label="Templates">
        <Film className="mr-1 h-3.5 w-3.5 sm:mr-1.5" />
        <span className="hidden sm:inline">Styles</span>
      </TabsTrigger>
      <TabsTrigger value="ai" aria-label="AI suggestions">
        <Sparkles className="mr-1 h-3.5 w-3.5 sm:mr-1.5" />
        <span className="hidden sm:inline">AI</span>
      </TabsTrigger>
    </TabsList>
  )

  const panels = (
    <>
      <TabsContent value="text" className="mt-0">
        <TextPanel />
      </TabsContent>
      <TabsContent value="design" className="mt-0">
        <DesignPanel />
      </TabsContent>
      <TabsContent value="audio" className="mt-0">
        <AudioPanel />
      </TabsContent>
      <TabsContent value="templates" className="mt-0">
        <TemplatesPanel />
      </TabsContent>
      <TabsContent value="ai" className="mt-0">
        <AiPanel />
      </TabsContent>
    </>
  )

  return (
    <div className="flex h-screen flex-col overflow-hidden bg-background">
      {/* Top bar */}
      <header className="flex h-14 shrink-0 items-center gap-2 border-b border-border/80 bg-card/60 px-3 sm:gap-3 sm:px-4">
        <Button
          variant="ghost"
          size="icon"
          onClick={() => navigate(user ? '/dashboard' : '/')}
          aria-label="Back"
          className="h-9 w-9 shrink-0"
        >
          <ArrowLeft className="h-4 w-4" />
        </Button>

        <div className="flex min-w-0 flex-1 items-center gap-2 sm:gap-3">
          <Input
            value={projectName}
            onChange={(e) => store.setProjectName(e.target.value)}
            aria-label="Project name"
            className="h-9 w-32 truncate border-transparent bg-transparent px-1.5 text-sm font-medium hover:border-border sm:w-56"
            maxLength={120}
          />
          <div className="hidden sm:block">{saveStatusView}</div>
          {user &&
            (plan.id === 'FREE' ? (
              <Button
                variant="outline"
                size="sm"
                className="hidden h-7 shrink-0 border-brand/40 bg-brand-soft px-2.5 text-xs font-medium text-brand hover:bg-brand/20 md:inline-flex"
                onClick={() => navigate('/billing')}
              >
                <Crown className="mr-1 h-3.5 w-3.5" aria-hidden="true" /> Upgrade
              </Button>
            ) : (
              <span className="hidden shrink-0 rounded-md bg-secondary px-2 py-1 text-[11px] font-medium text-muted-foreground md:inline">
                {plan.name} plan
              </span>
            ))}
        </div>

        {/* Guests land here too — the handler routes them to signup first. */}
        {isDraft && (
          <Button variant="outline" size="sm" onClick={saveDraftToAccount} className="shrink-0">
            Save to account
          </Button>
        )}

        <Button size="sm" onClick={() => setExportOpen(true)} className="shrink-0">
          <Download className="mr-1.5 h-4 w-4" aria-hidden="true" />
          Export
        </Button>
      </header>

      {/* First-run guide — slim, dismissible, above both layout columns so the
          h-screen flex-col + min-h-0 grid keeps working (banner is shrink-0). */}
      {showTour && (
        <div className="shrink-0 border-b border-border/80 bg-brand/[0.06] px-4 py-2.5">
          <div className="flex flex-wrap items-center gap-x-3 gap-y-1">
            <Sparkles className="h-4 w-4 shrink-0 text-brand" aria-hidden="true" />
            <p className="flex flex-wrap items-center gap-x-2 gap-y-1 text-xs text-muted-foreground">
              <span>1. Edit your text in the Text tab</span>
              <span aria-hidden="true" className="text-muted-foreground/50">·</span>
              <span>2. Pick a style in the Styles tab</span>
              <span aria-hidden="true" className="text-muted-foreground/50">·</span>
              <span>3. Export your MP4</span>
            </p>
            <Button
              variant="ghost"
              size="sm"
              aria-label="Dismiss editor guide"
              className="ml-auto h-7 shrink-0 px-2.5 text-xs"
              onClick={() => {
                try {
                  window.localStorage.setItem('typo-editor-tour-done', '1')
                } catch {
                  /* storage unavailable — just hide it for this session */
                }
                setShowTour(false)
              }}
            >
              Got it
            </Button>
          </div>
        </div>
      )}

      {/* Single preview instance — layout switches with the viewport so we
          never mount two players (and two render loops) at once. */}
      {isDesktop ? (
        <div className="hidden min-h-0 flex-1 lg:grid lg:grid-cols-[340px_1fr]">
          <aside className="min-h-0 overflow-y-auto border-r border-border/80 p-3 scrollbar-slim">
            <Tabs defaultValue="text" className="flex flex-col gap-4">
              {tabsList}
              {panels}
            </Tabs>
          </aside>
          <section className="flex min-h-0 flex-col p-4" aria-label="Video preview">
            <PreviewPlayer watermark={plan.watermark} />
          </section>
        </div>
      ) : (
        <div className="flex min-h-0 flex-1 flex-col lg:hidden">
          <section className="h-[48vh] shrink-0 border-b border-border/80 p-3" aria-label="Video preview">
            <PreviewPlayer watermark={plan.watermark} />
          </section>
          <div className="min-h-0 flex-1 overflow-y-auto p-3 pb-[calc(0.75rem+env(safe-area-inset-bottom))] scrollbar-slim">
            <Tabs value={mobileTab} onValueChange={setMobileTab} className="flex flex-col gap-4">
              {tabsList}
              {panels}
            </Tabs>
          </div>
        </div>
      )}

      <ExportDialog open={exportOpen} onOpenChange={setExportOpen} />
    </div>
  )
}
