'use client'

// Timeline: scene blocks sized by duration. Click to seek, drag scrubber.

import { useCallback, useEffect, useRef } from 'react'
import { useEditorStore } from './editor-store'
import { cn } from '@/lib/utils'

export function Timeline({
  time,
  duration,
  onSeek,
}: {
  time: number
  duration: number
  onSeek: (t: number) => void
}) {
  const project = useEditorStore((s) => s.project)
  const selectScene = useEditorStore((s) => s.selectScene)
  const selectedSceneId = useEditorStore((s) => s.selectedSceneId)
  const trackRef = useRef<HTMLDivElement>(null)

  const scenes = project.scenes
  const total = duration || scenes.reduce((a, s) => a + s.duration, 0)

  const sceneAt = useCallback(
    (t: number) => {
      let acc = 0
      for (let i = 0; i < scenes.length; i++) {
        acc += scenes[i].duration
        if (t < acc) return i
      }
      return scenes.length - 1
    },
    [scenes]
  )

  // Click-to-seek on the track.
  const handleTrackClick = (e: React.MouseEvent) => {
    const track = trackRef.current
    if (!track || total <= 0) return
    const rect = track.getBoundingClientRect()
    const ratio = Math.min(1, Math.max(0, (e.clientX - rect.left) / rect.width))
    onSeek(ratio * total)
  }

  const currentIndex = sceneAt(time)

  return (
    <div className="rounded-lg border border-border/70 bg-card px-3 py-2.5">
      <div className="mb-2 flex items-center justify-between text-[11px] font-medium uppercase tracking-wider text-muted-foreground">
        <span>Timeline</span>
        <span>{scenes.length} scenes · {total.toFixed(1)}s</span>
      </div>
      <div
        ref={trackRef}
        className="relative h-9 w-full cursor-pointer select-none overflow-hidden rounded-md bg-secondary"
        onClick={handleTrackClick}
        role="slider"
        aria-label="Seek through scenes"
        aria-valuemin={0}
        aria-valuemax={Math.round(total)}
        aria-valuenow={Math.round(time)}
        tabIndex={0}
        onKeyDown={(e) => {
          if (e.key === 'ArrowRight') onSeek(Math.min(total, time + 0.5))
          if (e.key === 'ArrowLeft') onSeek(Math.max(0, time - 0.5))
        }}
      >
        <div className="flex h-full w-full">
          {scenes.map((scene, i) => {
            const width = total > 0 ? (scene.duration / total) * 100 : 0
            const isSelected = scene.id === selectedSceneId
            const isCurrent = i === currentIndex
            return (
              <button
                key={scene.id}
                className={cn(
                  'group relative h-full min-w-0 overflow-hidden border-r border-background/60 px-1.5 text-left transition-colors last:border-r-0',
                  isSelected ? 'bg-brand/25' : isCurrent ? 'bg-brand/15' : 'bg-transparent hover:bg-white/5'
                )}
                style={{ width: `${width}%` }}
                onClick={(e) => {
                  e.stopPropagation()
                  const before = scenes.slice(0, i).reduce((a, s) => a + s.duration, 0)
                  selectScene(scene.id)
                  onSeek(before + 0.01)
                }}
                title={scene.text.split('\n')[0] || `Scene ${i + 1}`}
                aria-label={`Scene ${i + 1}: ${scene.text.split('\n')[0] ?? ''}`}
              >
                <span className="pointer-events-none block truncate text-[10px] leading-9 text-foreground/80">
                  {scene.text.split('\n')[0] || `Scene ${i + 1}`}
                </span>
              </button>
            )
          })}
        </div>
        {/* Playhead */}
        <div
          className="pointer-events-none absolute inset-y-0 w-0.5 bg-brand"
          style={{ left: `${total > 0 ? (time / total) * 100 : 0}%` }}
          aria-hidden="true"
        />
      </div>
    </div>
  )
}
