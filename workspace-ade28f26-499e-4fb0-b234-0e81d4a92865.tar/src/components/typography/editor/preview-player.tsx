'use client'

// Live preview player: renders the project with the exact engine used for
// exports, with playback controls, scrubbing, audio sync and zoom.

import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { Pause, Play, RotateCcw, Volume2, VolumeX, Maximize2 } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Slider } from '@/components/ui/slider'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { CANVAS_SIZES, type ProjectData } from '@/lib/typography/types'
import { createRenderer } from '@/lib/typography/render-frame'
import { ensureProjectFontsLoaded } from '@/lib/typography/fonts'
import { getCachedImage, getCachedAudio, loadImageAsset, loadAudioAsset } from '@/lib/client/assets'
import { useEditorStore } from './editor-store'
import { Timeline } from './timeline'

function formatTime(t: number): string {
  const s = Math.floor(t)
  const m = Math.floor(s / 60)
  return `${m}:${String(s % 60).padStart(2, '0')}`
}

export function PreviewPlayer({ watermark }: { watermark: boolean }) {
  const project = useEditorStore((s) => s.project)
  const selectScene = useEditorStore((s) => s.selectScene)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const audioRef = useRef<HTMLAudioElement | null>(null)
  const timeRef = useRef(0)

  const [fontsReady, setFontsReady] = useState(false)
  const [images, setImages] = useState<Map<string, CanvasImageSource>>(new Map())
  const [audioLoaded, setAudioLoaded] = useState<{
    fileId: string
    duration: number
    objectUrl: string
  } | null>(null)
  const [playing, setPlaying] = useState(false)
  const [time, setTime] = useState(0)
  const [muted, setMuted] = useState(false)
  const [zoom, setZoom] = useState('fit')
  // Before the user interacts, show a "poster" frame where text is visible
  // (at t=0 most entrance animations haven't revealed anything yet).
  const posterModeRef = useRef(true)

  // Fonts.
  useEffect(() => {
    let cancelled = false
    ensureProjectFontsLoaded(project.style.fontId, [project.style.fontWeight]).then(() => {
      if (!cancelled) setFontsReady(true)
    })
    return () => {
      cancelled = true
    }
  }, [project.style.fontId, project.style.fontWeight])

  // Images (background + logo) — stale entries are harmless because the
  // renderer only consults the map for the currently configured ids.
  const imageIds = [
    project.background.type === 'image' ? project.background.imageFileId : null,
    project.brand.logoFileId,
  ].filter(Boolean) as string[]
  const imageKey = imageIds.join(',')
  useEffect(() => {
    if (!imageKey) return
    let cancelled = false
    const ids = imageKey.split(',').filter(Boolean)
    Promise.all(ids.map(async (id) => [id, await loadImageAsset(id)] as const)).then((entries) => {
      if (cancelled) return
      const map = new Map<string, CanvasImageSource>()
      for (const [id, img] of entries) {
        if (img) map.set(id, img)
      }
      setImages(map)
    })
    return () => {
      cancelled = true
    }
  }, [imageKey])

  const bgMissing =
    project.background.type === 'image' &&
    !!project.background.imageFileId &&
    images.size > 0 &&
    !images.has(project.background.imageFileId)

  // Audio decode + duration (for sync timing mode). The loaded entry is only
  // used while it matches the current track, so no reset is needed.
  const audioFileId = project.audio?.fileId ?? null
  useEffect(() => {
    if (!audioFileId) return
    let cancelled = false
    const resolve = async () => {
      const cached = getCachedAudio(audioFileId)
      if (cached) return cached
      return loadAudioAsset(audioFileId)
    }
    resolve().then((loaded) => {
      if (cancelled || !loaded) return
      setAudioLoaded({ fileId: audioFileId, duration: loaded.buffer.duration, objectUrl: loaded.objectUrl })
    })
    return () => {
      cancelled = true
    }
  }, [audioFileId])

  const activeAudio = audioLoaded && audioLoaded.fileId === audioFileId ? audioLoaded : null
  const audioDuration = project.audio && activeAudio ? activeAudio.duration : null
  const renderer = useMemo(
    () =>
      fontsReady
        ? createRenderer(project, {
            watermark,
            images,
            audioDuration: audioFileId ? audioDuration : null,
          })
        : null,
    [project, fontsReady, images, watermark, audioFileId, audioDuration]
  )

  const duration = renderer?.duration ?? 0

  // Audio element setup.
  useEffect(() => {
    if (!activeAudio) {
      audioRef.current?.pause()
      audioRef.current = null
      return
    }
    let el = audioRef.current
    if (!el || el.dataset.fileId !== activeAudio.fileId) {
      el?.pause()
      el = new Audio(activeAudio.objectUrl)
      el.preload = 'auto'
      el.dataset.fileId = activeAudio.fileId
      audioRef.current = el
    }
    return () => {
      el?.pause()
    }
  }, [activeAudio])

  // Pure canvas draw (no React state updates). Letterbox-fits the project
  // into whatever pixel size the canvas currently has.
  const drawCanvas = useCallback(
    (t: number) => {
      const canvas = canvasRef.current
      if (!canvas || !renderer) return
      const ctx = canvas.getContext('2d')
      if (!ctx) return
      const base = CANVAS_SIZES[project.format]
      const dpr = Math.min(2, window.devicePixelRatio || 1)
      const rect = canvas.getBoundingClientRect()
      const w = Math.max(1, Math.round(rect.width * dpr))
      const h = Math.max(1, Math.round(rect.height * dpr))
      if (canvas.width !== w || canvas.height !== h) {
        canvas.width = w
        canvas.height = h
      }
      const zoomFactor = zoom === '75' ? 0.75 : zoom === '50' ? 0.5 : 1
      const scale = Math.min(w / base.width, h / base.height) * zoomFactor
      const offsetX = (w - base.width * scale) / 2
      const offsetY = (h - base.height * scale) / 2
      ctx.setTransform(1, 0, 0, 1, 0, 0)
      ctx.clearRect(0, 0, w, h)
      ctx.fillStyle = '#08080a'
      ctx.fillRect(0, 0, w, h)
      ctx.setTransform(scale, 0, 0, scale, offsetX, offsetY)
      renderer.render(ctx, t)
    },
    [renderer, project.format, zoom]
  )

  // Draw + update UI state (used from event handlers and the rAF loop).
  const drawAt = useCallback(
    (t: number) => {
      drawCanvas(t)
      timeRef.current = t
      posterModeRef.current = false
      const sceneIndex = renderer ? renderer.sceneIndexAt(t) : 0
      const scene = project.scenes[sceneIndex]
      if (scene) selectScene(scene.id)
      setTime(t)
    },
    [drawCanvas, renderer, project.scenes, selectScene]
  )

  // Redraw the current frame whenever the project/renderer changes while paused.
  useEffect(() => {
    if (playing) return
    if (posterModeRef.current) {
      // Poster frame: pick a moment mid-first-scene where content is visible.
      const firstSpan = renderer?.spans[0]
      const posterT = firstSpan ? Math.min(firstSpan.start + Math.min(1.3, (firstSpan.end - firstSpan.start) * 0.55), duration) : 0
      drawCanvas(posterT)
    } else {
      drawCanvas(Math.min(timeRef.current, duration || 0))
    }
  }, [drawCanvas, playing, duration, renderer])

  // Playback loop.
  useEffect(() => {
    if (!playing || !renderer || duration <= 0) return
    let raf = 0
    let last = performance.now()
    let t = Math.min(time, duration - 0.001)

    const audio = audioRef.current
    if (audio && project.audio) {
      audio.currentTime = (project.audio.trimStart ?? 0) + t
      audio.volume = project.audio.volume ?? 1
      audio.muted = muted
      void audio.play().catch(() => {})
    }

    const loop = (now: number) => {
      const dt = (now - last) / 1000
      last = now
      t += dt
      if (t >= duration) {
        t = duration
        drawAt(t)
        setPlaying(false)
        audio?.pause()
        setTime(0)
        return
      }
      drawAt(t)
      raf = requestAnimationFrame(loop)
    }
    raf = requestAnimationFrame(loop)
    return () => {
      cancelAnimationFrame(raf)
      audio?.pause()
    }
  }, [playing, renderer, duration, drawAt, muted])

  const togglePlay = () => {
    if (duration <= 0) return
    if (playing) {
      setPlaying(false)
      audioRef.current?.pause()
    } else {
      if (time >= duration - 0.01) setTime(0)
      posterModeRef.current = false
      timeRef.current = time >= duration - 0.01 ? 0 : timeRef.current
      setPlaying(true)
    }
  }

  const restart = () => {
    setPlaying(false)
    setTime(0)
    requestAnimationFrame(() => drawAt(0))
  }

  const onScrub = (value: number[]) => {
    setPlaying(false)
    audioRef.current?.pause()
    drawAt(value[0])
  }

  const seekTo = useCallback(
    (t: number) => {
      setPlaying(false)
      audioRef.current?.pause()
      drawAt(t)
    },
    [drawAt]
  )

  const toggleMute = () => {
    const next = !muted
    setMuted(next)
    if (audioRef.current) audioRef.current.muted = next
  }

  const currentSceneIndex = renderer ? renderer.sceneIndexAt(time) : 0

  return (
    <div className="flex h-full min-h-0 flex-col gap-3">
      <div className="relative min-h-0 flex-1 overflow-hidden rounded-lg border border-border/70 bg-[#08080a]">
        {bgMissing && (
          <div className="absolute left-1/2 top-2 z-10 -translate-x-1/2 rounded-md border border-destructive/40 bg-destructive/15 px-3 py-1 text-xs text-red-300">
            Background image unavailable — showing solid color instead
          </div>
        )}
        <canvas
          ref={canvasRef}
          className="absolute inset-0 h-full w-full"
          aria-label="Video preview"
          role="img"
        />
      </div>

      {/* Controls */}
      <div className="flex flex-wrap items-center gap-2 rounded-lg border border-border/70 bg-card px-3 py-2">
        <Button
          variant="secondary"
          size="icon"
          onClick={togglePlay}
          disabled={duration <= 0}
          aria-label={playing ? 'Pause preview' : 'Play preview'}
          className="h-9 w-9"
        >
          {playing ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
        </Button>
        <Button
          variant="ghost"
          size="icon"
          onClick={restart}
          disabled={duration <= 0}
          aria-label="Restart preview"
          className="h-9 w-9"
        >
          <RotateCcw className="h-4 w-4" />
        </Button>

        <span className="w-fit shrink-0 font-mono text-xs tabular-nums text-muted-foreground">
          {formatTime(time)} / {formatTime(duration)}
        </span>

        <div className="min-w-[120px] flex-1">
          <Slider
            value={[Math.min(time, duration)]}
            max={Math.max(0.1, duration)}
            step={0.05}
            onValueChange={onScrub}
            aria-label="Timeline position"
          />
        </div>

        <span className="hidden shrink-0 rounded-md bg-secondary px-2 py-1 text-xs text-secondary-foreground sm:inline">
          Scene {Math.min(currentSceneIndex + 1, project.scenes.length)} of {project.scenes.length}
        </span>

        {audioLoaded && (
          <Button variant="ghost" size="icon" onClick={toggleMute} aria-label={muted ? 'Unmute audio' : 'Mute audio'} className="h-9 w-9">
            {muted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
          </Button>
        )}

        <Select value={zoom} onValueChange={setZoom}>
          <SelectTrigger size="sm" className="h-9 w-[4.5rem] shrink-0" aria-label="Preview size">
            <Maximize2 className="h-3.5 w-3.5" aria-hidden="true" />
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="fit">Fit</SelectItem>
            <SelectItem value="75">75%</SelectItem>
            <SelectItem value="50">50%</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Scene timeline */}
      <Timeline time={time} duration={duration} onSeek={seekTo} />
    </div>
  )
}
