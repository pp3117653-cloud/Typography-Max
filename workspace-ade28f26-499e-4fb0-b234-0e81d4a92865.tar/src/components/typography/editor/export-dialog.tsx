'use client'

// Export dialog: real MP4 export powered by WebCodecs, with a server-side
// export job for limits/history, live progress, upload, download and retry.

import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import {
  AlertTriangle,
  Check,
  Crown,
  Download,
  Film,
  Loader2,
  RefreshCw,
  X,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Label } from '@/components/ui/label'
import { Progress } from '@/components/ui/progress'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { toast } from 'sonner'
import { cn } from '@/lib/utils'
import { useEditorStore } from './editor-store'
import { useSession, useUsage } from '@/hooks/use-session'
import { navigate, currentHashPath } from '@/hooks/use-hash-route'
import { apiSend, ApiError } from '@/lib/api-client'
import { RESOLUTIONS, resolutionAllowed } from '@/lib/typography/plans'
import {
  encodeProjectToMp4,
  estimateExportTime,
  exportDimensions,
  webCodecsSupported,
} from '@/lib/client/encode'
import { getCachedAudio, getCachedImage, loadAudioAsset } from '@/lib/client/assets'

type Phase = 'setup' | 'rendering' | 'uploading' | 'success' | 'error'

export function ExportDialog({
  open,
  onOpenChange,
}: {
  open: boolean
  onOpenChange: (open: boolean) => void
}) {
  const project = useEditorStore((s) => s.project)
  const projectId = useEditorStore((s) => s.projectId)
  const projectName = useEditorStore((s) => s.projectName)
  const { user, plan } = useSession()
  const { usage, isLoading: usageLoading } = useUsage()

  const [resolution, setResolution] = useState<'720' | '1080' | '2160'>('720')
  const [phase, setPhase] = useState<Phase>('setup')
  const [progress, setProgress] = useState(0)
  const [error, setError] = useState<string | null>(null)
  const [estimateSec, setEstimateSec] = useState<number | null>(null)
  const [result, setResult] = useState<{
    sizeBytes: number
    durationSec: number
    url: string
    historySaved: boolean
    audioIntended: boolean
    audioMuxed: 'aac' | 'opus' | null
  } | null>(null)
  const [upgradeMsg, setUpgradeMsg] = useState<string | null>(null)
  const cancelRef = useRef(false)
  const downloadUrlRef = useRef<string | null>(null)

  const dimensions = useMemo(() => exportDimensions(project, resolution), [project, resolution])
  const exportsLeft = usage ? Math.max(0, usage.exportsLimit - usage.exportsUsed) : null
  const watermarked = plan.watermark

  useEffect(() => {
    if (!open) {
      // Reset when closed (keep last download URL alive for the session).
      if (phase !== 'success') cancelRef.current = true
      setPhase('setup')
      setProgress(0)
      setError(null)
      setUpgradeMsg(null)
    } else {
      cancelRef.current = false
    }
  }, [open])

  // Honest time estimate from a live render benchmark.
  useEffect(() => {
    if (!open || phase !== 'setup') return
    let cancelled = false
    estimateExportTime(project, resolution).then((sec) => {
      if (!cancelled) setEstimateSec(sec)
    })
    return () => {
      cancelled = true
    }
  }, [open, phase, project, resolution])

  const needsAuth = !user

  const startExport = useCallback(async () => {
    if (needsAuth) {
      toast.info('Create a free account to export your video — it takes 20 seconds.')
      navigate(`/signup?returnTo=${encodeURIComponent(currentHashPath())}`)
      onOpenChange(false)
      return
    }
    if (!webCodecsSupported()) {
      setError(
        'This browser cannot encode MP4 video. Please use the latest Chrome, Edge or Opera on desktop.'
      )
      setPhase('error')
      return
    }

    setUpgradeMsg(null)
    setError(null)
    setProgress(0)
    setPhase('rendering')
    cancelRef.current = false

    // 1) Create the server-side job (checks plan limits).
    let jobId: string
    try {
      const res = await apiSend<{ job: { id: string } }>('POST', '/api/export-jobs', {
        projectId,
        projectName,
        resolution,
      })
      jobId = res.job.id
    } catch (err) {
      if (err instanceof ApiError && err.status === 402) {
        setUpgradeMsg(err.message)
        setPhase('setup')
        return
      }
      setError(err instanceof Error ? err.message : 'Could not start the export.')
      setPhase('error')
      return
    }

    // 2) Load audio + images for the render.
    let audioBuffer: AudioBuffer | null = null
    if (project.audio) {
      const loaded = getCachedAudio(project.audio.fileId) ?? (await loadAudioAsset(project.audio.fileId))
      audioBuffer = loaded?.buffer ?? null
      if (project.audio && !loaded) {
        toast.warning('Your audio could not be loaded — exporting video only.')
      }
    }
    const images = new Map<string, CanvasImageSource>()
    if (project.background.type === 'image' && project.background.imageFileId) {
      const img = getCachedImage(project.background.imageFileId)
      if (img) images.set(project.background.imageFileId, img)
    }
    if (project.brand.logoFileId) {
      const logo = getCachedImage(project.brand.logoFileId)
      if (logo) images.set(project.brand.logoFileId, logo)
    }

    // 3) Encode locally with the exact preview renderer.
    let blob: Blob
    let durationSec: number
    let audioIntended = false
    let audioMuxed: 'aac' | 'opus' | null = null
    try {
      const encoded = await encodeProjectToMp4({
        project,
        resolution,
        watermark: watermarked,
        images,
        audioBuffer,
        audioVolume: project.audio?.volume ?? 1,
        audioTrimStart: project.audio?.trimStart ?? 0,
        audioTrimEnd: project.audio?.trimEnd ?? null,
        onProgress: (p) => setProgress(Math.round(p * 90)),
        shouldCancel: () => cancelRef.current,
      })
      blob = encoded.blob
      durationSec = encoded.durationSec
      audioIntended = encoded.audioIntended
      audioMuxed = encoded.audioMuxed
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Export failed.'
      setError(message)
      setPhase('error')
      void apiSend('PATCH', `/api/export-jobs/${jobId}`, {
        status: 'failed',
        error: message.slice(0, 400),
      }).catch(() => {})
      return
    }

    // 4) Deliver the file immediately…
    if (downloadUrlRef.current) URL.revokeObjectURL(downloadUrlRef.current)
    const url = URL.createObjectURL(blob)
    downloadUrlRef.current = url
    setResult({ sizeBytes: blob.size, durationSec, url, historySaved: false, audioIntended, audioMuxed })

    // 5) …and store it in export history.
    setPhase('uploading')
    try {
      const form = new FormData()
      form.set('file', new File([blob], 'export.mp4', { type: 'video/mp4' }))
      form.set('durationSec', String(durationSec))
      const uploadRes = await fetch(`/api/export-jobs/${jobId}/upload`, {
        method: 'POST',
        credentials: 'same-origin',
        body: form,
      })
      if (!uploadRes.ok) {
        const detail = (await uploadRes.json().catch(() => null)) as { error?: string } | null
        throw new Error(detail?.error ?? 'Upload failed')
      }
      setProgress(100)
      setResult((prev) => (prev ? { ...prev, historySaved: true } : prev))
      setPhase('success')
      toast.success('Export complete — your video is downloading and saved to your history.')
      if (audioIntended && !audioMuxed) {
        toast.warning(
          'Your audio could not be embedded — this browser has no audio encoder. The exported video is silent.',
          { duration: 8000 }
        )
      }
    } catch (err) {
      // The video itself is fine — only the history upload failed. Be honest
      // about it on the success screen (and keep the job marked failed).
      setProgress(100)
      setResult((prev) => (prev ? { ...prev, historySaved: false } : prev))
      setPhase('success')
      toast.warning(
        'Your video downloaded, but saving it to export history failed. You can still download it again from this dialog.'
      )
      void apiSend('PATCH', `/api/export-jobs/${jobId}`, {
        status: 'failed',
        error: 'History upload failed — file delivered directly.',
      }).catch(() => {})
    }
  }, [needsAuth, projectId, projectName, resolution, project, watermarked, onOpenChange])

  const triggerDownload = () => {
    if (!result?.url) return
    const a = document.createElement('a')
    a.href = result.url
    a.download = `${projectName.replace(/[^a-z0-9\-_ ]/gi, '').trim() || 'typography-video'}-${resolution}p.mp4`
    document.body.appendChild(a)
    a.click()
    a.remove()
  }

  const retry = () => {
    setPhase('setup')
    setError(null)
    setResult(null)
  }

  const busy = phase === 'rendering' || phase === 'uploading'

  return (
    <Dialog open={open} onOpenChange={(next) => !busy && onOpenChange(next)}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Film className="h-4 w-4 text-brand" aria-hidden="true" />
            Export video
          </DialogTitle>
          <DialogDescription>
            MP4 · {dimensions.width}×{dimensions.height} · rendered on your device, saved to your history.
          </DialogDescription>
        </DialogHeader>

        {phase === 'setup' && (
          <div className="space-y-4">
            {!webCodecsSupported() && (
              <div className="flex items-start gap-2 rounded-md border border-destructive/50 bg-destructive/10 px-3 py-2.5 text-xs text-red-300" role="alert">
                <AlertTriangle className="mt-0.5 h-3.5 w-3.5 shrink-0" aria-hidden="true" />
                This browser can&apos;t encode MP4 video. Use the latest Chrome, Edge or Opera on desktop to export.
              </div>
            )}

            {upgradeMsg && (
              <div className="rounded-md border border-brand/50 bg-brand/10 p-3 text-xs" role="alert">
                <p>{upgradeMsg}</p>
                <div className="mt-2 flex flex-wrap gap-2">
                  <Button
                    size="sm"
                    onClick={() => {
                      navigate('/billing')
                      onOpenChange(false)
                    }}
                  >
                    <Crown className="mr-1 h-3.5 w-3.5" aria-hidden="true" /> Upgrade now
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => {
                      navigate('/pricing')
                      onOpenChange(false)
                    }}
                  >
                    View pricing
                  </Button>
                </div>
                <p className="mt-2 text-muted-foreground">
                  Plans start at ₹499/month — no watermark, 1080p and more exports.
                </p>
              </div>
            )}

            <div className="space-y-2">
              <Label htmlFor="export-resolution">Resolution</Label>
              <Select value={resolution} onValueChange={(v) => setResolution(v as '720' | '1080' | '2160')}>
                <SelectTrigger id="export-resolution" className="w-full">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {RESOLUTIONS.map((res) => {
                    const allowed = user ? resolutionAllowed(plan.id, res.id) : res.id === '720'
                    return (
                      <SelectItem key={res.id} value={res.id} disabled={!allowed}>
                        {res.label}
                        {!allowed && ' (upgrade)'}
                      </SelectItem>
                    )
                  })}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-1.5 rounded-md border border-border/60 bg-secondary/30 p-3 text-xs">
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Watermark</span>
                {watermarked ? (
                  <span className="flex items-center gap-1.5">
                    <span className="text-amber-400">Yes (free plan)</span>
                    <button
                      className="text-brand hover:underline"
                      onClick={() => {
                        if (!user) {
                          toast.info('Create a free account first, then upgrade to remove the watermark.')
                          navigate(`/signup?returnTo=${encodeURIComponent(currentHashPath())}`)
                          onOpenChange(false)
                        } else {
                          navigate('/billing')
                          onOpenChange(false)
                        }
                      }}
                    >
                      Remove
                    </button>
                  </span>
                ) : (
                  <span className="flex items-center gap-1 text-emerald-400">
                    <Check className="h-3 w-3" aria-hidden="true" /> None
                  </span>
                )}
              </div>
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Exports this month</span>
                <span className="tabular-nums">
                  {usageLoading || !usage
                    ? '…'
                    : `${usage.exportsUsed} of ${usage.exportsLimit} used · ${exportsLeft} left`}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Estimated render time</span>
                <span>{estimateSec === null ? 'Measuring…' : `~${estimateSec}s on this device`}</span>
              </div>
            </div>

            <Button className="w-full" onClick={startExport} disabled={!webCodecsSupported()}>
              {needsAuth ? 'Create account to export' : `Export ${resolution}p MP4`}
            </Button>
            {needsAuth && (
              <p className="text-center text-[11px] text-muted-foreground">
                Free plan: 5 exports/month with watermark. No credit card needed.
              </p>
            )}
          </div>
        )}

        {busy && (
          <div className="space-y-4 py-2" aria-live="polite">
            <div className="flex items-center gap-3">
              <Loader2 className="h-5 w-5 animate-spin text-brand" aria-hidden="true" />
              <div>
                <p className="text-sm font-medium">
                  {phase === 'rendering' ? 'Rendering your video…' : 'Saving to your history…'}
                </p>
                <p className="text-xs text-muted-foreground">
                  {phase === 'rendering'
                    ? 'Encoding happens on your device — keep this tab open.'
                    : 'Almost done.'}
                </p>
              </div>
            </div>
            <Progress value={phase === 'uploading' ? 92 : progress} aria-label="Export progress" />
            <p className="text-center text-xs tabular-nums text-muted-foreground">
              {phase === 'uploading' ? '' : `${progress}%`}
            </p>
            <Button
              variant="ghost"
              size="sm"
              className="w-full text-muted-foreground"
              onClick={() => {
                cancelRef.current = true
                setPhase('setup')
                setProgress(0)
              }}
            >
              <X className="mr-1.5 h-3.5 w-3.5" aria-hidden="true" /> Cancel
            </Button>
          </div>
        )}

        {phase === 'success' && result && (
          <div className="space-y-4 py-2" aria-live="polite">
            <div className="flex items-center gap-3">
              <span className="flex h-10 w-10 items-center justify-center rounded-full bg-emerald-500/15">
                <Check className="h-5 w-5 text-emerald-400" aria-hidden="true" />
              </span>
              <div>
                <p className="text-sm font-medium">Your video is ready</p>
                <p className="text-xs text-muted-foreground">
                  {(result.sizeBytes / 1024 / 1024).toFixed(1)} MB · {result.durationSec.toFixed(1)}s · {resolution}p
                </p>
              </div>
            </div>
            <Button className="w-full" onClick={triggerDownload}>
              <Download className="mr-2 h-4 w-4" aria-hidden="true" /> Download MP4
            </Button>
            {result.audioIntended && !result.audioMuxed && (
              <p
                className="rounded-md border border-amber-500/40 bg-amber-500/10 px-3 py-2 text-center text-[11px] leading-relaxed text-amber-300"
                role="status"
              >
                Your audio could not be embedded (this browser has no audio encoder) — the exported
                video is silent.
              </p>
            )}
            {result.historySaved ? (
              <p className="text-center text-[11px] text-muted-foreground">
                Also saved to your export history (kept for 7 days) — find it on your dashboard.
              </p>
            ) : (
              <p
                className="rounded-md border border-amber-500/40 bg-amber-500/10 px-3 py-2 text-center text-[11px] leading-relaxed text-amber-300"
                role="status"
              >
                Your video downloaded, but it could not be saved to your export history. Download it
                again from this dialog before closing it.
              </p>
            )}
            <Button variant="outline" className="w-full" onClick={() => onOpenChange(false)}>
              Back to editor
            </Button>
          </div>
        )}

        {phase === 'error' && (
          <div className="space-y-4 py-2" role="alert">
            <div className="flex items-start gap-3">
              <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-destructive/15">
                <AlertTriangle className="h-5 w-5 text-destructive" aria-hidden="true" />
              </span>
              <div>
                <p className="text-sm font-medium">Export failed</p>
                <p className="mt-0.5 text-xs leading-relaxed text-muted-foreground">{error}</p>
              </div>
            </div>
            <Button className="w-full" onClick={retry}>
              <RefreshCw className="mr-2 h-4 w-4" aria-hidden="true" /> Try again
            </Button>
          </div>
        )}
      </DialogContent>
    </Dialog>
  )
}
