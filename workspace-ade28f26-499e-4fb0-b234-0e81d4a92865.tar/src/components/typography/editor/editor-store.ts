'use client'

// Editor state store (Zustand). Holds the project being edited plus
// editor UI state. Persistence/autosave is driven by editor-view.

import { create } from 'zustand'
import type {
  AnimationStyle,
  BackgroundStyle,
  BrandSettings,
  CanvasFormat,
  ProjectData,
  Scene,
  TypographyStyle,
} from '@/lib/typography/types'
import { defaultProject, estimateDuration, makeScene, splitScriptIntoScenes, applyTemplateDesign } from '@/lib/typography/defaults'
import type { TemplateDef } from '@/lib/typography/templates'
import { getFontDef } from '@/lib/typography/fonts'

export type SaveState = 'saved' | 'saving' | 'unsaved' | 'guest' | 'error'

interface EditorState {
  projectId: string | null
  projectName: string
  project: ProjectData
  selectedSceneId: string | null
  saveState: SaveState
  loaded: boolean
  loadError: string | null

  init: (opts: { projectId: string | null; project: ProjectData; name: string }) => void
  setLoadError: (message: string | null) => void
  setSaveState: (state: SaveState) => void
  setProjectName: (name: string) => void
  touch: () => void

  updateStyle: (patch: Partial<TypographyStyle>) => void
  updateBackground: (patch: Partial<BackgroundStyle>) => void
  updateAnimation: (patch: Partial<AnimationStyle>) => void
  updateBrand: (patch: Partial<BrandSettings>) => void
  setFormat: (format: CanvasFormat) => void
  setAudio: (audio: ProjectData['audio']) => void

  selectScene: (id: string | null) => void
  addScene: (afterId?: string) => void
  deleteScene: (id: string) => void
  duplicateScene: (id: string) => void
  moveScene: (id: string, direction: -1 | 1) => void
  updateSceneText: (id: string, text: string) => void
  updateSceneDuration: (id: string, duration: number) => void
  autoDuration: (id: string) => void
  replaceScenes: (texts: string[]) => void

  applyTemplate: (template: TemplateDef) => void
}

function withProject(state: EditorState, mutate: (p: ProjectData) => ProjectData): Partial<EditorState> {
  return { project: mutate(state.project), saveState: state.loaded ? 'unsaved' : state.saveState }
}

export const useEditorStore = create<EditorState>((set, get) => ({
  projectId: null,
  projectName: 'Untitled video',
  project: defaultProject(),
  selectedSceneId: null,
  saveState: 'guest',
  loaded: false,
  loadError: null,

  init: ({ projectId, project, name }) =>
    set({
      projectId,
      projectName: name,
      project,
      selectedSceneId: project.scenes[0]?.id ?? null,
      saveState: projectId ? 'saved' : 'guest',
      loaded: true,
      loadError: null,
    }),

  setLoadError: (message) => set({ loadError: message, loaded: true }),
  setSaveState: (saveState) => set({ saveState }),
  setProjectName: (name) => set({ projectName: name, saveState: get().projectId ? 'unsaved' : get().saveState }),

  touch: () => set((s) => (s.loaded ? { saveState: s.projectId ? 'unsaved' : 'guest' } : {})),

  updateStyle: (patch) =>
    set((s) => {
      let next = { ...s.project.style, ...patch }
      // Keep weight valid for the selected font.
      if (patch.fontId && patch.fontId !== s.project.style.fontId) {
        const def = getFontDef(patch.fontId)
        if (!def.weights.includes(next.fontWeight)) next = { ...next, fontWeight: def.defaultWeight }
      }
      return withProject(s, (p) => ({ ...p, style: next }))
    }),

  updateBackground: (patch) =>
    set((s) => withProject(s, (p) => ({ ...p, background: { ...p.background, ...patch } }))),

  updateAnimation: (patch) =>
    set((s) => withProject(s, (p) => ({ ...p, animation: { ...p.animation, ...patch } }))),

  updateBrand: (patch) =>
    set((s) => withProject(s, (p) => ({ ...p, brand: { ...p.brand, ...patch } }))),

  setFormat: (format) =>
    set((s) => withProject(s, (p) => ({ ...p, format }))),

  setAudio: (audio) => set((s) => withProject(s, (p) => ({ ...p, audio }))),

  selectScene: (id) => set({ selectedSceneId: id }),

  addScene: (afterId) =>
    set((s) => {
      const scene = makeScene('New scene')
      const scenes = [...s.project.scenes]
      const index = afterId ? scenes.findIndex((sc) => sc.id === afterId) : scenes.length - 1
      scenes.splice(index + 1, 0, scene)
      return {
        ...withProject(s, (p) => ({ ...p, scenes })),
        selectedSceneId: scene.id,
      }
    }),

  deleteScene: (id) =>
    set((s) => {
      if (s.project.scenes.length <= 1) return {}
      const scenes = s.project.scenes.filter((sc) => sc.id !== id)
      const selectedSceneId =
        s.selectedSceneId === id ? (scenes[Math.max(0, scenes.length - 1)]?.id ?? null) : s.selectedSceneId
      return { ...withProject(s, (p) => ({ ...p, scenes })), selectedSceneId }
    }),

  duplicateScene: (id) =>
    set((s) => {
      const index = s.project.scenes.findIndex((sc) => sc.id === id)
      if (index < 0) return {}
      const source = s.project.scenes[index]
      const copy: Scene = {
        id: `s_${Math.random().toString(36).slice(2, 9)}`,
        text: source.text,
        duration: source.duration,
      }
      const scenes = [...s.project.scenes]
      scenes.splice(index + 1, 0, copy)
      return { ...withProject(s, (p) => ({ ...p, scenes })), selectedSceneId: copy.id }
    }),

  moveScene: (id, direction) =>
    set((s) => {
      const index = s.project.scenes.findIndex((sc) => sc.id === id)
      const target = index + direction
      if (index < 0 || target < 0 || target >= s.project.scenes.length) return {}
      const scenes = [...s.project.scenes]
      const [item] = scenes.splice(index, 1)
      scenes.splice(target, 0, item)
      return withProject(s, (p) => ({ ...p, scenes }))
    }),

  updateSceneText: (id, text) =>
    set((s) =>
      withProject(s, (p) => ({
        ...p,
        scenes: p.scenes.map((sc) => (sc.id === id ? { ...sc, text } : sc)),
      }))
    ),

  updateSceneDuration: (id, duration) =>
    set((s) =>
      withProject(s, (p) => ({
        ...p,
        scenes: p.scenes.map((sc) =>
          sc.id === id ? { ...sc, duration: Math.min(30, Math.max(0.5, Number(duration.toFixed(1)))) } : sc
        ),
      }))
    ),

  autoDuration: (id) =>
    set((s) =>
      withProject(s, (p) => ({
        ...p,
        scenes: p.scenes.map((sc) => (sc.id === id ? { ...sc, duration: Number(estimateDuration(sc.text).toFixed(1)) } : sc)),
      }))
    ),

  replaceScenes: (texts) =>
    set((s) => {
      const scenes = splitScriptIntoScenes(texts.join('\n\n'))
      const finalScenes = scenes.length ? scenes : [makeScene(texts.join(' '))]
      return {
        ...withProject(s, (p) => ({ ...p, scenes: finalScenes })),
        selectedSceneId: finalScenes[0]?.id ?? null,
      }
    }),

  applyTemplate: (template) =>
    set((s) => withProject(s, (p) => applyTemplateDesign(p, template.design))),
}))

export function useSelectedScene(): Scene | null {
  return useEditorStore((s) => s.project.scenes.find((sc) => sc.id === s.selectedSceneId) ?? null)
}
