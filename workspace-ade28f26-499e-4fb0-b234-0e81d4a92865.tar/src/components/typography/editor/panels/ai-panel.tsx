'use client'

// AI tools panel: script→scenes, hooks, platform rewrites, titles/captions,
// style suggestions, quote variants, storyboards. Results are always editable
// and never applied without an explicit user action.

import { useState } from 'react'
import {
  Check,
  ClipboardCopy,
  Lightbulb,
  Loader2,
  RefreshCw,
  Sparkles,
  Type,
  Wand2,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import { toast } from 'sonner'
import { cn } from '@/lib/utils'
import { useEditorStore } from '../editor-store'
import { apiSend } from '@/lib/api-client'
import { getFontDef } from '@/lib/typography/fonts'
import { useSession } from '@/hooks/use-session'
import { navigate, currentHashPath } from '@/hooks/use-hash-route'

type ToolId =
  | 'split-script'
  | 'hook'
  | 'rewrite-platform'
  | 'titles'
  | 'style-suggest'
  | 'quote-variants'
  | 'storyboard'

interface ToolDef {
  id: ToolId
  label: string
  description: string
  icon: typeof Sparkles
}

const TOOLS: ToolDef[] = [
  { id: 'split-script', label: 'Script → scenes', description: 'Turn a long script into tight scenes', icon: Wand2 },
  { id: 'hook', label: 'Stronger hooks', description: '3 scroll-stopping opening lines', icon: Lightbulb },
  { id: 'rewrite-platform', label: 'Rewrite for platform', description: 'Adapt pacing for TikTok, Reels or Shorts', icon: RefreshCw },
  { id: 'titles', label: 'Titles & captions', description: 'Title, caption and hashtags', icon: Type },
  { id: 'style-suggest', label: 'Suggest a style', description: 'Typography style based on your tone', icon: Sparkles },
  { id: 'quote-variants', label: 'Quote variations', description: '3 tighter cuts of your quote', icon: RefreshCw },
  { id: 'storyboard', label: 'Storyboard', description: 'Scene-by-scene plan with pacing notes', icon: Wand2 },
]

type AiResult =
  | { kind: 'scenes'; items: string[]; notes?: (string | undefined)[] }
  | { kind: 'options'; items: string[] }
  | { kind: 'titles'; title: string; caption: string; hashtags: string[] }
  | { kind: 'style'; data: Record<string, unknown>; mood: string }

export function AiPanel() {
  const project = useEditorStore((s) => s.project)
  const selectedSceneId = useEditorStore((s) => s.selectedSceneId)
  const replaceScenes = useEditorStore((s) => s.replaceScenes)
  const updateSceneText = useEditorStore((s) => s.updateSceneText)
  const updateStyle = useEditorStore((s) => s.updateStyle)
  const updateBackground = useEditorStore((s) => s.updateBackground)
  const updateAnimation = useEditorStore((s) => s.updateAnimation)
  const addScene = useEditorStore((s) => s.addScene)
  const { user } = useSession()

  const defaultInput = () => {
    const selected = project.scenes.find((s) => s.id === selectedSceneId)
    return selected?.text || project.scenes.map((s) => s.text).join('\n\n')
  }

  const [tool, setTool] = useState<ToolId>('split-script')
  const [platform, setPlatform] = useState<'tiktok' | 'reels' | 'shorts'>('tiktok')
  const [input, setInput] = useState(defaultInput)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [result, setResult] = useState<AiResult | null>(null)
  const [copied, setCopied] = useState<string | null>(null)

  const currentText = project.scenes.map((s) => s.text).join('\n\n')

  const runTool = async () => {
    if (!user) {
      toast.error('Create a free account to use AI suggestions.')
      navigate(`/signup?returnTo=${encodeURIComponent(currentHashPath())}`)
      return
    }
    if (!input.trim()) {
      setError('Add some text for the AI to work with.')
      return
    }
    setLoading(true)
    setError(null)
    setResult(null)
    try {
      const res = await apiSend<{ data: unknown; text: string }>('POST', '/api/ai', {
        tool,
        input,
        platform: tool === 'rewrite-platform' ? platform : undefined,
      })
      const parsed = parseResult(tool, res.data)
      if (!parsed) {
        setError('Could not read the AI response. Please retry.')
      } else {
        setResult(parsed)
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'The AI request failed. Please retry.')
    } finally {
      setLoading(false)
    }
  }

  const copy = async (text: string, key: string) => {
    try {
      await navigator.clipboard.writeText(text)
      setCopied(key)
      window.setTimeout(() => setCopied(null), 1200)
    } catch {
      toast.error('Could not copy — select the text and copy manually.')
    }
  }

  return (
    <div className="flex flex-col gap-4">
      <div className="flex items-start gap-2 rounded-md border border-border/70 bg-secondary/40 px-3 py-2.5 text-[11px] leading-relaxed text-muted-foreground" role="note">
        <Sparkles className="mt-0.5 h-3.5 w-3.5 shrink-0 text-brand" aria-hidden="true" />
        <span>
          AI suggestions are editable drafts — review before using. They are not fact-checked and never
          replace your text without your action.
        </span>
      </div>

      {/* Tool picker */}
      <div className="grid grid-cols-1 gap-2" role="group" aria-label="AI tools">
        {TOOLS.map((t) => {
          const Icon = t.icon
          return (
            <button
              key={t.id}
              onClick={() => {
                setTool(t.id)
                setResult(null)
                setError(null)
              }}
              aria-pressed={tool === t.id}
              className={cn(
                'flex items-center gap-2.5 rounded-md border px-3 py-2 text-left transition-colors',
                tool === t.id ? 'border-brand bg-brand/10' : 'border-border/60 hover:border-border'
              )}
            >
              <Icon className={cn('h-4 w-4 shrink-0', tool === t.id ? 'text-brand' : 'text-muted-foreground')} aria-hidden="true" />
              <span className="min-w-0">
                <span className="block text-xs font-medium">{t.label}</span>
                <span className="block truncate text-[11px] text-muted-foreground">{t.description}</span>
              </span>
            </button>
          )
        })}
      </div>

      {tool === 'rewrite-platform' && (
        <div className="flex gap-1.5" role="group" aria-label="Target platform">
          {(['tiktok', 'reels', 'shorts'] as const).map((p) => (
            <button
              key={p}
              onClick={() => setPlatform(p)}
              aria-pressed={platform === p}
              className={cn(
                'rounded-full border px-3 py-1 text-[11px] font-medium capitalize transition-colors',
                platform === p ? 'border-brand bg-brand text-white' : 'border-border/70 text-muted-foreground'
              )}
            >
              {p === 'tiktok' ? 'TikTok' : p === 'reels' ? 'Reels' : 'Shorts'}
            </button>
          ))}
        </div>
      )}

      {/* Input */}
      <div className="space-y-1.5">
        <div className="flex items-center justify-between">
          <label htmlFor="ai-input" className="text-xs font-medium text-muted-foreground">
            Your text
          </label>
          <button
            className="text-[11px] text-brand hover:underline"
            onClick={() => setInput(currentText || '')}
          >
            Use my scenes
          </button>
        </div>
        <Textarea
          id="ai-input"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          rows={4}
          placeholder="Paste or edit the text the AI should work with…"
          className="text-sm"
        />
      </div>

      <Button onClick={runTool} disabled={loading}>
        {loading ? (
          <>
            <Loader2 className="mr-2 h-4 w-4 animate-spin" aria-hidden="true" /> Thinking…
          </>
        ) : (
          <>
            <Sparkles className="mr-2 h-4 w-4" aria-hidden="true" /> Suggest
          </>
        )}
      </Button>

      {error && (
        <div className="rounded-md border border-destructive/50 bg-destructive/10 px-3 py-2.5 text-xs text-red-300" role="alert">
          <p>{error}</p>
          <Button variant="outline" size="sm" className="mt-2" onClick={runTool}>
            <RefreshCw className="mr-1.5 h-3.5 w-3.5" aria-hidden="true" /> Retry
          </Button>
        </div>
      )}

      {/* Results */}
      {result && (
        <div className="space-y-3 rounded-md border border-border/70 bg-secondary/30 p-3" aria-live="polite">
          {result.kind === 'scenes' && (
            <>
              <p className="text-xs font-semibold">
                {result.items.length} suggested scenes — edit, then apply
              </p>
              <div className="space-y-2">
                {result.items.map((scene, i) => (
                  <div key={i} className="space-y-1">
                    <Textarea
                      value={scene}
                      onChange={(e) => {
                        const items = [...result.items]
                        items[i] = e.target.value
                        setResult({ ...result, items })
                      }}
                      rows={2}
                      className="text-xs"
                      aria-label={`Suggested scene ${i + 1}`}
                    />
                    {result.notes?.[i] && (
                      <p className="pl-1 text-[10px] italic text-muted-foreground">{result.notes[i]}</p>
                    )}
                  </div>
                ))}
              </div>
              <div className="flex gap-2">
                <Button
                  size="sm"
                  onClick={() => {
                    replaceScenes(result.items.filter((t) => t.trim()))
                    toast.success(`Replaced scenes with ${result.items.length} AI suggestions`)
                  }}
                >
                  Replace my scenes
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => {
                    result.items.filter((t) => t.trim()).forEach(() => addScene())
                    toast.info('Scenes added below — paste the suggestions into them.')
                  }}
                >
                  Add empty scenes
                </Button>
              </div>
              <p className="text-[10px] text-muted-foreground">
                Replacing overwrites your current scenes — make sure you&apos;re happy with the suggestions first.
              </p>
            </>
          )}

          {result.kind === 'options' && (
            <>
              <p className="text-xs font-semibold">Suggestions</p>
              <div className="space-y-2">
                {result.items.map((option, i) => (
                  <div key={i} className="rounded-md border border-border/60 bg-card px-3 py-2">
                    <p className="text-xs leading-relaxed">{option}</p>
                    <div className="mt-1.5 flex gap-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-7 text-[11px]"
                        onClick={() => copy(option, `opt-${i}`)}
                      >
                        {copied === `opt-${i}` ? (
                          <Check className="mr-1 h-3 w-3" aria-hidden="true" />
                        ) : (
                          <ClipboardCopy className="mr-1 h-3 w-3" aria-hidden="true" />
                        )}
                        Copy
                      </Button>
                      {tool === 'hook' && (
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-7 text-[11px] text-brand"
                          onClick={() => {
                            if (selectedSceneId) {
                              updateSceneText(selectedSceneId, option)
                              toast.success('Replaced the selected scene with this hook')
                            } else {
                              toast.error('Select a scene first')
                            }
                          }}
                        >
                          Use in selected scene
                        </Button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </>
          )}

          {result.kind === 'titles' && (
            <>
              <p className="text-xs font-semibold">Packaging suggestions</p>
              <div className="space-y-2 text-xs">
                <div className="rounded-md border border-border/60 bg-card px-3 py-2">
                  <span className="text-[10px] uppercase tracking-wide text-muted-foreground">Title</span>
                  <p className="mt-0.5">{result.title}</p>
                  <CopyButton text={result.title} onClick={() => copy(result.title, 'title')} copied={copied === 'title'} />
                </div>
                <div className="rounded-md border border-border/60 bg-card px-3 py-2">
                  <span className="text-[10px] uppercase tracking-wide text-muted-foreground">Caption</span>
                  <p className="mt-0.5">{result.caption}</p>
                  <CopyButton text={result.caption} onClick={() => copy(result.caption, 'caption')} copied={copied === 'caption'} />
                </div>
                <div className="rounded-md border border-border/60 bg-card px-3 py-2">
                  <span className="text-[10px] uppercase tracking-wide text-muted-foreground">Hashtags</span>
                  <p className="mt-0.5">{result.hashtags.join(' ')}</p>
                  <CopyButton text={result.hashtags.join(' ')} onClick={() => copy(result.hashtags.join(' '), 'tags')} copied={copied === 'tags'} />
                </div>
              </div>
            </>
          )}

          {result.kind === 'style' && (
            <>
              <p className="text-xs font-semibold">Suggested typography style</p>
              <p className="text-xs italic text-muted-foreground">“{result.mood}”</p>
              <Button
                size="sm"
                onClick={() => {
                  const d = result.data as {
                    fontId?: string
                    fontWeight?: number
                    animationPreset?: string
                    palette?: { textColor?: string; highlightColor?: string; backgroundFrom?: string; backgroundTo?: string }
                  }
                  if (d.fontId) updateStyle({ fontId: d.fontId })
                  if (d.fontWeight) updateStyle({ fontWeight: d.fontWeight })
                  if (d.animationPreset) updateAnimation({ preset: d.animationPreset as never })
                  if (d.palette?.textColor) updateStyle({ textColor: d.palette.textColor })
                  if (d.palette?.highlightColor) updateStyle({ highlightColor: d.palette.highlightColor })
                  if (d.palette?.backgroundFrom && d.palette.backgroundTo) {
                    updateBackground({
                      type: 'gradient',
                      gradientFrom: d.palette.backgroundFrom,
                      gradientTo: d.palette.backgroundTo,
                    })
                  }
                  const fontName = d.fontId ? getFontDef(d.fontId).label : 'new style'
                  toast.success(`Applied the suggested style (${fontName})`)
                }}
              >
                Apply this style
              </Button>
            </>
          )}
        </div>
      )}
    </div>
  )
}

function CopyButton({ onClick, copied, text }: { onClick: () => void; copied: boolean; text: string }) {
  return (
    <Button variant="ghost" size="sm" className="mt-1 h-7 text-[11px]" onClick={onClick} aria-label={`Copy: ${text.slice(0, 40)}`}>
      {copied ? <Check className="mr-1 h-3 w-3" aria-hidden="true" /> : <ClipboardCopy className="mr-1 h-3 w-3" aria-hidden="true" />}
      Copy
    </Button>
  )
}

function parseResult(tool: ToolId, data: unknown): AiResult | null {
  if (!data || typeof data !== 'object') return null
  const d = data as Record<string, unknown>
  try {
    switch (tool) {
      case 'split-script':
      case 'rewrite-platform': {
        const scenes = Array.isArray(d.scenes)
          ? d.scenes
          : Array.isArray(d.lines)
            ? d.lines
            : null
        if (!scenes) return null
        return {
          kind: 'scenes',
          items: scenes.map((s) => (typeof s === 'string' ? s : String((s as { text?: string })?.text ?? ''))),
        }
      }
      case 'hook':
      case 'quote-variants': {
        const items = Array.isArray(d.hooks) ? d.hooks : Array.isArray(d.variants) ? d.variants : null
        if (!items) return null
        return { kind: 'options', items: items.map(String) }
      }
      case 'titles': {
        if (typeof d.title !== 'string' || typeof d.caption !== 'string') return null
        const hashtags = Array.isArray(d.hashtags) ? d.hashtags.map(String) : []
        return { kind: 'titles', title: d.title, caption: d.caption, hashtags }
      }
      case 'style-suggest': {
        return { kind: 'style', data: d, mood: typeof d.mood === 'string' ? d.mood : '' }
      }
      case 'storyboard': {
        const scenes = Array.isArray(d.scenes) ? d.scenes : null
        if (!scenes) return null
        const items = scenes.map((s) =>
          typeof s === 'string' ? s : String((s as { text?: string })?.text ?? '')
        )
        const notes = scenes.map((s) =>
          typeof s === 'object' && s ? String((s as { visualNote?: string })?.visualNote ?? '') : undefined
        )
        return { kind: 'scenes', items, notes }
      }
      default:
        return null
    }
  } catch {
    return null
  }
}
