'use client'

// In-editor template browser: preview before applying, apply design only
// (never touches scene text).

import { useMemo, useState } from 'react'
import { Check, Crown } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { toast } from 'sonner'
import { cn } from '@/lib/utils'
import { useEditorStore } from '../editor-store'
import { TEMPLATES, TEMPLATE_CATEGORIES, type TemplateDef } from '@/lib/typography/templates'
import { TemplatePreview } from '@/components/typography/preview/template-preview'
import { useSession } from '@/hooks/use-session'

export function TemplatesPanel() {
  const project = useEditorStore((s) => s.project)
  const applyTemplate = useEditorStore((s) => s.applyTemplate)
  const { plan } = useSession()
  const [filter, setFilter] = useState<string>('all')
  const [previewTemplate, setPreviewTemplate] = useState<TemplateDef | null>(null)
  const [applied, setApplied] = useState<string | null>(null)

  const visible = useMemo(
    () => TEMPLATES.filter((t) => filter === 'all' || t.category === filter),
    [filter]
  )

  const handleApply = (template: TemplateDef) => {
    if (template.premium && !plan.premiumTemplates) {
      toast.info('This is a premium template — preview it to see how to unlock it.')
    }
    applyTemplate(template)
    setApplied(template.id)
    setPreviewTemplate(null)
    toast.success(`${template.name} design applied — your text is untouched.`)
    window.setTimeout(() => setApplied(null), 1500)
  }

  return (
    <div className="flex flex-col gap-4">
      <p className="text-xs leading-relaxed text-muted-foreground">
        Applying a template changes fonts, colors, background and animation — your scenes and text stay
        exactly as you wrote them.
      </p>

      <div className="flex flex-wrap gap-1.5" role="group" aria-label="Filter templates by category">
        <button
          onClick={() => setFilter('all')}
          aria-pressed={filter === 'all'}
          className={cn(
            'rounded-full border px-2.5 py-1 text-[11px] font-medium transition-colors',
            filter === 'all' ? 'border-brand bg-brand text-white' : 'border-border/70 text-muted-foreground hover:border-border'
          )}
        >
          All
        </button>
        {TEMPLATE_CATEGORIES.map((c) => (
          <button
            key={c.id}
            onClick={() => setFilter(c.id)}
            aria-pressed={filter === c.id}
            className={cn(
              'rounded-full border px-2.5 py-1 text-[11px] font-medium transition-colors',
              filter === c.id ? 'border-brand bg-brand text-white' : 'border-border/70 text-muted-foreground hover:border-border'
            )}
          >
            {c.label}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-2 gap-3">
        {visible.map((template) => {
          const isCurrent = project.templateId === template.id
          const locked = template.premium && !plan.premiumTemplates
          return (
            <div
              key={template.id}
              className={cn(
                'group overflow-hidden rounded-md border transition-colors',
                isCurrent ? 'border-brand/70' : 'border-border/60 hover:border-border'
              )}
            >
              <button
                className="block w-full"
                onClick={() => setPreviewTemplate(template)}
                aria-label={`Preview ${template.name} template`}
              >
                <TemplatePreview template={template} className="w-full bg-card" />
              </button>
              <div className="flex items-center justify-between gap-1 px-2 py-1.5">
                <span className="min-w-0 truncate text-[11px] font-medium">{template.name}</span>
                {isCurrent ? (
                  <Badge className="h-5 bg-brand/20 text-[10px] text-brand">
                    <Check className="mr-0.5 h-3 w-3" aria-hidden="true" /> In use
                  </Badge>
                ) : locked ? (
                  <Crown className="h-3.5 w-3.5 shrink-0 text-brand" aria-label="Premium template" />
                ) : null}
              </div>
            </div>
          )
        })}
      </div>

      {/* Preview dialog */}
      <Dialog open={!!previewTemplate} onOpenChange={(open) => !open && setPreviewTemplate(null)}>
        <DialogContent className="max-w-2xl">
          {previewTemplate && (
            <>
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2">
                  {previewTemplate.name}
                  {previewTemplate.premium ? (
                    <Badge className="bg-brand/20 text-brand">
                      <Crown className="mr-1 h-3 w-3" aria-hidden="true" /> Pro
                    </Badge>
                  ) : null}
                </DialogTitle>
                <DialogDescription>{previewTemplate.description}</DialogDescription>
              </DialogHeader>
              <div className="max-h-[50vh] overflow-y-auto scrollbar-slim">
                <TemplatePreview template={previewTemplate} className="mx-auto w-full max-w-xs bg-card" />
              </div>
              <DialogFooter className="flex-col gap-2 sm:flex-col">
                {previewTemplate.premium && !plan.premiumTemplates ? (
                  <>
                    <Button className="w-full" onClick={() => handleApply(previewTemplate)}>
                      Apply with watermark (free plan)
                    </Button>
                    <p className="text-center text-[11px] text-muted-foreground">
                      Premium templates are included in Creator and above — but you can still try the design
                      on the free plan.
                    </p>
                  </>
                ) : (
                  <Button className="w-full" onClick={() => handleApply(previewTemplate)}>
                    Apply this design
                  </Button>
                )}
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}
