'use client'

// Design panel: fonts, colors + contrast checking, backgrounds, animations,
// canvas format and brand kit (Pro).

import { useMemo, useRef, useState } from 'react'
import {
  AlertTriangle,
  Check,
  Crown,
  Image as ImageIcon,
  Monitor,
  Square,
  Smartphone,
  Upload,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Slider } from '@/components/ui/slider'
import { Switch } from '@/components/ui/switch'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Progress } from '@/components/ui/progress'
import { toast } from 'sonner'
import { cn } from '@/lib/utils'
import { useEditorStore } from '../editor-store'
import { FONTS, FONT_CATEGORIES, getFontDef, resolveFontFamily } from '@/lib/typography/fonts'
import { ANIMATION_PRESETS, getAnimationPreset } from '@/lib/typography/animations'
import { CANVAS_SIZES, type CanvasFormat } from '@/lib/typography/types'
import { checkContrast } from '@/lib/typography/contrast'
import { effectiveBackgroundColor } from '@/lib/typography/render-frame'
import { apiUpload } from '@/lib/api-client'
import { useSession } from '@/hooks/use-session'
import { navigate, currentHashPath } from '@/hooks/use-hash-route'

function ColorField({
  label,
  value,
  onChange,
  id,
}: {
  label: string
  value: string
  onChange: (v: string) => void
  id: string
}) {
  return (
    <div className="flex items-center justify-between gap-3">
      <Label htmlFor={id} className="text-xs">
        {label}
      </Label>
      <div className="flex items-center gap-2">
        <Input
          id={id}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="h-8 w-24 font-mono text-xs"
          aria-label={`${label} hex value`}
        />
        <input
          type="color"
          value={/^#[0-9a-fA-F]{6}$/.test(value) ? value : '#000000'}
          onChange={(e) => onChange(e.target.value)}
          className="h-8 w-8 cursor-pointer rounded-md border border-border bg-transparent p-0.5"
          aria-label={`${label} color picker`}
        />
      </div>
    </div>
  )
}

export function DesignPanel() {
  const project = useEditorStore((s) => s.project)
  const updateStyle = useEditorStore((s) => s.updateStyle)
  const updateBackground = useEditorStore((s) => s.updateBackground)
  const updateAnimation = useEditorStore((s) => s.updateAnimation)
  const updateBrand = useEditorStore((s) => s.updateBrand)
  const setFormat = useEditorStore((s) => s.setFormat)
  const { plan, user } = useSession()

  const [fontFilter, setFontFilter] = useState<string>('all')
  const [uploading, setUploading] = useState<'bg' | 'logo' | null>(null)
  const bgInputRef = useRef<HTMLInputElement>(null)
  const logoInputRef = useRef<HTMLInputElement>(null)

  const style = project.style
  const fontDef = getFontDef(style.fontId)
  const presetDef = getAnimationPreset(project.animation.preset)

  // Effective background color for the contrast checker.
  const bgForContrast = useMemo(() => effectiveBackgroundColor(project), [project])
  const contrast = useMemo(
    () => checkContrast(style.textColor, bgForContrast),
    [style.textColor, bgForContrast]
  )

  const uploadFile = async (file: File, kind: 'image', target: 'bg' | 'logo') => {
    setUploading(target)
    try {
      const form = new FormData()
      form.set('kind', kind)
      form.set('file', file)
      const res = await apiUpload<{ id: string }>('/api/uploads', form)
      if (target === 'bg') {
        updateBackground({ type: 'image', imageFileId: res.id })
        toast.success('Background image applied')
      } else {
        updateBrand({ logoFileId: res.id })
        toast.success('Logo added to your videos')
      }
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Upload failed. Please try again.')
    } finally {
      setUploading(null)
    }
  }

  const visibleFonts = FONTS.filter((f) => fontFilter === 'all' || f.category === fontFilter)

  return (
    <div className="flex flex-col gap-6">
      {/* Format */}
      <section aria-labelledby="format-heading">
        <h3 id="format-heading" className="mb-2 text-sm font-semibold">
          Canvas format
        </h3>
        <div className="grid grid-cols-3 gap-2" role="radiogroup" aria-label="Canvas format">
          {(
            [
              { value: '9:16', label: 'Vertical', dims: '1080×1920', icon: Smartphone },
              { value: '1:1', label: 'Square', dims: '1080×1080', icon: Square },
              { value: '16:9', label: 'Landscape', dims: '1920×1080', icon: Monitor },
            ] as { value: CanvasFormat; label: string; dims: string; icon: typeof Smartphone }[]
          ).map(({ value, label, dims, icon: Icon }) => (
            <button
              key={value}
              role="radio"
              aria-checked={project.format === value}
              onClick={() => setFormat(value)}
              className={cn(
                'flex flex-col items-center gap-1 rounded-md border px-2 py-2.5 text-center transition-colors',
                project.format === value
                  ? 'border-brand bg-brand/10 text-foreground'
                  : 'border-border/70 hover:border-border'
              )}
            >
              <Icon className="h-4 w-4" aria-hidden="true" />
              <span className="text-xs font-medium">{label}</span>
              <span className="text-[10px] text-muted-foreground">{dims}</span>
            </button>
          ))}
        </div>
      </section>

      {/* Typography */}
      <section aria-labelledby="typography-heading" className="space-y-3">
        <h3 id="typography-heading" className="text-sm font-semibold">
          Typography
        </h3>
        <div className="flex items-center justify-between gap-2">
          <Label className="text-xs text-muted-foreground">Font</Label>
          <Select value={fontFilter} onValueChange={setFontFilter}>
            <SelectTrigger size="sm" className="h-7 w-36 text-xs" aria-label="Filter fonts by category">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All categories</SelectItem>
              {FONT_CATEGORIES.map((c) => (
                <SelectItem key={c.id} value={c.id}>
                  {c.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="grid max-h-56 grid-cols-2 gap-2 overflow-y-auto pr-1 scrollbar-slim" role="listbox" aria-label="Font selection">
          {visibleFonts.map((f) => (
            <button
              key={f.id}
              role="option"
              aria-selected={style.fontId === f.id}
              onClick={() => updateStyle({ fontId: f.id })}
              className={cn(
                'rounded-md border px-2.5 py-2 text-left transition-colors',
                style.fontId === f.id ? 'border-brand bg-brand/10' : 'border-border/60 hover:border-border'
              )}
            >
              <span
                className="block truncate text-base leading-tight"
                style={{ fontFamily: resolveFontFamily(f.id), fontWeight: f.defaultWeight }}
              >
                {f.label}
              </span>
              <span className="mt-0.5 block text-[10px] text-muted-foreground">
                {FONT_CATEGORIES.find((c) => c.id === f.category)?.label}
              </span>
            </button>
          ))}
        </div>

        <div className="flex items-center justify-between gap-2">
          <Label htmlFor="font-weight" className="text-xs text-muted-foreground">
            Weight
          </Label>
          <Select
            value={String(style.fontWeight)}
            onValueChange={(v) => updateStyle({ fontWeight: Number(v) })}
          >
            <SelectTrigger id="font-weight" size="sm" className="h-8 w-28 text-xs">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {fontDef.weights.map((w) => (
                <SelectItem key={w} value={String(w)}>
                  {w}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {(
          [
            {
              id: 'font-size',
              label: 'Font size',
              display: `${Math.round(style.fontSize * 1920)}px @1080`,
              min: 0.025,
              max: 0.16,
              step: 0.001,
              value: style.fontSize,
              onChange: (v: number) => updateStyle({ fontSize: v }),
            },
            {
              id: 'letter-spacing',
              label: 'Letter spacing',
              display: `${style.letterSpacing.toFixed(3)}em`,
              min: -0.05,
              max: 0.35,
              step: 0.005,
              value: style.letterSpacing,
              onChange: (v: number) => updateStyle({ letterSpacing: v }),
            },
            {
              id: 'line-height',
              label: 'Line height',
              display: `${style.lineHeight.toFixed(2)}`,
              min: 0.9,
              max: 2.4,
              step: 0.05,
              value: style.lineHeight,
              onChange: (v: number) => updateStyle({ lineHeight: v }),
            },
            {
              id: 'position-y',
              label: 'Vertical position',
              display: `${Math.round(style.positionY * 100)}%`,
              min: 0.1,
              max: 0.9,
              step: 0.01,
              value: style.positionY,
              onChange: (v: number) => updateStyle({ positionY: v }),
            },
            {
              id: 'max-width',
              label: 'Text width',
              display: `${Math.round(style.maxWidth * 100)}%`,
              min: 0.4,
              max: 0.95,
              step: 0.01,
              value: style.maxWidth,
              onChange: (v: number) => updateStyle({ maxWidth: v }),
            },
          ] as const
        ).map((ctl) => (
          <div key={ctl.id} className="space-y-1.5">
            <div className="flex items-center justify-between">
              <Label htmlFor={ctl.id} className="text-xs text-muted-foreground">
                {ctl.label}
              </Label>
              <span className="text-xs tabular-nums text-muted-foreground">{ctl.display}</span>
            </div>
            <Slider
              id={ctl.id}
              aria-label={ctl.label}
              value={[ctl.value]}
              min={ctl.min}
              max={ctl.max}
              step={ctl.step}
              onValueChange={(v) => ctl.onChange(v[0])}
            />
          </div>
        ))}
      </section>

      {/* Colors */}
      <section aria-labelledby="colors-heading" className="space-y-3">
        <h3 id="colors-heading" className="text-sm font-semibold">
          Colors
        </h3>
        <ColorField
          id="text-color"
          label="Text color"
          value={style.textColor}
          onChange={(v) => updateStyle({ textColor: v })}
        />
        <ColorField
          id="highlight-color"
          label="Highlight color"
          value={style.highlightColor}
          onChange={(v) => updateStyle({ highlightColor: v })}
        />
        <div
          className={cn(
            'flex items-start gap-2 rounded-md border px-3 py-2 text-xs',
            contrast.ok ? 'border-border/60 text-muted-foreground' : 'border-destructive/50 bg-destructive/10 text-red-300'
          )}
          role="status"
        >
          {contrast.ok ? (
            <Check className="mt-0.5 h-3.5 w-3.5 shrink-0 text-emerald-400" aria-hidden="true" />
          ) : (
            <AlertTriangle className="mt-0.5 h-3.5 w-3.5 shrink-0" aria-hidden="true" />
          )}
          <span>
            Text contrast: <strong>{contrast.ratio.toFixed(1)}:1</strong> — {contrast.label}
            {!contrast.ok && ' Try a brighter text color or a darker background.'}
          </span>
        </div>
      </section>

      {/* Background */}
      <section aria-labelledby="background-heading" className="space-y-3">
        <h3 id="background-heading" className="text-sm font-semibold">
          Background
        </h3>
        <div className="grid grid-cols-3 gap-1 rounded-md border border-border p-1" role="tablist" aria-label="Background type">
          {(['solid', 'gradient', 'image'] as const).map((type) => (
            <button
              key={type}
              role="tab"
              aria-selected={project.background.type === type}
              onClick={() => updateBackground({ type })}
              className={cn(
                'rounded px-2 py-1.5 text-xs font-medium capitalize transition-colors',
                project.background.type === type ? 'bg-brand text-white' : 'text-muted-foreground hover:bg-accent'
              )}
            >
              {type}
            </button>
          ))}
        </div>

        {project.background.type === 'solid' && (
          <ColorField
            id="bg-color"
            label="Background color"
            value={project.background.color}
            onChange={(v) => updateBackground({ color: v })}
          />
        )}

        {project.background.type === 'gradient' && (
          <div className="space-y-3">
            <ColorField
              id="grad-from"
              label="Gradient from"
              value={project.background.gradientFrom}
              onChange={(v) => updateBackground({ gradientFrom: v })}
            />
            <ColorField
              id="grad-to"
              label="Gradient to"
              value={project.background.gradientTo}
              onChange={(v) => updateBackground({ gradientTo: v })}
            />
            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <Label htmlFor="grad-angle" className="text-xs text-muted-foreground">
                  Angle
                </Label>
                <span className="text-xs tabular-nums text-muted-foreground">
                  {Math.round(project.background.gradientAngle)}°
                </span>
              </div>
              <Slider
                id="grad-angle"
                aria-label="Gradient angle"
                value={[project.background.gradientAngle]}
                min={0}
                max={360}
                step={5}
                onValueChange={(v) => updateBackground({ gradientAngle: v[0] })}
              />
            </div>
          </div>
        )}

        {project.background.type === 'image' && (
          <div className="space-y-3">
            <input
              ref={bgInputRef}
              type="file"
              accept="image/png,image/jpeg,image/webp"
              className="hidden"
              aria-hidden="true"
              onChange={(e) => {
                const file = e.target.files?.[0]
                if (file) void uploadFile(file, 'image', 'bg')
                e.target.value = ''
              }}
            />
            <Button
              variant="outline"
              size="sm"
              className="w-full"
              onClick={() => bgInputRef.current?.click()}
              disabled={uploading === 'bg'}
            >
              <Upload className="mr-1.5 h-3.5 w-3.5" />
              {uploading === 'bg' ? 'Uploading…' : project.background.imageFileId ? 'Replace image' : 'Upload image'}
            </Button>
            {project.background.imageFileId && (
              <p className="flex items-center gap-1.5 text-[11px] text-muted-foreground">
                <ImageIcon className="h-3 w-3" aria-hidden="true" />
                Custom background image in use
              </p>
            )}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <Label htmlFor="overlay-opacity" className="text-xs text-muted-foreground">
                  Dark overlay
                </Label>
                <span className="text-xs tabular-nums text-muted-foreground">
                  {Math.round(project.background.overlayOpacity * 100)}%
                </span>
              </div>
              <Slider
                id="overlay-opacity"
                aria-label="Dark overlay opacity"
                value={[project.background.overlayOpacity]}
                min={0}
                max={0.9}
                step={0.05}
                onValueChange={(v) => updateBackground({ overlayOpacity: v[0] })}
              />
            </div>
          </div>
        )}

        <div className="flex items-center justify-between">
          <Label htmlFor="vignette" className="text-xs">
            Vignette effect
          </Label>
          <Switch
            id="vignette"
            checked={project.background.vignette}
            onCheckedChange={(v) => updateBackground({ vignette: v })}
            aria-label="Toggle vignette effect"
          />
        </div>
      </section>

      {/* Animation */}
      <section aria-labelledby="animation-heading" className="space-y-3">
        <h3 id="animation-heading" className="text-sm font-semibold">
          Animation
        </h3>
        <div className="grid grid-cols-2 gap-2">
          {ANIMATION_PRESETS.map((preset) => (
            <button
              key={preset.id}
              onClick={() => updateAnimation({ preset: preset.id })}
              aria-pressed={project.animation.preset === preset.id}
              title={preset.description}
              className={cn(
                'rounded-md border px-2.5 py-2 text-left transition-colors',
                project.animation.preset === preset.id
                  ? 'border-brand bg-brand/10'
                  : 'border-border/60 hover:border-border'
              )}
            >
              <span className="block text-xs font-medium">{preset.label}</span>
              <span className="mt-0.5 block truncate text-[10px] text-muted-foreground">
                {preset.description}
              </span>
            </button>
          ))}
        </div>

        {(
          [
            {
              id: 'anim-speed',
              label: 'Speed',
              display: `${project.animation.speed.toFixed(2)}×`,
              min: 0.5,
              max: 2,
              step: 0.05,
              value: project.animation.speed,
              onChange: (v: number) => updateAnimation({ speed: v }),
            },
            {
              id: 'anim-exit',
              label: 'Exit fade',
              display: `${project.animation.exitDuration.toFixed(2)}s`,
              min: 0,
              max: 1.5,
              step: 0.05,
              value: project.animation.exitDuration,
              onChange: (v: number) => updateAnimation({ exitDuration: v }),
            },
          ] as const
        ).map((ctl) => (
          <div key={ctl.id} className="space-y-1.5">
            <div className="flex items-center justify-between">
              <Label htmlFor={ctl.id} className="text-xs text-muted-foreground">
                {ctl.label}
              </Label>
              <span className="text-xs tabular-nums text-muted-foreground">{ctl.display}</span>
            </div>
            <Slider
              id={ctl.id}
              aria-label={ctl.label}
              value={[ctl.value]}
              min={ctl.min}
              max={ctl.max}
              step={ctl.step}
              onValueChange={(v) => ctl.onChange(v[0])}
            />
          </div>
        ))}

        {(presetDef.unit === 'word' || presetDef.unit === 'letter') && (
          <>
            {presetDef.unit === 'word' && (
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <Label htmlFor="word-delay" className="text-xs text-muted-foreground">
                    Delay between words
                  </Label>
                  <span className="text-xs tabular-nums text-muted-foreground">
                    {project.animation.wordDelay}ms
                  </span>
                </div>
                <Slider
                  id="word-delay"
                  aria-label="Delay between words"
                  value={[project.animation.wordDelay]}
                  min={30}
                  max={400}
                  step={10}
                  onValueChange={(v) => updateAnimation({ wordDelay: Math.round(v[0]) })}
                />
              </div>
            )}
            {presetDef.unit === 'letter' && (
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <Label htmlFor="letter-delay" className="text-xs text-muted-foreground">
                    Delay between letters
                  </Label>
                  <span className="text-xs tabular-nums text-muted-foreground">
                    {project.animation.letterDelay}ms
                  </span>
                </div>
                <Slider
                  id="letter-delay"
                  aria-label="Delay between letters"
                  value={[project.animation.letterDelay]}
                  min={10}
                  max={120}
                  step={2}
                  onValueChange={(v) => updateAnimation({ letterDelay: Math.round(v[0]) })}
                />
              </div>
            )}
          </>
        )}
      </section>

      {/* Brand kit */}
      <section aria-labelledby="brand-heading" className="space-y-3">
        <h3 id="brand-heading" className="flex items-center gap-2 text-sm font-semibold">
          Brand kit
          {!plan.brandKit && <Crown className="h-3.5 w-3.5 text-brand" aria-hidden="true" />}
        </h3>
        {!user ? (
          <p className="text-xs text-muted-foreground">
            <button className="text-brand hover:underline" onClick={() => navigate(`/signup?returnTo=${encodeURIComponent(currentHashPath())}`)}>
              Create a free account
            </button>{' '}
            to upload media and use brand tools.
          </p>
        ) : !plan.brandKit ? (
          <div className="rounded-md border border-brand/40 bg-brand/10 p-3 text-xs">
            <p className="font-medium">Brand kit is a Pro feature</p>
            <p className="mt-1 text-muted-foreground">
              Add your logo to every video and control its visibility. Available on Pro and Agency plans.
            </p>
            <Button size="sm" variant="secondary" className="mt-2" onClick={() => navigate('/billing')}>
              <Crown className="mr-1 h-3.5 w-3.5" aria-hidden="true" /> Upgrade to Pro
            </Button>
          </div>
        ) : (
          <>
            <input
              ref={logoInputRef}
              type="file"
              accept="image/png,image/jpeg,image/webp"
              className="hidden"
              aria-hidden="true"
              onChange={(e) => {
                const file = e.target.files?.[0]
                if (file) void uploadFile(file, 'image', 'logo')
                e.target.value = ''
              }}
            />
            <Button
              variant="outline"
              size="sm"
              className="w-full"
              onClick={() => logoInputRef.current?.click()}
              disabled={uploading === 'logo'}
            >
              <Upload className="mr-1.5 h-3.5 w-3.5" />
              {uploading === 'logo' ? 'Uploading…' : project.brand.logoFileId ? 'Replace logo' : 'Upload logo'}
            </Button>
            {project.brand.logoFileId && (
              <>
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="logo-opacity" className="text-xs text-muted-foreground">
                      Logo opacity
                    </Label>
                    <span className="text-xs tabular-nums text-muted-foreground">
                      {Math.round(project.brand.logoOpacity * 100)}%
                    </span>
                  </div>
                  <Slider
                    id="logo-opacity"
                    aria-label="Logo opacity"
                    value={[project.brand.logoOpacity]}
                    min={0.15}
                    max={1}
                    step={0.05}
                    onValueChange={(v) => updateBrand({ logoOpacity: v[0] })}
                  />
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  className="w-full text-muted-foreground"
                  onClick={() => updateBrand({ logoFileId: null })}
                >
                  Remove logo
                </Button>
              </>
            )}
          </>
        )}
      </section>
    </div>
  )
}
