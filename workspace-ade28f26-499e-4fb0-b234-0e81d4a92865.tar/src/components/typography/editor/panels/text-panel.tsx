'use client'

// Text panel: scene management, scene editing, script splitting, text-level
// typography controls (alignment, case) and live counts.

import { useMemo, useState } from 'react'
import {
  AlignCenter,
  AlignLeft,
  AlignRight,
  ArrowDown,
  ArrowUp,
  Copy,
  Plus,
  Scissors,
  Trash2,
  Wand2,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import { Slider } from '@/components/ui/slider'
import { Label } from '@/components/ui/label'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog'
import { toast } from 'sonner'
import { cn } from '@/lib/utils'
import { useEditorStore } from '../editor-store'
import { splitScriptIntoScenes } from '@/lib/typography/defaults'

export function TextPanel() {
  const project = useEditorStore((s) => s.project)
  const selectedSceneId = useEditorStore((s) => s.selectedSceneId)
  const selectScene = useEditorStore((s) => s.selectScene)
  const addScene = useEditorStore((s) => s.addScene)
  const deleteScene = useEditorStore((s) => s.deleteScene)
  const duplicateScene = useEditorStore((s) => s.duplicateScene)
  const moveScene = useEditorStore((s) => s.moveScene)
  const updateSceneText = useEditorStore((s) => s.updateSceneText)
  const updateSceneDuration = useEditorStore((s) => s.updateSceneDuration)
  const autoDuration = useEditorStore((s) => s.autoDuration)
  const updateStyle = useEditorStore((s) => s.updateStyle)
  const replaceScenes = useEditorStore((s) => s.replaceScenes)

  const [splitOpen, setSplitOpen] = useState(false)
  const [splitText, setSplitText] = useState('')
  const [deleteTarget, setDeleteTarget] = useState<string | null>(null)

  const selected = project.scenes.find((s) => s.id === selectedSceneId) ?? null

  const totals = useMemo(() => {
    const allText = project.scenes.map((s) => s.text).join(' ')
    return {
      chars: allText.length,
      words: allText.trim().split(/\s+/).filter(Boolean).length,
      sceneChars: selected?.text.length ?? 0,
      sceneWords: selected?.text.trim().split(/\s+/).filter(Boolean).length ?? 0,
    }
  }, [project.scenes, selected])

  const alignButtons = [
    { value: 'left' as const, icon: AlignLeft, label: 'Align left' },
    { value: 'center' as const, icon: AlignCenter, label: 'Align center' },
    { value: 'right' as const, icon: AlignRight, label: 'Align right' },
  ]

  return (
    <div className="flex flex-col gap-5">
      {/* Scene list */}
      <section aria-labelledby="scenes-heading">
        <div className="mb-2 flex items-center justify-between">
          <h3 id="scenes-heading" className="text-sm font-semibold">
            Scenes
          </h3>
          <span className="text-xs text-muted-foreground">
            {totals.words} words · {totals.chars} characters
          </span>
        </div>
        <ul className="max-h-64 space-y-1.5 overflow-y-auto pr-1 scrollbar-slim" role="listbox" aria-label="Scene list">
          {project.scenes.map((scene, i) => (
            <li key={scene.id}>
              <div
                className={cn(
                  'group flex items-center gap-1 rounded-md border px-2 py-1.5 transition-colors',
                  scene.id === selectedSceneId
                    ? 'border-brand/60 bg-brand/10'
                    : 'border-border/60 hover:border-border'
                )}
              >
                <button
                  className="min-w-0 flex-1 truncate text-left"
                  onClick={() => selectScene(scene.id)}
                  role="option"
                  aria-selected={scene.id === selectedSceneId}
                >
                  <span className="mr-1.5 text-[10px] font-semibold text-muted-foreground">{i + 1}</span>
                  <span className="text-sm text-foreground/90">
                    {scene.text.split('\n')[0]?.slice(0, 42) || 'Empty scene'}
                    {(scene.text.split('\n')[0]?.length ?? 0) > 42 ? '…' : ''}
                  </span>
                  <span className="ml-1.5 text-[10px] text-muted-foreground">{scene.duration.toFixed(1)}s</span>
                </button>
                <div className="flex shrink-0 items-center opacity-0 transition-opacity group-hover:opacity-100 focus-within:opacity-100">
                  <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => moveScene(scene.id, -1)} disabled={i === 0} aria-label={`Move scene ${i + 1} up`}>
                    <ArrowUp className="h-3.5 w-3.5" />
                  </Button>
                  <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => moveScene(scene.id, 1)} disabled={i === project.scenes.length - 1} aria-label={`Move scene ${i + 1} down`}>
                    <ArrowDown className="h-3.5 w-3.5" />
                  </Button>
                  <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => duplicateScene(scene.id)} aria-label={`Duplicate scene ${i + 1}`}>
                    <Copy className="h-3.5 w-3.5" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-7 w-7 text-destructive hover:text-destructive"
                    onClick={() => setDeleteTarget(scene.id)}
                    disabled={project.scenes.length <= 1}
                    aria-label={`Delete scene ${i + 1}`}
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </Button>
                </div>
              </div>
            </li>
          ))}
        </ul>
        <div className="mt-2 flex gap-2">
          <Button variant="outline" size="sm" className="flex-1" onClick={() => addScene(selectedSceneId ?? undefined)}>
            <Plus className="mr-1 h-3.5 w-3.5" /> Add scene
          </Button>
          <Button variant="outline" size="sm" className="flex-1" onClick={() => setSplitOpen(true)}>
            <Scissors className="mr-1 h-3.5 w-3.5" /> Split script
          </Button>
        </div>
      </section>

      {/* Selected scene editor */}
      {selected && (
        <section aria-labelledby="scene-editor-heading" className="space-y-3">
          <h3 id="scene-editor-heading" className="text-sm font-semibold">
            Scene {project.scenes.findIndex((s) => s.id === selected.id) + 1} text
          </h3>
          <div>
            <Textarea
              value={selected.text}
              onChange={(e) => updateSceneText(selected.id, e.target.value)}
              placeholder="Type your text… use blank lines for line breaks and *asterisks* to highlight words"
              rows={5}
              className="resize-y text-sm leading-relaxed"
              aria-label="Scene text"
            />
            <div className="mt-1.5 flex items-center justify-between text-[11px] text-muted-foreground">
              <span>
                {totals.sceneWords} words · {totals.sceneChars} characters
              </span>
              <button
                className="rounded px-1 text-brand hover:underline"
                onClick={() => autoDuration(selected.id)}
              >
                <Wand2 className="mr-0.5 inline h-3 w-3" aria-hidden="true" />
                Auto duration
              </button>
            </div>
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label htmlFor="scene-duration" className="text-xs">
                Duration
              </Label>
              <span className="text-xs tabular-nums text-muted-foreground">{selected.duration.toFixed(1)}s</span>
            </div>
            <Slider
              id="scene-duration"
              aria-label="Scene duration"
              value={[selected.duration]}
              min={0.5}
              max={15}
              step={0.1}
              onValueChange={(v) => updateSceneDuration(selected.id, v[0])}
            />
          </div>
        </section>
      )}

      {/* Text-level typography */}
      <section aria-labelledby="text-style-heading" className="space-y-4">
        <h3 id="text-style-heading" className="text-sm font-semibold">
          Text style
        </h3>
        <div className="space-y-1.5">
          <span className="text-xs text-muted-foreground" id="align-label">
            Alignment
          </span>
          <div className="flex overflow-hidden rounded-md border border-border" role="group" aria-labelledby="align-label">
            {alignButtons.map(({ value, icon: Icon, label }) => (
              <button
                key={value}
                onClick={() => updateStyle({ align: value })}
                aria-label={label}
                aria-pressed={project.style.align === value}
                className={cn(
                  'flex h-9 flex-1 items-center justify-center transition-colors',
                  project.style.align === value ? 'bg-brand text-white' : 'hover:bg-accent'
                )}
              >
                <Icon className="h-4 w-4" />
              </button>
            ))}
          </div>
        </div>
        <div className="space-y-1.5">
          <span className="text-xs text-muted-foreground" id="case-label">
            Letter case
          </span>
          <div className="flex overflow-hidden rounded-md border border-border" role="group" aria-labelledby="case-label">
            {(
              [
                { value: 'none', label: 'Aa', full: 'Normal' },
                { value: 'uppercase', label: 'AA', full: 'UPPERCASE' },
                { value: 'lowercase', label: 'aa', full: 'lowercase' },
              ] as const
            ).map((opt) => (
              <button
                key={opt.value}
                onClick={() => updateStyle({ transform: opt.value })}
                aria-pressed={project.style.transform === opt.value}
                aria-label={opt.full}
                className={cn(
                  'flex h-9 flex-1 items-center justify-center gap-1.5 font-mono text-xs transition-colors',
                  project.style.transform === opt.value ? 'bg-brand text-white' : 'hover:bg-accent'
                )}
              >
                {opt.label}
                <span className="hidden font-sans text-[10px] opacity-70 sm:inline">{opt.full}</span>
              </button>
            ))}
          </div>
        </div>
        <p className="text-[11px] leading-relaxed text-muted-foreground">
          Tip: wrap <code className="rounded bg-secondary px-1">*words*</code> in asterisks in the scene text to
          highlight them with your highlight color.
        </p>
      </section>

      {/* Split script dialog */}
      <Dialog open={splitOpen} onOpenChange={setSplitOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Split a script into scenes</DialogTitle>
            <DialogDescription>
              Paste a longer script. We&apos;ll break it into scenes at natural points — you can edit
              everything afterwards. This replaces your current scenes.
            </DialogDescription>
          </DialogHeader>
          <Textarea
            value={splitText}
            onChange={(e) => setSplitText(e.target.value)}
            rows={8}
            placeholder="Paste your script, quote, or lyrics here…"
            aria-label="Script to split"
          />
          <DialogFooter>
            <Button variant="ghost" onClick={() => setSplitOpen(false)}>
              Cancel
            </Button>
            <Button
              onClick={() => {
                const scenes = splitScriptIntoScenes(splitText)
                if (scenes.length === 0) {
                  toast.error('Paste some text first — we need something to split.')
                  return
                }
                replaceScenes(scenes.map((s) => s.text))
                setSplitOpen(false)
                setSplitText('')
                toast.success(`Split into ${scenes.length} scenes`)
              }}
            >
              Split into scenes
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete scene confirm */}
      <AlertDialog open={!!deleteTarget} onOpenChange={(open) => !open && setDeleteTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete this scene?</AlertDialogTitle>
            <AlertDialogDescription>
              The scene and its text will be removed from this project.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Keep scene</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-white hover:bg-destructive/90"
              onClick={() => {
                if (deleteTarget) deleteScene(deleteTarget)
                setDeleteTarget(null)
              }}
            >
              Delete scene
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
