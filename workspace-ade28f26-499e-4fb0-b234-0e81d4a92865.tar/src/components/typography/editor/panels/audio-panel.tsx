'use client'

// Audio panel: MP3/WAV upload, waveform, trim, volume, timing mode and the
// copyright notice. Word-level sync is an honest "coming soon".

import { useEffect, useRef, useState } from 'react'
import { AudioWaveform, Info, Trash2, Upload } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Label } from '@/components/ui/label'
import { Slider } from '@/components/ui/slider'
import { Switch } from '@/components/ui/switch'
import { toast } from 'sonner'
import { cn } from '@/lib/utils'
import { useEditorStore } from '../editor-store'
import { apiUpload } from '@/lib/api-client'
import { getCachedAudio, loadAudioAsset, type LoadedAudio } from '@/lib/client/assets'
import { useSession } from '@/hooks/use-session'
import { navigate, currentHashPath } from '@/hooks/use-hash-route'

function formatTime(t: number): string {
  const s = Math.floor(t)
  const m = Math.floor(s / 60)
  return `${m}:${String(s % 60).padStart(2, '0')}`
}

export function AudioPanel() {
  const project = useEditorStore((s) => s.project)
  const setAudio = useEditorStore((s) => s.setAudio)
  const { user } = useSession()
  const inputRef = useRef<HTMLInputElement>(null)
  const waveRef = useRef<HTMLCanvasElement>(null)
  const [audio, setAudioState] = useState<LoadedAudio | null>(null)
  const [loading, setLoading] = useState(false)
  const [playing, setPlaying] = useState(false)
  const previewRef = useRef<HTMLAudioElement | null>(null)

  const track = project.audio

  // Load the decoded audio whenever the track changes.
  useEffect(() => {
    if (!track) {
      setAudioState(null)
      return
    }
    const cached = getCachedAudio(track.fileId)
    if (cached) {
      setAudioState(cached)
      return
    }
    setLoading(true)
    loadAudioAsset(track.fileId)
      .then((loaded) => {
        if (loaded) setAudioState(loaded)
        else toast.error('Could not load the audio file. Try re-uploading it.')
      })
      .finally(() => setLoading(false))
  }, [track])

  // Keep the preview player volume in sync.
  useEffect(() => {
    if (previewRef.current && track) previewRef.current.volume = track.volume
  }, [track])

  // Draw the waveform with trim shading.
  useEffect(() => {
    const canvas = waveRef.current
    if (!canvas || !audio || !track) return
    const draw = () => {
      const ctx = canvas.getContext('2d')
      if (!ctx) return
      const dpr = Math.min(2, window.devicePixelRatio || 1)
      const rect = canvas.getBoundingClientRect()
      const w = Math.max(1, Math.round(rect.width * dpr))
      const h = Math.max(1, Math.round(rect.height * dpr))
      if (canvas.width !== w || canvas.height !== h) {
        canvas.width = w
        canvas.height = h
      }
      ctx.clearRect(0, 0, w, h)
      const duration = audio.buffer.duration || 1
      const start = (track.trimStart ?? 0) / duration
      const end = (track.trimEnd ?? duration) / duration
      const mid = h / 2
      audio.peaks.forEach((peak, i) => {
        const x = (i / audio.peaks.length) * w
        const inTrim = i / audio.peaks.length >= start && i / audio.peaks.length <= end
        ctx.fillStyle = inTrim ? '#FF5A1F' : 'rgba(255,255,255,0.18)'
        const barH = Math.max(2 * dpr, peak * (h - 6 * dpr))
        ctx.fillRect(x, mid - barH / 2, Math.max(1, w / audio.peaks.length - 1), barH)
      })
      // Trim markers
      ctx.fillStyle = 'rgba(255,255,255,0.5)'
      ctx.fillRect(start * w, 0, 1.5 * dpr, h)
      ctx.fillRect(end * w, 0, 1.5 * dpr, h)
    }
    draw()
    const observer = new ResizeObserver(draw)
    observer.observe(canvas)
    return () => observer.disconnect()
  }, [audio, track])

  const uploadAudio = async (file: File) => {
    if (!user) {
      toast.error('Create a free account to upload audio — it takes 20 seconds.')
      navigate(`/signup?returnTo=${encodeURIComponent(currentHashPath())}`)
      return
    }
    setLoading(true)
    try {
      const form = new FormData()
      form.set('kind', 'audio')
      form.set('file', file)
      const res = await apiUpload<{ id: string; fileName: string }>('/api/uploads', form)
      const loaded = await loadAudioAsset(res.id)
      if (!loaded) throw new Error('The audio could not be decoded. Try a different MP3 or WAV file.')
      setAudio({
        fileId: res.id,
        fileName: res.fileName,
        volume: 1,
        trimStart: 0,
        trimEnd: loaded.buffer.duration,
        timingMode: 'manual',
      })
      toast.success('Audio added')
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Audio upload failed. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  const togglePreview = () => {
    const el = previewRef.current
    if (!el || !track) return
    if (playing) {
      el.pause()
      setPlaying(false)
    } else {
      el.currentTime = track.trimStart
      el.volume = track.volume
      void el.play().then(() => setPlaying(true)).catch(() => setPlaying(false))
      el.onended = () => setPlaying(false)
      el.onpause = () => setPlaying(false)
    }
  }

  const duration = audio?.buffer.duration ?? 0
  const trimStart = track?.trimStart ?? 0
  const trimEnd = track?.trimEnd ?? duration

  return (
    <div className="flex flex-col gap-5">
      {/* Copyright notice */}
      <div className="flex items-start gap-2 rounded-md border border-border/70 bg-secondary/40 px-3 py-2.5 text-xs leading-relaxed text-muted-foreground" role="note">
        <Info className="mt-0.5 h-3.5 w-3.5 shrink-0" aria-hidden="true" />
        <span>
          Only upload audio you own or have permission to use. You are responsible for the rights to any
          music, lyrics, or podcast clips you upload.
        </span>
      </div>

      {!track ? (
        <section aria-labelledby="audio-upload-heading" className="space-y-3">
          <h3 id="audio-upload-heading" className="text-sm font-semibold">
            Add audio
          </h3>
          <input
            ref={inputRef}
            type="file"
            accept="audio/mpeg,audio/wav"
            className="hidden"
            aria-hidden="true"
            onChange={(e) => {
              const file = e.target.files?.[0]
              if (file) void uploadAudio(file)
              e.target.value = ''
            }}
          />
          <button
            onClick={() => {
              if (!user) {
                toast.error('Create a free account to upload audio — it takes 20 seconds.')
                navigate('/signup')
                return
              }
              inputRef.current?.click()
            }}
            disabled={loading}
            className="flex w-full flex-col items-center gap-2 rounded-lg border border-dashed border-border px-4 py-8 text-center transition-colors hover:border-brand/60 hover:bg-brand/5"
            aria-label="Upload MP3 or WAV audio"
          >
            <AudioWaveform className="h-6 w-6 text-brand" aria-hidden="true" />
            <span className="text-sm font-medium">{loading ? 'Uploading…' : 'Upload MP3 or WAV'}</span>
            <span className="text-xs text-muted-foreground">
              Music, voiceover, or podcast excerpt · up to {process.env.NEXT_PUBLIC_MAX_UPLOAD_MB ?? 20} MB
            </span>
          </button>
          <p className="text-[11px] text-muted-foreground">
            Audio plays in your preview and is embedded in your exported MP4.
          </p>
        </section>
      ) : (
        <>
          <section aria-labelledby="audio-file-heading" className="space-y-3">
            <div className="flex items-center justify-between gap-2">
              <h3 id="audio-file-heading" className="min-w-0 flex-1 truncate text-sm font-semibold">
                {track.fileName}
              </h3>
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8 text-destructive hover:text-destructive"
                aria-label="Remove audio"
                onClick={() => {
                  previewRef.current?.pause()
                  setPlaying(false)
                  setAudio(null)
                }}
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            </div>

            {audio && (
              <>
                <audio ref={previewRef} src={audio.objectUrl} preload="auto" className="hidden" />
                <div className="flex items-center gap-2">
                  <Button variant="secondary" size="sm" onClick={togglePreview} aria-label={playing ? 'Pause audio preview' : 'Play audio preview'}>
                    {playing ? 'Pause' : 'Play'} trimmed range
                  </Button>
                  <span className="text-xs tabular-nums text-muted-foreground">
                    {formatTime(trimStart)} – {formatTime(trimEnd)} · {formatTime(Math.max(0, trimEnd - trimStart))} used
                  </span>
                </div>

                <canvas
                  ref={waveRef}
                  className="h-16 w-full rounded-md border border-border/60 bg-[#0c0c0f]"
                  aria-label="Audio waveform with trim range highlighted"
                  role="img"
                />
              </>
            )}
            {loading && <p className="text-xs text-muted-foreground">Loading audio…</p>}

            {/* Trim */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <Label htmlFor="trim-start" className="text-xs text-muted-foreground">
                  Trim start
                </Label>
                <span className="text-xs tabular-nums text-muted-foreground">{formatTime(trimStart)}</span>
              </div>
              <Slider
                id="trim-start"
                aria-label="Trim start position"
                value={[trimStart]}
                min={0}
                max={Math.max(0.1, trimEnd - 0.5)}
                step={0.1}
                onValueChange={(v) => setAudio({ ...track, trimStart: Math.min(v[0], trimEnd - 0.5) })}
              />
            </div>
            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <Label htmlFor="trim-end" className="text-xs text-muted-foreground">
                  Trim end
                </Label>
                <span className="text-xs tabular-nums text-muted-foreground">
                  {trimEnd >= duration - 0.05 ? 'Full length' : formatTime(trimEnd)}
                </span>
              </div>
              <Slider
                id="trim-end"
                aria-label="Trim end position"
                value={[trimEnd]}
                min={Math.min(duration, trimStart + 0.5)}
                max={duration}
                step={0.1}
                onValueChange={(v) => setAudio({ ...track, trimEnd: v[0] })}
              />
            </div>

            {/* Volume */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <Label htmlFor="audio-volume" className="text-xs text-muted-foreground">
                  Volume
                </Label>
                <span className="text-xs tabular-nums text-muted-foreground">
                  {Math.round(track.volume * 100)}%
                </span>
              </div>
              <Slider
                id="audio-volume"
                aria-label="Audio volume"
                value={[track.volume]}
                min={0}
                max={1}
                step={0.05}
                onValueChange={(v) => setAudio({ ...track, volume: v[0] })}
              />
            </div>
          </section>

          {/* Timing */}
          <section aria-labelledby="timing-heading" className="space-y-3">
            <h3 id="timing-heading" className="text-sm font-semibold">
              Text timing
            </h3>
            <div className="space-y-2" role="radiogroup" aria-label="Timing mode">
              {(
                [
                  {
                    value: 'manual' as const,
                    title: 'Manual scene timing',
                    desc: 'Each scene uses the duration you set.',
                  },
                  {
                    value: 'audio-sync' as const,
                    title: 'Sync text to audio',
                    desc: `Scenes spread evenly across your trimmed audio (${formatTime(Math.max(0, trimEnd - trimStart))}).`,
                  },
                ]
              ).map((opt) => (
                <button
                  key={opt.value}
                  role="radio"
                  aria-checked={track.timingMode === opt.value}
                  onClick={() => setAudio({ ...track, timingMode: opt.value })}
                  className={cn(
                    'w-full rounded-md border px-3 py-2.5 text-left transition-colors',
                    track.timingMode === opt.value
                      ? 'border-brand bg-brand/10'
                      : 'border-border/60 hover:border-border'
                  )}
                >
                  <span className="block text-xs font-medium">{opt.title}</span>
                  <span className="mt-0.5 block text-[11px] text-muted-foreground">{opt.desc}</span>
                </button>
              ))}
            </div>
            <div className="flex items-center justify-between rounded-md border border-border/60 px-3 py-2.5 opacity-60">
              <div>
                <span className="block text-xs font-medium">
                  Word-by-word timing <span className="ml-1 rounded bg-secondary px-1.5 py-0.5 text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">Coming soon</span>
                </span>
                <span className="mt-0.5 block text-[11px] text-muted-foreground">
                  Automatic speech-to-text alignment for karaoke-precise reveals.
                </span>
              </div>
              <Switch disabled checked={false} aria-label="Word-by-word timing (coming soon)" />
            </div>
          </section>
        </>
      )}
    </div>
  )
}
