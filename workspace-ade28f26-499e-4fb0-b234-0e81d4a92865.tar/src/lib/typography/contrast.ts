// Typography — WCAG contrast helpers used to warn about unreadable text.

function parseHex(hex: string): [number, number, number] {
  let h = hex.replace('#', '').trim()
  if (h.length === 3) h = h.split('').map((c) => c + c).join('')
  if (h.length !== 6 || /[^0-9a-fA-F]/.test(h)) return [0, 0, 0]
  return [
    parseInt(h.slice(0, 2), 16),
    parseInt(h.slice(2, 4), 16),
    parseInt(h.slice(4, 6), 16),
  ]
}

function channelLuminance(c: number): number {
  const s = c / 255
  return s <= 0.03928 ? s / 12.92 : Math.pow((s + 0.055) / 1.055, 2.4)
}

export function relativeLuminance(hex: string): number {
  const [r, g, b] = parseHex(hex)
  return (
    0.2126 * channelLuminance(r) +
    0.7152 * channelLuminance(g) +
    0.0722 * channelLuminance(b)
  )
}

/** WCAG contrast ratio between two colors (1..21). */
export function contrastRatio(hexA: string, hexB: string): number {
  const la = relativeLuminance(hexA)
  const lb = relativeLuminance(hexB)
  const [lighter, darker] = la > lb ? [la, lb] : [lb, la]
  return (lighter + 0.05) / (darker + 0.05)
}

export interface ContrastCheck {
  ratio: number
  /** WCAG AA for large text is 3:1; we aim for 4.5:1 for body-size text. */
  ok: boolean
  warning: boolean
  label: string
}

export function checkContrast(textHex: string, backgroundHex: string): ContrastCheck {
  const ratio = contrastRatio(textHex, backgroundHex)
  return {
    ratio,
    ok: ratio >= 4.5,
    warning: ratio < 4.5,
    label: ratio >= 7 ? 'Excellent' : ratio >= 4.5 ? 'Good' : ratio >= 3 ? 'Low — large text only' : 'Very low — hard to read',
  }
}

/** Mix a hex color toward black/white by an amount (used to preview overlays). */
export function shade(hex: string, amount: number): string {
  const [r, g, b] = parseHex(hex)
  const t = amount < 0 ? 0 : 255
  const p = Math.abs(amount)
  const to = (c: number) => Math.round((t - c) * p + c).toString(16).padStart(2, '0')
  return `#${to(r)}${to(g)}${to(b)}`
}
