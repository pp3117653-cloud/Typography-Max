// Typography — deterministic canvas render engine.
// The SAME code renders the live preview and every exported frame, which
// guarantees a true WYSIWYG export. All sizes derive from the canvas
// dimensions, so a project renders identically at 720p, 1080p and 4K.

import { getFontDef, resolveFontFamily } from './fonts'
import type {
  AnimationPresetId,
  AnimationStyle,
  ProjectData,
  Scene,
  TypographyStyle,
} from './types'
import { CANVAS_SIZES } from './types'

/* ------------------------------------------------------------------ */
/* Layout model                                                        */
/* ------------------------------------------------------------------ */

interface LaidChar {
  ch: string
  /** x offset from the word origin. */
  x: number
  w: number
}

interface LaidWord {
  text: string
  emphasized: boolean
  /** Word origin on the canvas. */
  x: number
  y: number
  width: number
  chars: LaidChar[]
  /** Global word index within the scene. */
  index: number
  /** Cumulative char weight at the END of this word (for karaoke slots). */
  weightEnd: number
}

interface LaidLine {
  words: LaidWord[]
  width: number
  y: number
}

interface SceneLayout {
  lines: LaidLine[]
  fontSize: number
  totalChars: number
  totalWords: number
  totalWeight: number
  /** True when the font must be drawn word-by-word (script fonts). */
  wordRendering: boolean
}

export type RenderCtx = CanvasRenderingContext2D | OffscreenCanvasRenderingContext2D

/* ------------------------------------------------------------------ */
/* Parsing                                                             */
/* ------------------------------------------------------------------ */

interface ParsedWord {
  text: string
  emphasized: boolean
}

function parseWords(text: string, transform: 'none' | 'uppercase' | 'lowercase'): ParsedWord[] {
  const words: ParsedWord[] = []
  for (const rawLine of text.split('\n')) {
    const line = rawLine.trim()
    if (!line) continue
    for (const token of line.split(/\s+/)) {
      const emphasized = token.length > 2 && token.startsWith('*') && token.endsWith('*')
      let clean = emphasized ? token.slice(1, -1) : token.replace(/\*/g, '')
      if (transform === 'uppercase') clean = clean.toUpperCase()
      else if (transform === 'lowercase') clean = clean.toLowerCase()
      if (clean) words.push({ text: clean, emphasized })
    }
  }
  return words
}

/* ------------------------------------------------------------------ */
/* Layout                                                              */
/* ------------------------------------------------------------------ */

function layoutScene(
  ctx: RenderCtx,
  scene: Scene,
  style: TypographyStyle,
  W: number,
  H: number
): SceneLayout {
  const fontDef = getFontDef(style.fontId)
  const family = resolveFontFamily(style.fontId)
  const words = parseWords(scene.text, style.transform)
  const maxTextWidth = Math.max(0.3, style.maxWidth) * W
  const sideMargin = ((1 - style.maxWidth) / 2) * W

  let fontSize = style.fontSize * H
  let lines: LaidLine[] = []
  let finalSize = fontSize

  for (let attempt = 0; attempt < 24; attempt++) {
    ctx.font = `${style.fontWeight} ${fontSize}px ${family}`
    const spaceWidth = ctx.measureText(' ').width + style.letterSpacing * fontSize
    const charWidths = new Map<string, number>()
    const widthOf = (ch: string) => {
      let w = charWidths.get(ch)
      if (w === undefined) {
        w = ctx.measureText(ch).width
        charWidths.set(ch, w)
      }
      return w
    }

    const measureWord = (text: string) => {
      let w = 0
      for (const ch of text) w += widthOf(ch) + style.letterSpacing * fontSize
      return w
    }

    // Greedy line wrapping.
    const current: { words: LaidWord[]; width: number } = { words: [], width: 0 }
    lines = []
    let wordIndex = 0
    let overflow = false

    const pushLine = () => {
      if (current.words.length > 0) {
        lines.push({ words: current.words, width: current.width, y: 0 })
        current.words = []
        current.width = 0
      }
    }

    for (const parsed of words) {
      const wordWidth = measureWord(parsed.text)
      if (wordWidth > maxTextWidth) overflow = true
      const needsSpace = current.words.length > 0
      const projected = current.width + (needsSpace ? spaceWidth : 0) + wordWidth
      if (needsSpace && projected > maxTextWidth) pushLine()
      const originX = current.words.length === 0 ? 0 : current.width + spaceWidth
      const chars: LaidChar[] = []
      let cx = 0
      for (const ch of parsed.text) {
        const cw = widthOf(ch)
        chars.push({ ch, x: cx, w: cw })
        cx += cw + style.letterSpacing * fontSize
      }
      current.words.push({
        text: parsed.text,
        emphasized: parsed.emphasized,
        x: originX,
        y: 0,
        width: wordWidth,
        chars,
        index: wordIndex++,
        weightEnd: 0,
      })
      current.width = originX + wordWidth
    }
    pushLine()

    if (!overflow || fontSize <= style.fontSize * H * 0.42) {
      finalSize = fontSize
      break
    }
    fontSize *= 0.93
    finalSize = fontSize
  }

  // Vertical placement.
  const lineHeight = style.lineHeight * finalSize
  const blockHeight = lines.length * lineHeight
  const top = style.positionY * H - blockHeight / 2
  for (let i = 0; i < lines.length; i++) {
    lines[i].y = top + lineHeight * (i + 0.5)
    for (const word of lines[i].words) word.y = lines[i].y
  }

  // Horizontal placement.
  for (const line of lines) {
    let originX: number
    if (style.align === 'center') originX = (W - line.width) / 2
    else if (style.align === 'right') originX = W - sideMargin - line.width
    else originX = sideMargin
    for (const word of line.words) word.x += originX
  }

  let totalChars = 0
  let totalWeight = 0
  for (const line of lines) {
    for (const word of line.words) {
      totalChars += word.text.length
      totalWeight += word.text.length + 1
      word.weightEnd = totalWeight
    }
  }

  return {
    lines,
    fontSize: finalSize,
    totalChars,
    totalWords: lines.reduce((n, l) => n + l.words.length, 0),
    totalWeight,
    wordRendering: fontDef.prefersWordRendering,
  }
}

/* ------------------------------------------------------------------ */
/* Easing                                                              */
/* ------------------------------------------------------------------ */

const clamp01 = (v: number) => (v < 0 ? 0 : v > 1 ? 1 : v)
const easeOutCubic = (p: number) => 1 - Math.pow(1 - p, 3)
const easeOutQuint = (p: number) => 1 - Math.pow(1 - p, 5)
const easeInOutCubic = (p: number) =>
  p < 0.5 ? 4 * p * p * p : 1 - Math.pow(-2 * p + 2, 3) / 2
function elasticOut(p: number): number {
  if (p <= 0) return 0
  if (p >= 1) return 1
  const c4 = (2 * Math.PI) / 3
  return Math.pow(2, -10 * p) * Math.sin((p * 10 - 0.75) * c4) + 1
}

/* ------------------------------------------------------------------ */
/* Timing                                                              */
/* ------------------------------------------------------------------ */

export interface SceneSpan {
  index: number
  scene: Scene
  start: number
  end: number
}

/** Word count used to weight audio-sync scene durations. */
function sceneWeight(scene: Scene): number {
  const words = scene.text.trim().split(/\s+/).filter(Boolean).length
  return Math.max(2, words + 1)
}

export function computeSpans(project: ProjectData, audioDuration?: number | null): SceneSpan[] {
  const spans: SceneSpan[] = []
  let t = 0
  const syncToAudio =
    project.audio?.timingMode === 'audio-sync' &&
    typeof audioDuration === 'number' &&
    audioDuration > 0
  const weights = project.scenes.map(sceneWeight)
  const totalWeight = weights.reduce((a, b) => a + b, 0)
  project.scenes.forEach((scene, index) => {
    let duration = Math.max(0.5, scene.duration || 2)
    if (syncToAudio) {
      duration = Math.max(0.6, (audioDuration as number) * (weights[index] / totalWeight))
    }
    spans.push({ index, scene, start: t, end: t + duration })
    t += duration
  })
  return spans
}

export function totalDuration(project: ProjectData, audioDuration?: number | null): number {
  const spans = computeSpans(project, audioDuration)
  return spans.length ? spans[spans.length - 1].end : 0
}

function entranceSpec(anim: AnimationStyle, layout: SceneLayout): { duration: number; kind: 'block' | 'stagger-word' | 'stagger-letter' | 'typewriter' | 'karaoke' } {
  const speed = Math.max(0.25, anim.speed || 1)
  switch (effectivePreset(anim.preset, layout.wordRendering)) {
    case 'typewriter': {
      const perChar = 0.045 / speed
      return { duration: layout.totalChars * perChar + 0.35, kind: 'typewriter' }
    }
    case 'wordReveal':
    case 'highlightWord': {
      if (anim.preset === 'highlightWord') return { duration: 0.4, kind: 'karaoke' }
      const perWord = Math.max(0.02, (anim.wordDelay || 110) / 1000) / speed
      return { duration: (Math.max(0, layout.totalWords - 1)) * perWord + 0.45, kind: 'stagger-word' }
    }
    case 'letterReveal': {
      const perLetter = Math.max(0.01, (anim.letterDelay || 28) / 1000) / speed
      return { duration: Math.max(0, layout.totalChars - 1) * perLetter + 0.45, kind: 'stagger-letter' }
    }
    default:
      return { duration: Math.min(1.6, Math.max(0.15, 0.65 / speed)), kind: 'block' }
  }
}

function effectivePreset(preset: AnimationPresetId, wordRendering: boolean): AnimationPresetId {
  if (wordRendering && (preset === 'typewriter' || preset === 'letterReveal')) {
    return 'wordReveal'
  }
  return preset
}

/* ------------------------------------------------------------------ */
/* Backgrounds                                                         */
/* ------------------------------------------------------------------ */

function hexToRgb(hex: string): [number, number, number] {
  let h = hex.replace('#', '')
  if (h.length === 3) h = h.split('').map((c) => c + c).join('')
  const n = parseInt(h || '000000', 16)
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255]
}

export function effectiveBackgroundColor(project: ProjectData): string {
  const bg = project.background
  if (bg.type === 'gradient') {
    const [r1, g1, b1] = hexToRgb(bg.gradientFrom)
    const [r2, g2, b2] = hexToRgb(bg.gradientTo)
    const mix = (a: number, b: number) => Math.round((a + b) / 2)
    return `#${[mix(r1, r2), mix(g1, g2), mix(b1, b2)].map((c) => c.toString(16).padStart(2, '0')).join('')}`
  }
  return bg.color
}

function paintBackground(
  ctx: RenderCtx,
  project: ProjectData,
  W: number,
  H: number,
  opts: RenderOptions
): void {
  const bg = project.background
  if (bg.type === 'gradient') {
    const angle = ((bg.gradientAngle || 0) * Math.PI) / 180
    const dx = Math.sin(angle)
    const dy = -Math.cos(angle)
    const halfDiag = Math.sqrt(W * W + H * H) / 2
    const cx = W / 2
    const cy = H / 2
    const grad = ctx.createLinearGradient(
      cx - dx * halfDiag,
      cy - dy * halfDiag,
      cx + dx * halfDiag,
      cy + dy * halfDiag
    )
    grad.addColorStop(0, bg.gradientFrom)
    grad.addColorStop(1, bg.gradientTo)
    ctx.fillStyle = grad
    ctx.fillRect(0, 0, W, H)
  } else if (bg.type === 'image' && bg.imageFileId && opts.images?.get(bg.imageFileId)) {
    ctx.fillStyle = bg.color
    ctx.fillRect(0, 0, W, H)
    const img = opts.images.get(bg.imageFileId) as CanvasImageSource & {
      width: number
      height: number
    }
    // Cover fit.
    const scale = Math.max(W / img.width, H / img.height)
    const dw = img.width * scale
    const dh = img.height * scale
    ctx.drawImage(img, (W - dw) / 2, (H - dh) / 2, dw, dh)
    if (bg.overlayOpacity > 0) {
      ctx.fillStyle = `rgba(0,0,0,${clamp01(bg.overlayOpacity)})`
      ctx.fillRect(0, 0, W, H)
    }
  } else {
    if (bg.type === 'image' && bg.imageFileId) opts.onBackgroundMissing?.(bg.imageFileId)
    ctx.fillStyle = bg.color
    ctx.fillRect(0, 0, W, H)
  }

  if (bg.vignette) {
    const grad = ctx.createRadialGradient(W / 2, H / 2, Math.min(W, H) * 0.35, W / 2, H / 2, Math.max(W, H) * 0.75)
    grad.addColorStop(0, 'rgba(0,0,0,0)')
    grad.addColorStop(1, 'rgba(0,0,0,0.22)')
    ctx.fillStyle = grad
    ctx.fillRect(0, 0, W, H)
  }
}

/* ------------------------------------------------------------------ */
/* Renderer                                                            */
/* ------------------------------------------------------------------ */

export interface RenderOptions {
  watermark?: boolean
  images?: Map<string, CanvasImageSource>
  onBackgroundMissing?: (fileId: string) => void
}

export interface ProjectRenderer {
  duration: number
  spans: SceneSpan[]
  render(ctx: RenderCtx, t: number): void
  sceneIndexAt(t: number): number
}

export function createRenderer(
  project: ProjectData,
  opts: RenderOptions & { audioDuration?: number | null } = {}
): ProjectRenderer {
  const base = CANVAS_SIZES[project.format]
  const spans = computeSpans(project, opts.audioDuration)
  const duration = spans.length ? spans[spans.length - 1].end : 0
  const layouts = new Map<string, SceneLayout>()
  const reportedMissing = new Set<string>()

  const getLayout = (ctx: RenderCtx, scene: Scene): SceneLayout | null => {
    if (!scene.text.trim()) return null
    let layout = layouts.get(scene.id)
    if (!layout) {
      layout = layoutScene(ctx, scene, project.style, base.width, base.height)
      layouts.set(scene.id, layout)
    }
    return layout
  }

  const render = (ctx: RenderCtx, time: number) => {
    const W = base.width
    const H = base.height
    const t = Math.max(0, Math.min(time, duration))

    ctx.save()
    ctx.clearRect(0, 0, W, H)
    paintBackground(ctx, project, W, H, {
      ...opts,
      onBackgroundMissing: (fileId) => {
        if (!reportedMissing.has(fileId)) {
          reportedMissing.add(fileId)
          opts.onBackgroundMissing?.(fileId)
        }
      },
    })

    if (duration > 0) {
      const span =
        spans.find((s) => t >= s.start && t < s.end) ?? (t >= duration ? spans[spans.length - 1] : spans[0])
      if (span) {
        const layout = getLayout(ctx, span.scene)
        if (layout && layout.lines.length > 0) {
          drawSceneText(ctx, project, layout, span, t, W, H)
        }
      }
    }

    if (opts.watermark) drawWatermark(ctx, project, W, H)
    drawLogo(ctx, project, opts, W, H)
    ctx.restore()
  }

  return {
    duration,
    spans,
    render,
    sceneIndexAt(t) {
      const span = spans.find((s) => t >= s.start && t < s.end)
      return span ? span.index : t >= duration ? spans.length - 1 : 0
    },
  }
}

/* ------------------------------------------------------------------ */
/* Scene text drawing                                                  */
/* ------------------------------------------------------------------ */

function drawSceneText(
  ctx: RenderCtx,
  project: ProjectData,
  layout: SceneLayout,
  span: SceneSpan,
  t: number,
  W: number,
  H: number
): void {
  const style = project.style
  const anim = project.animation
  const localT = t - span.start
  const sceneDuration = span.end - span.start
  const preset = effectivePreset(anim.preset, layout.wordRendering)
  const spec = entranceSpec(anim, layout)
  const family = resolveFontFamily(style.fontId)

  // Exit fade.
  const exitDur = Math.min(Math.max(0, anim.exitDuration ?? 0.25), sceneDuration / 2)
  const timeToEnd = span.end - t
  const exitAlpha =
    exitDur <= 0 || timeToEnd > exitDur ? 1 : easeInOutCubic(clamp01(timeToEnd / exitDur))

  ctx.font = `${style.fontWeight} ${layout.fontSize}px ${family}`
  ctx.textBaseline = 'middle'
  ctx.textAlign = 'left'

  // Block-level transform (entrance).
  const blockP = clamp01(localT / Math.max(0.001, spec.duration))
  let blockDx = 0
  let blockDy = 0
  let blockScale = 1
  let blockAlpha = 1

  switch (preset) {
    case 'fade':
      blockAlpha = easeOutCubic(blockP)
      break
    case 'slideUp':
      blockDy = (1 - easeOutQuint(blockP)) * 0.06 * H
      blockAlpha = easeOutCubic(blockP)
      break
    case 'slideLeft':
      blockDx = (1 - easeOutQuint(blockP)) * 0.06 * W
      blockAlpha = easeOutCubic(blockP)
      break
    case 'slideRight':
      blockDx = -(1 - easeOutQuint(blockP)) * 0.06 * W
      blockAlpha = easeOutCubic(blockP)
      break
    case 'scaleIn':
      blockScale = 0.92 + 0.08 * easeOutCubic(blockP)
      blockAlpha = easeOutCubic(blockP)
      break
    case 'bounce':
      blockScale = 0.55 + 0.45 * elasticOut(blockP)
      blockAlpha = clamp01(blockP * 2.2)
      break
    default:
      blockAlpha = preset === 'highlightWord' ? easeOutCubic(blockP) : 1
  }

  const anchorX = W / 2
  const anchorY = style.positionY * H

  ctx.save()
  ctx.globalAlpha = ctx.globalAlpha * blockAlpha * exitAlpha
  ctx.translate(anchorX + blockDx, anchorY + blockDy)
  ctx.scale(blockScale, blockScale)
  ctx.translate(-anchorX, -anchorY)

  const speed = Math.max(0.25, anim.speed || 1)
  const wordStagger = Math.max(0.02, (anim.wordDelay || 110) / 1000) / speed

  // Karaoke state (highlightWord).
  let karaokeIndex = -1
  let karaokeFill = 0
  if (preset === 'highlightWord') {
    const startAt = Math.min(0.3, sceneDuration * 0.12)
    const endAt = sceneDuration - Math.min(0.45, sceneDuration * 0.15)
    const p = clamp01((localT - startAt) / Math.max(0.001, endAt - startAt))
    const target = p * layout.totalWeight
    for (const line of layout.lines) {
      for (const word of line.words) {
        if (target >= word.weightEnd - (word.text.length + 1)) {
          karaokeIndex = word.index
          karaokeFill = clamp01((target - (word.weightEnd - (word.text.length + 1))) / (word.text.length + 1))
        }
      }
    }
  }

  // Typewriter state.
  let visibleChars = Infinity
  let caretPosition: { x: number; y: number } | null = null
  if (preset === 'typewriter') {
    const perChar = 0.045 / speed
    visibleChars = Math.floor(localT / perChar)
  }

  let charCursor = 0
  for (const line of layout.lines) {
    for (const word of line.words) {
      // Per-word reveal progress for staggered presets (1.0 otherwise).
      const wordRevealP =
        preset === 'wordReveal'
          ? easeOutCubic(clamp01((localT - word.index * wordStagger) / 0.45))
          : 1

      if (preset === 'typewriter') {
        // Typewriter: hide words that start beyond the visible char budget.
        const wordStartChar = charCursor
        const visibleInWord = Math.max(0, Math.min(word.text.length, visibleChars - wordStartChar))
        if (visibleInWord > 0) {
          if (visibleInWord === word.text.length) {
            drawWordMarker(ctx, layout.fontSize, word, style, karaokeIndex === word.index, karaokeFill, preset)
            ctx.fillStyle = style.textColor
            ctx.fillText(word.text, word.x, word.y)
          } else {
            ctx.fillStyle = style.textColor
            const partial = word.chars.slice(0, visibleInWord).map((c) => c.ch).join('')
            ctx.fillText(partial, word.x, word.y)
            caretPosition = { x: word.x + word.chars[visibleInWord - 1].x + word.chars[visibleInWord - 1].w, y: word.y }
          }
        } else if (visibleInWord === 0 && wordStartChar === visibleChars) {
          const prev = previousWordEnd(layout, word)
          caretPosition = prev
            ? { x: prev.x, y: prev.y }
            : { x: word.x, y: word.y }
        }
        charCursor += word.text.length + 1
        continue
      }

      if (wordRevealP <= 0.001) {
        charCursor += word.text.length + 1
        continue
      }

      drawWordMarker(ctx, layout.fontSize, word, style, karaokeIndex === word.index, karaokeFill, preset)

      const prevAlpha = baseAlpha(ctx)
      ctx.globalAlpha = prevAlpha * wordRevealP

      if (
        preset === 'wordReveal' ||
        preset === 'highlightWord' ||
        layout.wordRendering ||
        wordStaggerUnit(preset) === 'word'
      ) {
        // Whole-word drawing with a slight rise for staggered reveals.
        const dy = preset === 'wordReveal' ? (1 - wordRevealP) * layout.fontSize * 0.35 : 0
        ctx.fillStyle = style.textColor
        ctx.fillText(word.text, word.x, word.y + dy)
      } else if (preset === 'letterReveal') {
        ctx.fillStyle = style.textColor
        const letterStagger = Math.max(0.01, (anim.letterDelay || 28) / 1000) / speed
        let ci = 0
        for (const ch of word.chars) {
          const letterP = clamp01((localT - (charCursor + ci) * letterStagger) / 0.4)
          if (letterP > 0.001) {
            ctx.globalAlpha = prevAlpha * wordRevealP * easeOutCubic(letterP)
            ctx.fillText(ch.ch, word.x + ch.x, word.y)
          }
          ci++
        }
      } else {
        ctx.fillStyle = style.textColor
        ctx.fillText(word.text, word.x, word.y)
      }
      ctx.globalAlpha = prevAlpha
      charCursor += word.text.length + 1
    }
  }

  // Caret for typewriter.
  if (caretPosition && caretBlinkOn(localT)) {
    ctx.fillStyle = style.highlightColor || style.textColor
    const cw = Math.max(2, layout.fontSize * 0.06)
    const chh = layout.fontSize * 0.72
    ctx.fillRect(caretPosition.x + layout.fontSize * 0.04, caretPosition.y - chh / 2, cw, chh)
  }

  ctx.restore()
}

function caretBlinkOn(t: number): boolean {
  return Math.floor(t * 2.2) % 2 === 0
}

function baseAlpha(ctx: RenderCtx): number {
  return ctx.globalAlpha
}

function wordStaggerUnit(preset: AnimationPresetId): 'word' | 'letter' | 'block' {
  if (preset === 'wordReveal' || preset === 'highlightWord') return 'word'
  return 'block'
}

function previousWordEnd(layout: SceneLayout, word: LaidWord): { x: number; y: number } | null {
  let found: LaidWord | null = null
  for (const line of layout.lines) {
    for (const w of line.words) {
      if (w.index === word.index - 1) found = w
    }
  }
  if (!found) return null
  return { x: found.x + found.width, y: found.y }
}

/** Draws the highlight marker behind a word (emphasis + karaoke current word). */
function drawWordMarker(
  ctx: RenderCtx,
  fontSize: number,
  word: LaidWord,
  style: TypographyStyle,
  isKaraokeCurrent: boolean,
  karaokeFill: number,
  preset: AnimationPresetId
): void {
  const markerWanted = word.emphasized || (isKaraokeCurrent && preset === 'highlightWord')
  if (!markerWanted) return
  const padX = fontSize * 0.1
  const padY = fontSize * 0.34
  let w = word.width + padX * 2
  if (isKaraokeCurrent && preset === 'highlightWord' && !word.emphasized) {
    w *= clamp01(karaokeFill)
  }
  if (w <= 0) return
  const x = word.x - padX
  const y = word.y - fontSize * 0.5 - padY * 0.35
  const h = fontSize + padY * 0.7
  const r = Math.min(fontSize * 0.14, h / 2)
  ctx.fillStyle = style.highlightColor
  ctx.beginPath()
  // Manual rounded rect for broad compatibility.
  ctx.moveTo(x + r, y)
  ctx.lineTo(x + w - r, y)
  ctx.arcTo(x + w, y, x + w, y + r, r)
  ctx.lineTo(x + w, y + h - r)
  ctx.arcTo(x + w, y + h, x + w - r, y + h, r)
  ctx.lineTo(x + r, y + h)
  ctx.arcTo(x, y + h, x, y + h - r, r)
  ctx.lineTo(x, y + r)
  ctx.arcTo(x, y, x + r, y, r)
  ctx.closePath()
  ctx.fill()
}

/* ------------------------------------------------------------------ */
/* Watermark & logo                                                    */
/* ------------------------------------------------------------------ */

function luminanceOf(hex: string): number {
  const [r, g, b] = hexToRgb(hex)
  return (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255
}

function drawWatermark(ctx: RenderCtx, project: ProjectData, W: number, H: number): void {
  const bgHex = effectiveBackgroundColor(project)
  const dark = luminanceOf(bgHex) > 0.55
  const color = dark ? 'rgba(15,15,17,0.62)' : 'rgba(255,255,255,0.62)'
  const size = Math.round(H * 0.024)
  const family = resolveFontFamily('inter')
  ctx.save()
  ctx.font = `600 ${size}px ${family}`
  ctx.textAlign = 'center'
  ctx.textBaseline = 'middle'
  ctx.fillStyle = color
  ctx.globalAlpha = ctx.globalAlpha * 0.9
  ctx.fillText('Typography', W / 2, H - H * 0.028)
  ctx.restore()
}

function drawLogo(
  ctx: RenderCtx,
  project: ProjectData,
  opts: RenderOptions,
  W: number,
  H: number
): void {
  const fileId = project.brand?.logoFileId
  if (!fileId) return
  const img = opts.images?.get(fileId) as (CanvasImageSource & { width: number; height: number }) | undefined
  if (!img || !img.width || !img.height) return
  const targetH = H * 0.065
  const scale = targetH / img.height
  const dw = img.width * scale
  const margin = Math.min(W, H) * 0.045
  ctx.save()
  ctx.globalAlpha = ctx.globalAlpha * clamp01(project.brand?.logoOpacity ?? 1)
  ctx.drawImage(img, W - margin - dw, margin, dw, targetH)
  ctx.restore()
}
