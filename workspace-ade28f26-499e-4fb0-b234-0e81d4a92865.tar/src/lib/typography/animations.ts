// Typography — animation preset metadata (UI-facing).
// The actual rendering lives in render-frame.ts.

import type { AnimationPresetId } from './types'

export interface AnimationPresetDef {
  id: AnimationPresetId
  label: string
  description: string
  /** Staggers content per unit — relevant for delay controls. */
  unit: 'block' | 'word' | 'letter' | 'none'
}

export const ANIMATION_PRESETS: AnimationPresetDef[] = [
  { id: 'fade', label: 'Fade in', description: 'Soft fade of the whole block', unit: 'block' },
  { id: 'slideUp', label: 'Slide up', description: 'Rises into place while fading in', unit: 'block' },
  { id: 'slideLeft', label: 'Slide left', description: 'Enters from the right edge', unit: 'block' },
  { id: 'slideRight', label: 'Slide right', description: 'Enters from the left edge', unit: 'block' },
  { id: 'scaleIn', label: 'Scale in', description: 'Grows into focus while fading in', unit: 'block' },
  { id: 'typewriter', label: 'Typewriter', description: 'Types out characters with a caret', unit: 'letter' },
  { id: 'wordReveal', label: 'Word by word', description: 'Words appear one after another', unit: 'word' },
  { id: 'letterReveal', label: 'Letter by letter', description: 'Letters cascade into place', unit: 'letter' },
  { id: 'bounce', label: 'Bounce', description: 'Springy pop into place', unit: 'block' },
  { id: 'highlightWord', label: 'Highlight word', description: 'Karaoke-style highlight that moves word by word', unit: 'word' },
]

export function getAnimationPreset(id: AnimationPresetId): AnimationPresetDef {
  return ANIMATION_PRESETS.find((p) => p.id === id) ?? ANIMATION_PRESETS[0]
}
