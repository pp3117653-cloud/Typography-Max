// Typography — plan definitions and limits.
// Pricing is displayed in INR. Billing only activates when Stripe env vars
// are configured; nothing here fakes a successful payment.

import type { PlanId } from './types'

export interface PlanDef {
  id: PlanId
  name: string
  priceLabel: string
  priceValue: number // INR per month; 0 = free
  tagline: string
  exportsPerMonth: number
  maxProjects: number
  /** Max export short-side resolution (e.g. 720, 1080, 2160). */
  maxResolution: number
  watermark: boolean
  premiumTemplates: boolean
  brandKit: boolean
  highlight: boolean
  features: { label: string; included: boolean; soon?: boolean }[]
}

export const PLANS: PlanDef[] = [
  {
    id: 'FREE',
    name: 'Free',
    priceLabel: '₹0',
    priceValue: 0,
    tagline: 'Try Typography and make your first videos.',
    exportsPerMonth: 5,
    maxProjects: 3,
    maxResolution: 720,
    watermark: true,
    premiumTemplates: false,
    brandKit: false,
    highlight: false,
    features: [
      { label: '5 video exports per month', included: true },
      { label: 'Typography watermark on exports', included: true },
      { label: '720p export resolution', included: true },
      { label: 'Standard templates', included: true },
      { label: '3 saved projects', included: true },
      { label: 'Audio upload & preview', included: true },
      { label: 'AI writing tools (limited)', included: true },
      { label: 'No watermark', included: false },
      { label: 'HD & 4K export', included: false },
    ],
  },
  {
    id: 'CREATOR',
    name: 'Creator',
    priceLabel: '₹499',
    priceValue: 499,
    tagline: 'For creators posting Reels, Shorts and TikToks every week.',
    exportsPerMonth: 30,
    maxProjects: 25,
    maxResolution: 1080,
    watermark: false,
    premiumTemplates: true,
    brandKit: false,
    highlight: true,
    features: [
      { label: '30 video exports per month', included: true },
      { label: 'No watermark', included: true },
      { label: 'Full HD 1080p export', included: true },
      { label: 'All templates', included: true },
      { label: '25 saved projects', included: true },
      { label: 'AI writing tools', included: true },
      { label: '4K export', included: false },
      { label: 'Brand kit & logo', included: false },
    ],
  },
  {
    id: 'PRO',
    name: 'Pro',
    priceLabel: '₹1,499',
    priceValue: 1499,
    tagline: 'For professionals and businesses publishing at scale.',
    exportsPerMonth: 100,
    maxProjects: 100,
    maxResolution: 2160,
    watermark: false,
    premiumTemplates: true,
    brandKit: true,
    highlight: false,
    features: [
      { label: '100 video exports per month', included: true },
      { label: 'No watermark', included: true },
      { label: 'Up to 4K export', included: true },
      { label: 'All templates', included: true },
      { label: '100 saved projects', included: true },
      { label: 'Brand colors & logo on videos', included: true },
      { label: 'Commercial-use license', included: true },
      { label: 'Custom font upload', included: false, soon: true },
    ],
  },
  {
    id: 'AGENCY',
    name: 'Agency',
    priceLabel: '₹4,999',
    priceValue: 4999,
    tagline: 'For teams producing client content every day.',
    exportsPerMonth: 500,
    maxProjects: 500,
    maxResolution: 2160,
    watermark: false,
    premiumTemplates: true,
    brandKit: true,
    highlight: false,
    features: [
      { label: '500 video exports per month', included: true },
      { label: 'No watermark', included: true },
      { label: 'Up to 4K export', included: true },
      { label: 'All templates + brand kits', included: true },
      { label: '500 saved projects', included: true },
      { label: 'Commercial client use', included: true },
      { label: 'Bulk export queue', included: true },
      { label: 'Priority rendering', included: true },
      { label: 'Team members', included: false, soon: true },
      { label: 'Client project spaces', included: false, soon: true },
    ],
  },
]

export function getPlan(id: string | null | undefined): PlanDef {
  return PLANS.find((p) => p.id === id) ?? PLANS[0]
}

export function formatINR(value: number): string {
  return `₹${value.toLocaleString('en-IN')}`
}

export const RESOLUTIONS = [
  { id: '720', label: '720p — standard', shortSide: 720, minPlan: 'FREE' as PlanId },
  { id: '1080', label: '1080p — full HD', shortSide: 1080, minPlan: 'CREATOR' as PlanId },
  { id: '2160', label: '2160p — 4K', shortSide: 2160, minPlan: 'PRO' as PlanId },
] as const

export function resolutionAllowed(plan: PlanId, resolutionId: string): boolean {
  const res = RESOLUTIONS.find((r) => r.id === resolutionId) ?? RESOLUTIONS[0]
  const planDef = getPlan(plan)
  return res.shortSide <= planDef.maxResolution
}

export function planRank(id: PlanId): number {
  return PLANS.findIndex((p) => p.id === id)
}
