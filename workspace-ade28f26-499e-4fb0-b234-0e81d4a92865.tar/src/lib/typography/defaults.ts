// Typography — default project factory, script splitting and normalization.
// Projects are versioned; normalizeProject upgrades older/partial data so the
// editor never crashes on missing fields (e.g. projects saved before a new
// style option existed).

import type { ProjectData, Scene } from './types'

export function uid(prefix = 's'): string {
  return `${prefix}_${Math.random().toString(36).slice(2, 9)}${Date.now().toString(36).slice(-4)}`
}

/** Rough reading duration for a chunk of text: ~2.6 words/second + padding. */
export function estimateDuration(text: string): number {
  const words = text.trim().split(/\s+/).filter(Boolean).length
  return Math.min(12, Math.max(1.6, words / 2.6 + 0.9))
}

export function makeScene(text: string): Scene {
  return { id: uid(), text: text.trim(), duration: Number(estimateDuration(text).toFixed(1)) }
}

export function defaultProject(): ProjectData {
  return {
    version: 1,
    format: '9:16',
    scenes: [
      makeScene('Your words.\nAnimated in *seconds*.'),
      makeScene('Paste a script, pick a style,\nand export a vertical video.'),
      makeScene('This is just a *sample* —\nreplace it with your words.'),
    ],
    style: {
      fontId: 'inter',
      fontSize: 0.075,
      fontWeight: 700,
      letterSpacing: 0,
      lineHeight: 1.25,
      align: 'center',
      transform: 'none',
      textColor: '#FFFFFF',
      highlightColor: '#FF5A1F',
      positionY: 0.5,
      maxWidth: 0.84,
    },
    background: {
      type: 'gradient',
      color: '#101014',
      gradientFrom: '#17171C',
      gradientTo: '#0A0A0D',
      gradientAngle: 160,
      imageFileId: null,
      overlayOpacity: 0.45,
      vignette: true,
    },
    animation: {
      preset: 'wordReveal',
      speed: 1,
      wordDelay: 110,
      letterDelay: 28,
      exitDuration: 0.25,
    },
    audio: null,
    brand: { logoFileId: null, logoOpacity: 1 },
    templateId: null,
  }
}

/**
 * Split a script into scenes. Prioritizes blank lines, then sentence groups
 * of ~2 sentences, then hard wraps at ~14 words.
 */
export function splitScriptIntoScenes(script: string): Scene[] {
  const text = script.replace(/\r\n/g, '\n').trim()
  if (!text) return []
  const blocks = text.split(/\n\s*\n/).map((b) => b.trim()).filter(Boolean)
  const chunks: string[] = []
  for (const block of blocks) {
    const sentences = block.match(/[^.!?\n]+[.!?]*\s*/g)?.map((s) => s.trim()).filter(Boolean) ?? [block]
    let current: string[] = []
    let wordCount = 0
    for (const sentence of sentences) {
      const sc = sentence.split(/\s+/).length
      if (wordCount > 0 && wordCount + sc > 26) {
        chunks.push(current.join(' '))
        current = []
        wordCount = 0
      }
      current.push(sentence)
      wordCount += sc
    }
    if (current.length) chunks.push(current.join(' '))
  }
  return chunks.map((chunk) => {
    // Hard-wrap extremely long chunks at ~16 words.
    const words = chunk.split(/\s+/)
    if (words.length > 20) {
      const parts: string[] = []
      for (let i = 0; i < words.length; i += 16) parts.push(words.slice(i, i + 16).join(' '))
      return parts.map((p) => makeScene(p))
    }
    return makeScene(chunk)
  }).flat()
}

/* ------------------------------------------------------------------ */
/* Normalization                                                       */
/* ------------------------------------------------------------------ */

function num(value: unknown, fallback: number, min: number, max: number): number {
  const n = typeof value === 'number' && Number.isFinite(value) ? value : fallback
  return Math.min(max, Math.max(min, n))
}

function str(value: unknown, fallback: string): string {
  return typeof value === 'string' && value ? value : fallback
}

const HEX = /^#[0-9a-fA-F]{3,8}$/

function color(value: unknown, fallback: string): string {
  return typeof value === 'string' && HEX.test(value) ? value : fallback
}

const FORMATS = ['9:16', '1:1', '16:9']
const ALIGNS = ['left', 'center', 'right']
const TRANSFORMS = ['none', 'uppercase', 'lowercase']
const BG_TYPES = ['solid', 'gradient', 'image']
const PRESETS = [
  'fade', 'slideUp', 'slideLeft', 'slideRight', 'scaleIn',
  'typewriter', 'wordReveal', 'letterReveal', 'bounce', 'highlightWord',
]
const TIMING_MODES = ['manual', 'audio-sync']

/** Upgrade/repair any incoming project JSON into a valid ProjectData. */
export function normalizeProject(input: unknown): ProjectData {
  const base = defaultProject()
  if (!input || typeof input !== 'object') return base
  const raw = input as Record<string, unknown>

  const rawScenes = Array.isArray(raw.scenes) ? raw.scenes : []
  const scenes: Scene[] = rawScenes
    .map((s) => {
      if (!s || typeof s !== 'object') return null
      const scene = s as Record<string, unknown>
      const text = typeof scene.text === 'string' ? scene.text : ''
      if (!text.trim()) return null
      return {
        id: str(scene.id, uid()),
        text,
        duration: num(scene.duration, estimateDuration(text), 0.5, 30),
      } as Scene
    })
    .filter((s): s is Scene => s !== null)

  const rawStyle = (raw.style ?? {}) as Record<string, unknown>
  const rawBg = (raw.background ?? {}) as Record<string, unknown>
  const rawAnim = (raw.animation ?? {}) as Record<string, unknown>
  const rawAudio = (raw.audio ?? null) as Record<string, unknown> | null
  const rawBrand = (raw.brand ?? {}) as Record<string, unknown>

  return {
    version: 1,
    format: FORMATS.includes(raw.format as string) ? (raw.format as ProjectData['format']) : base.format,
    scenes: scenes.length ? scenes : base.scenes,
    style: {
      fontId: str(rawStyle.fontId, base.style.fontId),
      fontSize: num(rawStyle.fontSize, base.style.fontSize, 0.02, 0.2),
      fontWeight: num(rawStyle.fontWeight, base.style.fontWeight, 100, 900),
      letterSpacing: num(rawStyle.letterSpacing, base.style.letterSpacing, -0.1, 0.6),
      lineHeight: num(rawStyle.lineHeight, base.style.lineHeight, 0.8, 3),
      align: ALIGNS.includes(rawStyle.align as string) ? (rawStyle.align as ProjectData['style']['align']) : base.style.align,
      transform: TRANSFORMS.includes(rawStyle.transform as string) ? (rawStyle.transform as ProjectData['style']['transform']) : base.style.transform,
      textColor: color(rawStyle.textColor, base.style.textColor),
      highlightColor: color(rawStyle.highlightColor, base.style.highlightColor),
      positionY: num(rawStyle.positionY, base.style.positionY, 0.08, 0.92),
      maxWidth: num(rawStyle.maxWidth, base.style.maxWidth, 0.3, 0.95),
    },
    background: {
      type: BG_TYPES.includes(rawBg.type as string) ? (rawBg.type as ProjectData['background']['type']) : base.background.type,
      color: color(rawBg.color, base.background.color),
      gradientFrom: color(rawBg.gradientFrom, base.background.gradientFrom),
      gradientTo: color(rawBg.gradientTo, base.background.gradientTo),
      gradientAngle: num(rawBg.gradientAngle, base.background.gradientAngle, 0, 360),
      imageFileId: typeof rawBg.imageFileId === 'string' ? rawBg.imageFileId : null,
      overlayOpacity: num(rawBg.overlayOpacity, base.background.overlayOpacity, 0, 0.95),
      vignette: typeof rawBg.vignette === 'boolean' ? rawBg.vignette : base.background.vignette,
    },
    animation: {
      preset: PRESETS.includes(rawAnim.preset as string) ? (rawAnim.preset as ProjectData['animation']['preset']) : base.animation.preset,
      speed: num(rawAnim.speed, base.animation.speed, 0.5, 2),
      wordDelay: num(rawAnim.wordDelay, base.animation.wordDelay, 20, 600),
      letterDelay: num(rawAnim.letterDelay, base.animation.letterDelay, 10, 200),
      exitDuration: num(rawAnim.exitDuration, base.animation.exitDuration, 0, 2),
    },
    audio:
      rawAudio && typeof rawAudio === 'object' && typeof rawAudio.fileId === 'string'
        ? {
            fileId: rawAudio.fileId as string,
            fileName: str(rawAudio.fileName, 'audio'),
            volume: num(rawAudio.volume, 1, 0, 1),
            trimStart: num(rawAudio.trimStart, 0, 0, 10000),
            trimEnd: typeof rawAudio.trimEnd === 'number' ? (rawAudio.trimEnd as number) : null,
            timingMode: TIMING_MODES.includes(rawAudio.timingMode as string)
              ? (rawAudio.timingMode as NonNullable<ProjectData['audio']>['timingMode'])
              : 'manual',
          }
        : null,
    brand: {
      logoFileId: typeof rawBrand.logoFileId === 'string' ? rawBrand.logoFileId : null,
      logoOpacity: num(rawBrand.logoOpacity, 1, 0.1, 1),
    },
    templateId: typeof raw.templateId === 'string' ? raw.templateId : null,
  }
}

/** Apply a template's design (never touches scene text). */
export function applyTemplateDesign(project: ProjectData, design: TemplateDesignPatch): ProjectData {
  return {
    ...project,
    format: design.format ?? project.format,
    style: { ...project.style, ...design.style },
    background: { ...project.background, ...design.background },
    animation: { ...project.animation, ...design.animation },
    templateId: design.templateId ?? null,
  }
}

export interface TemplateDesignPatch {
  templateId?: string
  format?: ProjectData['format']
  style?: Partial<ProjectData['style']>
  background?: Partial<ProjectData['background']>
  animation?: Partial<ProjectData['animation']>
}
