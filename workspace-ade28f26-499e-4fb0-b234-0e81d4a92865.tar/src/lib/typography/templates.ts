// Typography — template catalog.
// Each template is a complete design: fonts, palette, background, animation,
// timing and positioning. Templates only define DESIGN — applying one never
// replaces the user's scene text.

import type { ProjectData } from './types'
import type { TemplateDesignPatch } from './defaults'

export type TemplateCategory =
  | 'motivational'
  | 'minimal'
  | 'podcast'
  | 'music'
  | 'cinematic'
  | 'business'
  | 'educational'
  | 'news'
  | 'luxury'
  | 'fitness'
  | 'product'
  | 'storytelling'

export const TEMPLATE_CATEGORIES: { id: TemplateCategory; label: string }[] = [
  { id: 'motivational', label: 'Motivational' },
  { id: 'minimal', label: 'Minimal' },
  { id: 'podcast', label: 'Podcast' },
  { id: 'music', label: 'Music & lyrics' },
  { id: 'cinematic', label: 'Cinematic' },
  { id: 'business', label: 'Business' },
  { id: 'educational', label: 'Educational' },
  { id: 'news', label: 'News' },
  { id: 'luxury', label: 'Luxury' },
  { id: 'fitness', label: 'Fitness' },
  { id: 'product', label: 'Product' },
  { id: 'storytelling', label: 'Storytelling' },
]

export interface TemplateDef {
  id: string
  name: string
  description: string
  category: TemplateCategory
  premium: boolean
  /** Sample scene text used in previews and when starting a new project. */
  sampleScenes: { text: string; duration: number }[]
  design: TemplateDesignPatch & { templateId: string }
}

const style = (patch: TemplateDesignPatch['style']): TemplateDesignPatch['style'] => patch

export const TEMPLATES: TemplateDef[] = [
  {
    id: 'ignite',
    name: 'Ignite',
    description: 'Punchy bold statements with a hot accent highlight. Made for motivational pages.',
    category: 'motivational',
    premium: false,
    sampleScenes: [
      { text: 'Nobody is coming\nto save you.', duration: 2.8 },
      { text: 'Get up.\nDo the *work*.\nRepeat.', duration: 3.4 },
      { text: 'Your future self\nis watching.', duration: 2.6 },
    ],
    design: {
      templateId: 'ignite',
      format: '9:16',
      style: style({
        fontId: 'anton',
        fontSize: 0.085,
        fontWeight: 400,
        letterSpacing: 0.01,
        lineHeight: 1.14,
        align: 'center',
        transform: 'uppercase',
        textColor: '#FFFFFF',
        highlightColor: '#FF5A1F',
        positionY: 0.5,
        maxWidth: 0.86,
      }),
      background: {
        type: 'gradient',
        color: '#0C0A09',
        gradientFrom: '#1C0E06',
        gradientTo: '#08080A',
        gradientAngle: 165,
        overlayOpacity: 0.45,
        vignette: true,
      },
      animation: { preset: 'highlightWord', speed: 1.1, wordDelay: 120, letterDelay: 30, exitDuration: 0.22 },
    },
  },
  {
    id: 'essence',
    name: 'Essence',
    description: 'Quiet, confident quotes with generous whitespace and a slow fade.',
    category: 'minimal',
    premium: false,
    sampleScenes: [
      { text: '“Simplicity is the\nultimate\nsophistication.”', duration: 3.6 },
      { text: '— Leonardo da Vinci', duration: 2.2 },
    ],
    design: {
      templateId: 'essence',
      format: '9:16',
      style: style({
        fontId: 'inter',
        fontSize: 0.052,
        fontWeight: 300,
        letterSpacing: 0.02,
        lineHeight: 1.5,
        align: 'center',
        transform: 'none',
        textColor: '#1C1B1A',
        highlightColor: '#C8B89A',
        positionY: 0.47,
        maxWidth: 0.78,
      }),
      background: {
        type: 'solid',
        color: '#F6F4EF',
        gradientFrom: '#F6F4EF',
        gradientTo: '#EBE7DE',
        gradientAngle: 180,
        overlayOpacity: 0,
        vignette: false,
      },
      animation: { preset: 'fade', speed: 0.7, wordDelay: 140, letterDelay: 30, exitDuration: 0.5 },
    },
  },
  {
    id: 'airtime',
    name: 'Airtime',
    description: 'Podcast clip style — big pull-quotes that land word by word.',
    category: 'podcast',
    premium: false,
    sampleScenes: [
      { text: '“The best podcast\nadvice I ever got:\n*stop* performing.”', duration: 3.4 },
      { text: '— Episode 42', duration: 2 },
    ],
    design: {
      templateId: 'airtime',
      format: '9:16',
      style: style({
        fontId: 'space-grotesk',
        fontSize: 0.058,
        fontWeight: 600,
        letterSpacing: 0,
        lineHeight: 1.3,
        align: 'left',
        transform: 'none',
        textColor: '#F4F2EC',
        highlightColor: '#FFC94D',
        positionY: 0.52,
        maxWidth: 0.82,
      }),
      background: {
        type: 'gradient',
        color: '#111214',
        gradientFrom: '#1B1D22',
        gradientTo: '#0D0E10',
        gradientAngle: 200,
        overlayOpacity: 0.4,
        vignette: true,
      },
      animation: { preset: 'wordReveal', speed: 1, wordDelay: 130, letterDelay: 26, exitDuration: 0.25 },
    },
  },
  {
    id: 'lyric-wave',
    name: 'Lyric Wave',
    description: 'Flowing lyric video with soft script type over a dusk gradient.',
    category: 'music',
    premium: true,
    sampleScenes: [
      { text: 'We were dancing\nunder *streetlights*', duration: 3.2 },
      { text: 'humming songs\nwe half-knew', duration: 3 },
      { text: 'and the night\nwas ours', duration: 2.8 },
    ],
    design: {
      templateId: 'lyric-wave',
      format: '9:16',
      style: style({
        fontId: 'dancing-script',
        fontSize: 0.078,
        fontWeight: 600,
        letterSpacing: 0,
        lineHeight: 1.35,
        align: 'center',
        transform: 'none',
        textColor: '#FFE9F3',
        highlightColor: '#B76E79',
        positionY: 0.5,
        maxWidth: 0.84,
      }),
      background: {
        type: 'gradient',
        color: '#1A0F24',
        gradientFrom: '#33184A',
        gradientTo: '#120A1C',
        gradientAngle: 190,
        overlayOpacity: 0.35,
        vignette: true,
      },
      animation: { preset: 'wordReveal', speed: 0.85, wordDelay: 160, letterDelay: 30, exitDuration: 0.45 },
    },
  },
  {
    id: 'noir',
    name: 'Noir',
    description: 'Cinematic wide-spaced titles that fade in like film credits.',
    category: 'cinematic',
    premium: true,
    sampleScenes: [
      { text: 'Some stories\nbegin in\n*silence*.', duration: 4 },
      { text: 'This is one\nof them.', duration: 3.2 },
    ],
    design: {
      templateId: 'noir',
      format: '9:16',
      style: style({
        fontId: 'playfair',
        fontSize: 0.05,
        fontWeight: 500,
        letterSpacing: 0.14,
        lineHeight: 1.7,
        align: 'center',
        transform: 'uppercase',
        textColor: '#EDE8DF',
        highlightColor: '#8C7853',
        positionY: 0.46,
        maxWidth: 0.8,
      }),
      background: {
        type: 'gradient',
        color: '#0B0A08',
        gradientFrom: '#151310',
        gradientTo: '#060505',
        gradientAngle: 180,
        overlayOpacity: 0.5,
        vignette: true,
      },
      animation: { preset: 'fade', speed: 0.55, wordDelay: 200, letterDelay: 40, exitDuration: 0.7 },
    },
  },
  {
    id: 'launch',
    name: 'Launch',
    description: 'Clean business announcements with strong headings and a confident accent.',
    category: 'business',
    premium: true,
    sampleScenes: [
      { text: 'We are *hiring*\nproduct designers.', duration: 3 },
      { text: 'Remote-first.\nCompetitive pay.\nReal ownership.', duration: 3.6 },
      { text: 'Apply by Friday.', duration: 2.4 },
    ],
    design: {
      templateId: 'launch',
      format: '9:16',
      style: style({
        fontId: 'montserrat',
        fontSize: 0.05,
        fontWeight: 700,
        letterSpacing: 0,
        lineHeight: 1.4,
        align: 'left',
        transform: 'none',
        textColor: '#101828',
        highlightColor: '#FFB020',
        positionY: 0.45,
        maxWidth: 0.8,
      }),
      background: {
        type: 'solid',
        color: '#F3F4F6',
        gradientFrom: '#FFFFFF',
        gradientTo: '#E5E7EB',
        gradientAngle: 180,
        overlayOpacity: 0,
        vignette: false,
      },
      animation: { preset: 'slideUp', speed: 1, wordDelay: 110, letterDelay: 26, exitDuration: 0.25 },
    },
  },
  {
    id: 'did-you-know',
    name: 'Did You Know',
    description: 'Playful educational facts typed out on a chalkboard green.',
    category: 'educational',
    premium: false,
    sampleScenes: [
      { text: 'Did you know?', duration: 2 },
      { text: 'Octopuses have\n*three* hearts.', duration: 3.4 },
      { text: 'Two pump blood\nto the gills.', duration: 3 },
    ],
    design: {
      templateId: 'did-you-know',
      format: '9:16',
      style: style({
        fontId: 'poppins',
        fontSize: 0.055,
        fontWeight: 600,
        letterSpacing: 0,
        lineHeight: 1.4,
        align: 'center',
        transform: 'none',
        textColor: '#F2F7EE',
        highlightColor: '#FFD23F',
        positionY: 0.48,
        maxWidth: 0.82,
      }),
      background: {
        type: 'gradient',
        color: '#12271B',
        gradientFrom: '#1B3A27',
        gradientTo: '#0D1D14',
        gradientAngle: 170,
        overlayOpacity: 0.3,
        vignette: true,
      },
      animation: { preset: 'typewriter', speed: 1.15, wordDelay: 100, letterDelay: 24, exitDuration: 0.22 },
    },
  },
  {
    id: 'bulletin',
    name: 'Bulletin',
    description: 'Breaking-news energy — condensed caps that slam in from the side.',
    category: 'news',
    premium: true,
    sampleScenes: [
      { text: 'BREAKING', duration: 1.6 },
      { text: 'Local team wins\n*national*\nchampionship', duration: 3.2 },
      { text: 'Full story\ntonight at 9', duration: 2.6 },
    ],
    design: {
      templateId: 'bulletin',
      format: '9:16',
      style: style({
        fontId: 'oswald',
        fontSize: 0.075,
        fontWeight: 600,
        letterSpacing: 0.02,
        lineHeight: 1.16,
        align: 'left',
        transform: 'uppercase',
        textColor: '#FFFFFF',
        highlightColor: '#D6212B',
        positionY: 0.42,
        maxWidth: 0.86,
      }),
      background: {
        type: 'gradient',
        color: '#0E0F12',
        gradientFrom: '#1A1D23',
        gradientTo: '#0A0B0D',
        gradientAngle: 135,
        overlayOpacity: 0.4,
        vignette: false,
      },
      animation: { preset: 'slideLeft', speed: 1.2, wordDelay: 90, letterDelay: 22, exitDuration: 0.18 },
    },
  },
  {
    id: 'lumiere',
    name: 'Lumière',
    description: 'Luxury brand feel — champagne serif on deep charcoal, slow scale-in.',
    category: 'luxury',
    premium: true,
    sampleScenes: [
      { text: 'The new\n*Signature*\nCollection', duration: 3.8 },
      { text: 'Crafted without\ncompromise.', duration: 3.2 },
    ],
    design: {
      templateId: 'lumiere',
      format: '9:16',
      style: style({
        fontId: 'playfair',
        fontSize: 0.06,
        fontWeight: 600,
        letterSpacing: 0.06,
        lineHeight: 1.4,
        align: 'center',
        transform: 'none',
        textColor: '#E9D8A6',
        highlightColor: '#3E2F1C',
        positionY: 0.5,
        maxWidth: 0.82,
      }),
      background: {
        type: 'gradient',
        color: '#0E0D0B',
        gradientFrom: '#1C1913',
        gradientTo: '#080706',
        gradientAngle: 175,
        overlayOpacity: 0.4,
        vignette: true,
      },
      animation: { preset: 'scaleIn', speed: 0.7, wordDelay: 150, letterDelay: 34, exitDuration: 0.55 },
    },
  },
  {
    id: 'reps',
    name: 'Reps',
    description: 'High-energy fitness motivation with a springy bounce and acid accent.',
    category: 'fitness',
    premium: true,
    sampleScenes: [
      { text: 'ONE MORE\n*REP*.', duration: 2.2 },
      { text: 'Pain is\ntemporary.', duration: 2.6 },
      { text: 'Quit lasts\n*forever*.', duration: 2.6 },
    ],
    design: {
      templateId: 'reps',
      format: '9:16',
      style: style({
        fontId: 'anton',
        fontSize: 0.095,
        fontWeight: 400,
        letterSpacing: 0.02,
        lineHeight: 1.05,
        align: 'center',
        transform: 'uppercase',
        textColor: '#F5FFFE',
        highlightColor: '#B4FF39',
        positionY: 0.5,
        maxWidth: 0.88,
      }),
      background: {
        type: 'gradient',
        color: '#07100C',
        gradientFrom: '#0E1F16',
        gradientTo: '#050A07',
        gradientAngle: 160,
        overlayOpacity: 0.35,
        vignette: true,
      },
      animation: { preset: 'bounce', speed: 1.3, wordDelay: 90, letterDelay: 20, exitDuration: 0.16 },
    },
  },
  {
    id: 'showcase',
    name: 'Showcase',
    description: 'Product promos with a tidy feature list and calm motion.',
    category: 'product',
    premium: true,
    sampleScenes: [
      { text: 'Meet *Typewriter Pro*', duration: 2.6 },
      { text: 'Draft faster.\nEdit smarter.\nShip daily.', duration: 3.4 },
      { text: 'Available today.', duration: 2.2 },
    ],
    design: {
      templateId: 'showcase',
      format: '9:16',
      style: style({
        fontId: 'montserrat',
        fontSize: 0.052,
        fontWeight: 600,
        letterSpacing: 0.01,
        lineHeight: 1.5,
        align: 'center',
        transform: 'none',
        textColor: '#FFFFFF',
        highlightColor: '#2DD4BF',
        positionY: 0.5,
        maxWidth: 0.8,
      }),
      background: {
        type: 'gradient',
        color: '#0A1417',
        gradientFrom: '#0F2A2E',
        gradientTo: '#081215',
        gradientAngle: 185,
        overlayOpacity: 0.35,
        vignette: true,
      },
      animation: { preset: 'slideUp', speed: 0.9, wordDelay: 120, letterDelay: 26, exitDuration: 0.3 },
    },
  },
  {
    id: 'chapters',
    name: 'Chapters',
    description: 'Warm storytelling scenes with a bookish serif and gentle reveals.',
    category: 'storytelling',
    premium: false,
    sampleScenes: [
      { text: 'My grandmother\nkept a *journal*.', duration: 3.2 },
      { text: 'Fifty years of\nsmall handwriting.', duration: 3 },
      { text: 'This week,\nI read all of it.', duration: 3 },
    ],
    design: {
      templateId: 'chapters',
      format: '9:16',
      style: style({
        fontId: 'lora',
        fontSize: 0.052,
        fontWeight: 500,
        letterSpacing: 0.01,
        lineHeight: 1.5,
        align: 'center',
        transform: 'none',
        textColor: '#3B2F25',
        highlightColor: '#E8C39E',
        positionY: 0.48,
        maxWidth: 0.8,
      }),
      background: {
        type: 'gradient',
        color: '#F4EDE2',
        gradientFrom: '#F8F2E7',
        gradientTo: '#EADFCB',
        gradientAngle: 170,
        overlayOpacity: 0,
        vignette: false,
      },
      animation: { preset: 'wordReveal', speed: 0.9, wordDelay: 140, letterDelay: 30, exitDuration: 0.35 },
    },
  },
]

export function getTemplate(id: string | null | undefined): TemplateDef | null {
  if (!id) return null
  return TEMPLATES.find((t) => t.id === id) ?? null
}

/** Build a full starter project from a template. */
export function projectFromTemplate(template: TemplateDef): ProjectData {
  return {
    version: 1,
    format: template.design.format ?? '9:16',
    scenes: template.sampleScenes.map((s) => ({
      id: `s_${Math.random().toString(36).slice(2, 9)}`,
      text: s.text,
      duration: s.duration,
    })),
    style: {
      fontId: 'inter',
      fontSize: 0.075,
      fontWeight: 700,
      letterSpacing: 0,
      lineHeight: 1.25,
      align: 'center',
      transform: 'none',
      textColor: '#FFFFFF',
      highlightColor: '#FF5A1F',
      positionY: 0.5,
      maxWidth: 0.84,
      ...(template.design.style ?? {}),
    },
    background: {
      type: 'gradient',
      color: '#101014',
      gradientFrom: '#17171C',
      gradientTo: '#0A0A0D',
      gradientAngle: 160,
      imageFileId: null,
      overlayOpacity: 0.45,
      vignette: true,
      ...(template.design.background ?? {}),
    },
    animation: {
      preset: 'wordReveal',
      speed: 1,
      wordDelay: 110,
      letterDelay: 28,
      exitDuration: 0.25,
      ...(template.design.animation ?? {}),
    },
    audio: null,
    brand: { logoFileId: null, logoOpacity: 1 },
    templateId: template.id,
  }
}
