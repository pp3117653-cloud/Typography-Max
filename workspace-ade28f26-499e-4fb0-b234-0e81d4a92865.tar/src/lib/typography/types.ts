// Typography — shared data model
// A Project is fully serializable JSON. Font sizes are stored as fractions of
// the canvas height so the same project renders identically at any resolution.

export type CanvasFormat = '9:16' | '1:1' | '16:9'

export const CANVAS_SIZES: Record<CanvasFormat, { width: number; height: number }> = {
  '9:16': { width: 1080, height: 1920 },
  '1:1': { width: 1080, height: 1080 },
  '16:9': { width: 1920, height: 1080 },
}

export type TextAlignment = 'left' | 'center' | 'right'
export type TextTransform = 'none' | 'uppercase' | 'lowercase'

export interface Scene {
  id: string
  /** Scene text. Blank lines are respected; *word* marks an emphasized word. */
  text: string
  /** Scene duration in seconds (used when audio timing mode is "manual"). */
  duration: number
}

export interface TypographyStyle {
  fontId: string
  /** Base font size as a fraction of canvas height (e.g. 0.08 = 8%). */
  fontSize: number
  fontWeight: number
  /** Letter spacing in em. */
  letterSpacing: number
  /** Line height multiplier. */
  lineHeight: number
  align: TextAlignment
  transform: TextTransform
  textColor: string
  highlightColor: string
  /** Vertical anchor of the text block, 0..1 of canvas height. */
  positionY: number
  /** Max text block width as a fraction of canvas width. */
  maxWidth: number
}

export type BackgroundType = 'solid' | 'gradient' | 'image'

export interface BackgroundStyle {
  type: BackgroundType
  color: string
  gradientFrom: string
  gradientTo: string
  /** Gradient angle in degrees (0 = to top, 90 = to right). */
  gradientAngle: number
  /** UploadFile id for an image background. */
  imageFileId: string | null
  /** Dark overlay on top of image backgrounds, 0..1. */
  overlayOpacity: number
  /** Subtle vignette on top of the background. */
  vignette: boolean
}

export type AnimationPresetId =
  | 'fade'
  | 'slideUp'
  | 'slideLeft'
  | 'slideRight'
  | 'scaleIn'
  | 'typewriter'
  | 'wordReveal'
  | 'letterReveal'
  | 'bounce'
  | 'highlightWord'

export interface AnimationStyle {
  preset: AnimationPresetId
  /** Speed multiplier, 0.5 (slow) .. 2 (fast). */
  speed: number
  /** Delay between words in ms (word/letter based presets). */
  wordDelay: number
  /** Delay between letters in ms. */
  letterDelay: number
  /** Fade-out duration at the end of each scene, seconds. */
  exitDuration: number
}

export type AudioTimingMode = 'manual' | 'audio-sync'

export interface AudioTrack {
  /** UploadFile id. */
  fileId: string
  fileName: string
  volume: number
  /** Trim window in seconds within the source audio. */
  trimStart: number
  trimEnd: number | null
  timingMode: AudioTimingMode
}

export interface BrandSettings {
  /** UploadFile id of a logo image (Pro+). */
  logoFileId: string | null
  logoOpacity: number
}

export interface ProjectData {
  version: 1
  format: CanvasFormat
  scenes: Scene[]
  style: TypographyStyle
  background: BackgroundStyle
  animation: AnimationStyle
  audio: AudioTrack | null
  brand: BrandSettings
  templateId: string | null
}

export interface ProjectSummary {
  id: string
  name: string
  templateId: string | null
  createdAt: string
  updatedAt: string
  sceneCount: number
  durationSec: number
  format: CanvasFormat
  data: ProjectData
}

export interface ExportJobView {
  id: string
  projectId: string | null
  projectName: string
  status: 'processing' | 'completed' | 'failed' | 'expired'
  progress: number
  resolution: string
  format: string
  watermark: boolean
  durationSec: number | null
  fileSizeBytes: number | null
  error: string | null
  createdAt: string
  completedAt: string | null
}

export interface SessionUser {
  id: string
  email: string
  name: string | null
  plan: PlanId
  createdAt: string
}

export type PlanId = 'FREE' | 'CREATOR' | 'PRO' | 'AGENCY'

export interface UsageInfo {
  plan: PlanId
  exportsUsed: number
  exportsLimit: number
  projectsUsed: number
  projectsLimit: number
  periodLabel: string
  resetsAt: string
}
