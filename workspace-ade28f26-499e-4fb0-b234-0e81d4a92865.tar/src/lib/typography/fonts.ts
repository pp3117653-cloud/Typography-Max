// Typography — font catalog.
// Fonts are self-hosted through next/font/google (open-license Google Fonts, OFL).
// Each font is exposed as a CSS variable on <html>; this module resolves the
// real font-family string for canvas rendering and manages font loading.

export type FontCategory = 'sans' | 'serif' | 'display' | 'elegant' | 'handwritten' | 'mono'

export interface FontDef {
  id: string
  label: string
  cssVar: string
  category: FontCategory
  weights: number[]
  defaultWeight: number
  /** True when the canvas renderer must draw whole words (script fonts rely on joins). */
  prefersWordRendering: boolean
}

export const FONT_CATEGORIES: { id: FontCategory; label: string }[] = [
  { id: 'sans', label: 'Sans serif' },
  { id: 'serif', label: 'Serif' },
  { id: 'display', label: 'Bold display' },
  { id: 'elegant', label: 'Elegant' },
  { id: 'handwritten', label: 'Handwritten' },
  { id: 'mono', label: 'Monospace' },
]

export const FONTS: FontDef[] = [
  {
    id: 'inter',
    label: 'Inter',
    cssVar: '--font-inter',
    category: 'sans',
    weights: [300, 400, 500, 600, 700, 800, 900],
    defaultWeight: 700,
    prefersWordRendering: false,
  },
  {
    id: 'space-grotesk',
    label: 'Space Grotesk',
    cssVar: '--font-space-grotesk',
    category: 'sans',
    weights: [300, 400, 500, 600, 700],
    defaultWeight: 600,
    prefersWordRendering: false,
  },
  {
    id: 'montserrat',
    label: 'Montserrat',
    cssVar: '--font-montserrat',
    category: 'sans',
    weights: [300, 400, 500, 600, 700, 800, 900],
    defaultWeight: 800,
    prefersWordRendering: false,
  },
  {
    id: 'poppins',
    label: 'Poppins',
    cssVar: '--font-poppins',
    category: 'sans',
    weights: [300, 400, 500, 600, 700, 800],
    defaultWeight: 600,
    prefersWordRendering: false,
  },
  {
    id: 'playfair',
    label: 'Playfair Display',
    cssVar: '--font-playfair',
    category: 'serif',
    weights: [400, 500, 600, 700, 800, 900],
    defaultWeight: 700,
    prefersWordRendering: false,
  },
  {
    id: 'lora',
    label: 'Lora',
    cssVar: '--font-lora',
    category: 'serif',
    weights: [400, 500, 600, 700],
    defaultWeight: 500,
    prefersWordRendering: false,
  },
  {
    id: 'bebas',
    label: 'Bebas Neue',
    cssVar: '--font-bebas',
    category: 'display',
    weights: [400],
    defaultWeight: 400,
    prefersWordRendering: false,
  },
  {
    id: 'anton',
    label: 'Anton',
    cssVar: '--font-anton',
    category: 'display',
    weights: [400],
    defaultWeight: 400,
    prefersWordRendering: false,
  },
  {
    id: 'oswald',
    label: 'Oswald',
    cssVar: '--font-oswald',
    category: 'display',
    weights: [200, 300, 400, 500, 600, 700],
    defaultWeight: 600,
    prefersWordRendering: false,
  },
  {
    id: 'dancing-script',
    label: 'Dancing Script',
    cssVar: '--font-dancing-script',
    category: 'elegant',
    weights: [400, 500, 600, 700],
    defaultWeight: 600,
    // Script fonts lose letter connections when drawn char-by-char.
    prefersWordRendering: true,
  },
  {
    id: 'caveat',
    label: 'Caveat',
    cssVar: '--font-caveat',
    category: 'handwritten',
    weights: [400, 500, 600, 700],
    defaultWeight: 600,
    prefersWordRendering: true,
  },
  {
    id: 'jetbrains-mono',
    label: 'JetBrains Mono',
    cssVar: '--font-jetbrains-mono',
    category: 'mono',
    weights: [100, 200, 300, 400, 500, 600, 700, 800],
    defaultWeight: 500,
    prefersWordRendering: false,
  },
]

export function getFontDef(id: string): FontDef {
  return FONTS.find((f) => f.id === id) ?? FONTS[0]
}

const familyCache = new Map<string, string>()

/**
 * Resolve the real CSS font-family list for a font id by reading the CSS
 * variable that next/font places on <html>. Returns a safe fallback when the
 * variable is unavailable (e.g. before hydration).
 */
export function resolveFontFamily(id: string): string {
  const cached = familyCache.get(id)
  if (cached) return cached
  if (typeof window === 'undefined') return 'sans-serif'
  const def = getFontDef(id)
  let family = 'sans-serif'
  try {
    const value = getComputedStyle(document.documentElement).getPropertyValue(def.cssVar).trim()
    if (value) family = value
  } catch {
    family = 'sans-serif'
  }
  familyCache.set(id, family)
  return family
}

/** Invalidate the family cache (used after font CSS variables are applied). */
export function resetFontFamilyCache(): void {
  familyCache.clear()
}

const loadedFonts = new Set<string>()

/**
 * Ensure a font family is actually loaded and available to the canvas API.
 * Safe to call repeatedly; results are cached per family+weight.
 */
export async function ensureFontLoaded(id: string, weight: number): Promise<void> {
  if (typeof document === 'undefined' || !document.fonts) return
  const family = resolveFontFamily(id)
  const key = `${weight} ${family}`
  if (loadedFonts.has(key)) return
  try {
    await document.fonts.load(`${weight} 32px ${family}`, 'Typography Sample')
    loadedFonts.add(key)
  } catch {
    // Font may already be loaded or unavailable; rendering falls back gracefully.
  }
}

export async function ensureProjectFontsLoaded(fontId: string, weights: number[]): Promise<void> {
  const unique = new Set<number>([getFontDef(fontId).defaultWeight, ...weights])
  await Promise.all(Array.from(unique).map((w) => ensureFontLoaded(fontId, w)))
}
