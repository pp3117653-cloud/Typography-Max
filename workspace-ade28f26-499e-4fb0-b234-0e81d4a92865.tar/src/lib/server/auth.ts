// Server-side auth for Typography.
// - Passwords: scrypt with per-user salt (node:crypto, no external deps)
// - Sessions: HMAC-SHA256 signed, httpOnly cookie tokens (30 days)
// - Password resets: single-use hashed tokens with 1h expiry

import { createHmac, randomBytes, scryptSync, timingSafeEqual } from 'crypto'
import { cookies } from 'next/headers'
import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import type { SessionUser } from '@/lib/typography/types'

export const SESSION_COOKIE = 'typo_session'
const SESSION_TTL_SECONDS = 60 * 60 * 24 * 30

function getSecret(): string {
  const secret = process.env.AUTH_SECRET
  if (!secret || secret.length < 16) {
    throw new Error('AUTH_SECRET is missing or too short. Set it in .env (see .env.example).')
  }
  return secret
}

/* ------------------------------- passwords ------------------------------- */

export function hashPassword(password: string): string {
  const salt = randomBytes(16).toString('hex')
  const hash = scryptSync(password, salt, 64).toString('hex')
  return `scrypt:${salt}:${hash}`
}

export function verifyPassword(password: string, stored: string): boolean {
  try {
    const [scheme, salt, hash] = stored.split(':')
    if (scheme !== 'scrypt' || !salt || !hash) return false
    const candidate = scryptSync(password, salt, 64)
    const expected = Buffer.from(hash, 'hex')
    return candidate.length === expected.length && timingSafeEqual(candidate, expected)
  } catch {
    return false
  }
}

/* -------------------------------- tokens --------------------------------- */

interface SessionPayload {
  uid: string
  v: number
  exp: number
}

function signToken(payload: SessionPayload): string {
  const body = Buffer.from(JSON.stringify(payload)).toString('base64url')
  const sig = createHmac('sha256', getSecret()).update(body).digest('base64url')
  return `${body}.${sig}`
}

function verifyToken(token: string): SessionPayload | null {
  try {
    const [body, sig] = token.split('.')
    if (!body || !sig) return null
    const expected = createHmac('sha256', getSecret()).update(body).digest('base64url')
    const a = Buffer.from(sig)
    const b = Buffer.from(expected)
    if (a.length !== b.length || !timingSafeEqual(a, b)) return null
    const payload = JSON.parse(Buffer.from(body, 'base64url').toString()) as SessionPayload
    if (!payload.uid || typeof payload.exp !== 'number' || payload.exp < Date.now()) return null
    return payload
  } catch {
    return null
  }
}

/* ------------------------------- responses ------------------------------- */

export function sessionCookieSet(response: NextResponse, userId: string, tokenVersion: number): NextResponse {
  const token = signToken({ uid: userId, v: tokenVersion, exp: Date.now() + SESSION_TTL_SECONDS * 1000 })
  response.cookies.set(SESSION_COOKIE, token, {
    httpOnly: true,
    sameSite: 'lax',
    secure: process.env.NODE_ENV === 'production',
    path: '/',
    maxAge: SESSION_TTL_SECONDS,
  })
  return response
}

export function sessionCookieClear(response: NextResponse): NextResponse {
  response.cookies.set(SESSION_COOKIE, '', { httpOnly: true, path: '/', maxAge: 0 })
  return response
}

/* -------------------------------- lookup --------------------------------- */

export async function getSessionUser(req: NextRequest): Promise<SessionUser | null> {
  const token = req.cookies.get(SESSION_COOKIE)?.value
  if (!token) return null
  const payload = verifyToken(token)
  if (!payload) return null
  const user = await db.user.findUnique({ where: { id: payload.uid } })
  if (!user || user.tokenVersion !== payload.v) return null
  return {
    id: user.id,
    email: user.email,
    name: user.name,
    plan: user.plan as SessionUser['plan'],
    createdAt: user.createdAt.toISOString(),
  }
}

export async function getSessionUserFromCookieStore(): Promise<SessionUser | null> {
  const store = await cookies()
  const token = store.get(SESSION_COOKIE)?.value
  if (!token) return null
  const payload = verifyToken(token)
  if (!payload) return null
  const user = await db.user.findUnique({ where: { id: payload.uid } })
  if (!user || user.tokenVersion !== payload.v) return null
  return {
    id: user.id,
    email: user.email,
    name: user.name,
    plan: user.plan as SessionUser['plan'],
    createdAt: user.createdAt.toISOString(),
  }
}

/* ------------------------------ reset tokens ----------------------------- */

export function createResetToken(): { token: string; tokenHash: string } {
  const token = randomBytes(32).toString('hex')
  const tokenHash = createHmac('sha256', getSecret()).update(`reset:${token}`).digest('hex')
  return { token, tokenHash }
}

export function hashResetToken(token: string): string {
  return createHmac('sha256', getSecret()).update(`reset:${token}`).digest('hex')
}

/* ---------------------------------- CSRF --------------------------------- */

const ALLOWED_ORIGINS = new Set(
  [
    process.env.APP_URL,
    'http://localhost:3000',
    'http://127.0.0.1:3000',
  ].filter(Boolean) as string[]
)

/** Reject cross-site mutations (defense in depth on top of sameSite cookies). */
export function originAllowed(req: NextRequest): boolean {
  const origin = req.headers.get('origin')
  if (!origin) return true // same-origin fetches from the SPA send no Origin on GETs
  if (ALLOWED_ORIGINS.has(origin)) return true
  try {
    const url = new URL(origin)
    return url.hostname === 'localhost' || url.hostname === '127.0.0.1'
  } catch {
    return false
  }
}
