// Shared helpers for API routes.

import { NextRequest, NextResponse } from 'next/server'
import { getSessionUser } from '@/lib/server/auth'
import type { SessionUser } from '@/lib/typography/types'

/** Returns the session user or a ready-to-return 401 response. */
export async function requireUser(
  req: NextRequest
): Promise<{ user: SessionUser; res: null } | { user: null; res: NextResponse }> {
  const user = await getSessionUser(req)
  if (!user) {
    return {
      user: null,
      res: NextResponse.json({ error: 'You need to be signed in to do that.' }, { status: 401 }),
    }
  }
  return { user, res: null }
}

export function jsonError(message: string, status = 400): NextResponse {
  return NextResponse.json({ error: message }, { status })
}

export function serverError(scope: string, err: unknown): NextResponse {
  // Log details server-side; return a generic message that leaks nothing.
  console.error(`[${scope}]`, err instanceof Error ? err.message : err)
  return NextResponse.json({ error: 'Something went wrong on our side. Please try again.' }, { status: 500 })
}
