'use client'

// Client-side asset loading for canvas rendering (backgrounds, logos, audio).

export interface LoadedAudio {
  buffer: AudioBuffer
  peaks: number[]
  objectUrl: string
}

const imageCache = new Map<string, CanvasImageSource>()
const audioCache = new Map<string, LoadedAudio>()

export function getCachedImage(fileId: string): CanvasImageSource | undefined {
  return imageCache.get(fileId)
}

export async function loadImageAsset(fileId: string): Promise<CanvasImageSource | null> {
  const cached = imageCache.get(fileId)
  if (cached) return cached
  try {
    const res = await fetch(`/api/uploads/${fileId}/file`, { credentials: 'same-origin' })
    if (!res.ok) return null
    const blob = await res.blob()
    const bitmap = await createImageBitmap(blob)
    imageCache.set(fileId, bitmap)
    return bitmap
  } catch {
    return null
  }
}

export function getCachedAudio(fileId: string): LoadedAudio | undefined {
  return audioCache.get(fileId)
}

export function cacheAudio(fileId: string, audio: LoadedAudio): void {
  audioCache.set(fileId, audio)
}

export function dropAudioCache(fileId: string): void {
  const cached = audioCache.get(fileId)
  if (cached) URL.revokeObjectURL(cached.objectUrl)
  audioCache.delete(fileId)
}

/** Fetch, decode and analyze an uploaded audio file. Results are cached. */
export async function loadAudioAsset(fileId: string): Promise<LoadedAudio | null> {
  const cached = audioCache.get(fileId)
  if (cached) return cached
  try {
    const res = await fetch(`/api/uploads/${fileId}/file`, { credentials: 'same-origin' })
    if (!res.ok) return null
    const blob = await res.blob()
    const arrayBuffer = await blob.arrayBuffer()
    const AudioCtx = window.AudioContext ?? (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext
    const ctx = new AudioCtx()
    const buffer = await ctx.decodeAudioData(arrayBuffer.slice(0))
    void ctx.close()
    const peaks = computePeaks(buffer, 240)
    const objectUrl = URL.createObjectURL(blob)
    const loaded = { buffer, peaks, objectUrl }
    audioCache.set(fileId, loaded)
    return loaded
  } catch {
    return null
  }
}

function computePeaks(buffer: AudioBuffer, buckets: number): number[] {
  const channel = buffer.getChannelData(0)
  const size = Math.floor(channel.length / buckets) || 1
  const peaks: number[] = []
  for (let i = 0; i < buckets; i++) {
    const start = i * size
    const end = Math.min(channel.length, start + size)
    let peak = 0
    for (let j = start; j < end; j += Math.max(1, Math.floor((end - start) / 500))) {
      const v = Math.abs(channel[j])
      if (v > peak) peak = v
    }
    peaks.push(Math.min(1, peak))
  }
  return peaks
}
