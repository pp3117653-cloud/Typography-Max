'use client'

// Real MP4 export, fully client-side:
//   canvas frames → VideoEncoder (H.264 via WebCodecs) → mp4-muxer → Blob
//   audio (optional) → AudioEncoder (AAC) → same muxer
// The frames come from the exact same renderer used by the live preview.

import { ArrayBufferTarget, Muxer } from 'mp4-muxer'
import { CANVAS_SIZES, type ProjectData } from '@/lib/typography/types'
import { createRenderer, type RenderOptions } from '@/lib/typography/render-frame'
import { ensureProjectFontsLoaded } from '@/lib/typography/fonts'

export const EXPORT_FPS = 30

const AVC_CANDIDATES = ['avc1.640034', 'avc1.640033', 'avc1.640028', 'avc1.4d0032', 'avc1.42E01E']

export function webCodecsSupported(): boolean {
  return (
    typeof window !== 'undefined' &&
    typeof VideoEncoder !== 'undefined' &&
    typeof VideoFrame !== 'undefined'
  )
}

async function pickVideoConfig(width: number, height: number, bitrate: number) {
  for (const codec of AVC_CANDIDATES) {
    for (const hardware of ['prefer-hardware', 'no-preference'] as const) {
      const config: VideoEncoderConfig = {
        codec,
        width,
        height,
        bitrate,
        framerate: EXPORT_FPS,
        hardwareAcceleration: hardware,
      }
      try {
        const support = await VideoEncoder.isConfigSupported(config)
        if (support.supported) return config
      } catch {
        // try next
      }
    }
  }
  return null
}

function bitrateFor(width: number, height: number): number {
  // ~0.13 bits per pixel per frame keeps text crisp without bloating files.
  return Math.round(width * height * EXPORT_FPS * 0.13)
}

export function exportDimensions(project: ProjectData, resolution: '720' | '1080' | '2160') {
  const base = CANVAS_SIZES[project.format]
  const scale = resolution === '720' ? 720 / Math.min(base.width, base.height) : resolution === '1080' ? 1080 / Math.min(base.width, base.height) : 2160 / Math.min(base.width, base.height)
  // Keep exact aspect ratios and even dimensions (H.264 requirement).
  const even = (n: number) => Math.round(n / 2) * 2
  return { width: even(base.width * scale), height: even(base.height * scale) }
}

export interface ExportOptions {
  project: ProjectData
  resolution: '720' | '1080' | '2160'
  watermark: boolean
  images?: Map<string, CanvasImageSource>
  audioBuffer?: AudioBuffer | null
  audioVolume?: number
  audioTrimStart?: number
  audioTrimEnd?: number | null
  onProgress?: (progress: number, stage: 'preparing' | 'rendering' | 'finalizing') => void
  shouldCancel?: () => boolean
}

export class ExportError extends Error {
  constructor(message: string) {
    super(message)
    this.name = 'ExportError'
  }
}

interface PcmData {
  channels: Float32Array[]
  sampleRate: number
  frameCount: number
}

/**
 * Pick the best audio codec this browser can actually encode:
 * AAC first (best compatibility with social platforms), then Opus in MP4.
 * Returns null when no audio encoder is available at all.
 */
async function pickAudioEncoder(
  audio: AudioBuffer
): Promise<{ config: AudioEncoderConfig; muxerCodec: 'aac' | 'opus'; resampleTo: number | null } | null> {
  const channels = Math.min(2, audio.numberOfChannels)
  const aac: AudioEncoderConfig = {
    codec: 'mp4a.40.2',
    sampleRate: audio.sampleRate,
    numberOfChannels: channels,
    bitrate: 128_000,
  }
  try {
    const s = await AudioEncoder.isConfigSupported(aac)
    if (s.supported) return { config: aac, muxerCodec: 'aac', resampleTo: null }
  } catch {
    /* try opus */
  }
  // Opus only supports 48 kHz — resample via OfflineAudioContext.
  const opus: AudioEncoderConfig = {
    codec: 'opus',
    sampleRate: 48_000,
    numberOfChannels: channels,
    bitrate: 128_000,
  }
  try {
    const s = await AudioEncoder.isConfigSupported(opus)
    if (s.supported) return { config: opus, muxerCodec: 'opus', resampleTo: 48_000 }
  } catch {
    /* none */
  }
  return null
}

/** Resample (and optionally trim) an AudioBuffer to the target sample rate. */
async function resampleAudio(
  audio: AudioBuffer,
  startSample: number,
  endSample: number,
  targetRate: number
): Promise<AudioBuffer> {
  const frames = Math.max(1, endSample - startSample)
  const outFrames = Math.max(1, Math.ceil((frames * targetRate) / audio.sampleRate))
  const channels = Math.min(2, audio.numberOfChannels)
  const offline = new OfflineAudioContext(channels, outFrames, targetRate)
  // Copy the trimmed segment into a buffer at the ORIGINAL rate; the
  // OfflineAudioContext resamples it during rendering.
  const segment = offline.createBuffer(audio.numberOfChannels, frames, audio.sampleRate)
  for (let c = 0; c < audio.numberOfChannels; c++) {
    segment.copyToChannel(audio.getChannelData(c).slice(startSample, endSample), c)
  }
  const src = offline.createBufferSource()
  src.buffer = segment
  src.connect(offline.destination)
  src.start()
  return offline.startRendering()
}

export interface ExportResult {
  blob: Blob
  durationSec: number
  /** Audio codec actually muxed into the MP4 (null = video-only). */
  audioMuxed: 'aac' | 'opus' | null
  /** True when the project has audio that the user expects to hear. */
  audioIntended: boolean
}

export async function encodeProjectToMp4(opts: ExportOptions): Promise<ExportResult> {
  const { project, resolution, watermark } = opts
  if (!webCodecsSupported()) {
    throw new ExportError(
      'This browser cannot encode MP4 video. Please use the latest Chrome, Edge or Opera on desktop.'
    )
  }
  if (!project.scenes.length) {
    throw new ExportError('Add at least one scene with text before exporting.')
  }

  await ensureProjectFontsLoaded(project.style.fontId, [project.style.fontWeight])

  const { width, height } = exportDimensions(project, resolution)
  const renderOpts: RenderOptions = { watermark, images: opts.images }

  const audio = opts.audioBuffer ?? null
  const audioDuration = audio
    ? Math.max(0, (opts.audioTrimEnd ?? audio.duration) - (opts.audioTrimStart ?? 0))
    : null

  const renderer = createRenderer(project, { ...renderOpts, audioDuration })
  const duration = renderer.duration
  if (duration <= 0) throw new ExportError('The project has no playable scenes.')

  const totalFrames = Math.max(1, Math.ceil(duration * EXPORT_FPS))

  const videoConfig = await pickVideoConfig(width, height, bitrateFor(width, height))
  if (!videoConfig) {
    throw new ExportError(
      'This browser has no H.264 encoder available. Try the latest Chrome or Edge on desktop.'
    )
  }

  // Audio setup: prefer AAC, fall back to Opus (48 kHz). Honest result so the
  // UI can tell the user when audio could not be embedded.
  let audioPick: Awaited<ReturnType<typeof pickAudioEncoder>> = null
  if (audio && audioDuration && audioDuration > 0.05) {
    audioPick = await pickAudioEncoder(audio)
  }
  const audioConfig = audioPick?.config ?? null
  const audioChannels = audioConfig?.numberOfChannels ?? 0
  const audioSampleRate = audioConfig?.sampleRate ?? 0

  const target = new ArrayBufferTarget()
  const muxer = new Muxer({
    target,
    fastStart: 'in-memory',
    video: { codec: 'avc', width, height },
    ...(audioConfig
      ? { audio: { codec: audioPick!.muxerCodec, numberOfChannels: audioChannels, sampleRate: audioSampleRate } }
      : {}),
  })

  let encodeError: Error | null = null
  const videoEncoder = new VideoEncoder({
    output: (chunk, meta) => muxer.addVideoChunk(chunk, meta),
    error: (e) => {
      encodeError = e
    },
  })
  videoEncoder.configure(videoConfig)

  const canvas = document.createElement('canvas')
  canvas.width = width
  canvas.height = height
  const ctx = canvas.getContext('2d', { alpha: false })
  if (!ctx) throw new ExportError('Could not create the rendering canvas.')

  // The renderer works in project coordinates (e.g. 1080x1920); map it onto
  // the export canvas dimensions. exportDimensions preserves the aspect
  // ratio, so a single uniform scale is exact.
  const baseSize = CANVAS_SIZES[project.format]
  const exportScale = width / baseSize.width
  ctx.setTransform(exportScale, 0, 0, exportScale, 0, 0)

  const frameDuration = 1_000_000 / EXPORT_FPS
  opts.onProgress?.(0, 'preparing')

  for (let i = 0; i < totalFrames; i++) {
    if (opts.shouldCancel?.()) {
      videoEncoder.close()
      throw new ExportError('Export cancelled.')
    }
    if (encodeError) break

    const t = Math.min(duration, i / EXPORT_FPS)
    renderer.render(ctx, t)

    const frame = new VideoFrame(canvas, {
      timestamp: Math.round(i * frameDuration),
      duration: Math.round(frameDuration),
    })
    videoEncoder.encode(frame, { keyFrame: i % (EXPORT_FPS * 2) === 0 })
    frame.close()

    // Backpressure so memory stays flat on long videos.
    while (videoEncoder.encodeQueueSize > 8) {
      await new Promise((r) => setTimeout(r, 8))
    }
    if (i % 6 === 0) opts.onProgress?.(i / totalFrames, 'rendering')
  }

  if (encodeError !== null) {
    const encErr: Error = encodeError
    videoEncoder.close()
    throw new ExportError(`Video encoding failed: ${encErr.message}`)
  }

  await videoEncoder.flush()
  videoEncoder.close()

  // Audio track.
  let audioMuxed: 'aac' | 'opus' | null = null
  if (audioConfig && audio && audioPick) {
    opts.onProgress?.(0.9, 'rendering')
    const trimmedDuration = Math.min(duration, audioDuration ?? duration)
    const startSample = Math.floor((opts.audioTrimStart ?? 0) * audio.sampleRate)
    const endSample = Math.min(audio.length, Math.floor(startSample + trimmedDuration * audio.sampleRate))
    const volume = opts.audioVolume ?? 1

    // For Opus the encoder requires 48 kHz — resample the trimmed segment.
    let pcm: PcmData = {
      channels: [],
      sampleRate: audio.sampleRate,
      frameCount: 0,
    }
    if (audioPick.resampleTo && audioPick.resampleTo !== audio.sampleRate) {
      try {
        const resampled = await resampleAudio(audio, startSample, endSample, audioPick.resampleTo)
        pcm = {
          channels: Array.from({ length: audioChannels }, (_, c) =>
            resampled.getChannelData(Math.min(c, resampled.numberOfChannels - 1))
          ),
          sampleRate: resampled.sampleRate,
          frameCount: resampled.length,
        }
      } catch {
        pcm = { channels: [], sampleRate: 0, frameCount: 0 }
      }
    } else {
      pcm = {
        channels: Array.from({ length: audioChannels }, (_, c) =>
          audio.getChannelData(Math.min(c, audio.numberOfChannels - 1))
        ),
        sampleRate: audio.sampleRate,
        frameCount: Math.max(0, endSample - startSample),
        // slice offsets handled below via baseOffset
      }
    }

    if (pcm.frameCount > 0) {
      const audioEncoder = new AudioEncoder({
        output: (chunk, meta) => muxer.addAudioChunk(chunk, meta),
        error: () => {
          /* audio failures fall back to video-only below */
        },
      })
      audioEncoder.configure(audioConfig)

      const CHUNK = 1024
      try {
        for (let offset = 0; offset < pcm.frameCount; offset += CHUNK) {
          if (opts.shouldCancel?.()) throw new ExportError('Export cancelled.')
          const frames = Math.min(CHUNK, pcm.frameCount - offset)
          const data = new Float32Array(frames * audioChannels)
          for (let c = 0; c < audioChannels; c++) {
            const src =
              audioPick.resampleTo && audioPick.resampleTo !== audio.sampleRate
                ? pcm.channels[c]
                : pcm.channels[c].subarray(startSample + offset, startSample + offset + frames)
            for (let j = 0; j < frames; j++) {
              data[c * frames + j] = src[j] * volume
            }
          }
          const audioData = new AudioData({
            format: 'f32-planar',
            sampleRate: pcm.sampleRate,
            numberOfFrames: frames,
            numberOfChannels: audioChannels,
            timestamp: Math.round((offset / pcm.sampleRate) * 1_000_000),
            data,
          })
          audioEncoder.encode(audioData)
          audioData.close()
          while (audioEncoder.encodeQueueSize > 16) {
            await new Promise((r) => setTimeout(r, 4))
          }
        }
        await audioEncoder.flush()
        audioMuxed = audioPick.muxerCodec
      } catch {
        // If audio encoding fails we still deliver the video track.
        audioMuxed = null
      } finally {
        audioEncoder.close()
      }
    }
  }

  opts.onProgress?.(0.97, 'finalizing')
  muxer.finalize()
  opts.onProgress?.(1, 'finalizing')

  const blob = new Blob([target.buffer], { type: 'video/mp4' })
  return {
    blob,
    durationSec: duration,
    audioMuxed: audio && audioDuration && audioDuration > 0.05 ? audioMuxed : null,
    audioIntended: Boolean(audio && audioDuration && audioDuration > 0.05),
  }
}

/**
 * Rough export-time estimate from a short render benchmark (honest: based on
 * the user's actual machine, measured live).
 */
export async function estimateExportTime(
  project: ProjectData,
  resolution: '720' | '1080' | '2160'
): Promise<number> {
  await ensureProjectFontsLoaded(project.style.fontId, [project.style.fontWeight])
  const { width, height } = exportDimensions(project, resolution)
  const renderer = createRenderer(project, {})
  if (renderer.duration <= 0) return 0
  const totalFrames = Math.ceil(renderer.duration * EXPORT_FPS)

  const canvas = document.createElement('canvas')
  canvas.width = width
  canvas.height = height
  const ctx = canvas.getContext('2d', { alpha: false })
  if (!ctx) return 0
  const baseSize = CANVAS_SIZES[project.format]
  ctx.setTransform(width / baseSize.width, 0, 0, height / baseSize.height, 0, 0)

  const benchFrames = 5
  const start = performance.now()
  for (let i = 0; i < benchFrames; i++) {
    renderer.render(ctx, (i / benchFrames) * renderer.duration)
  }
  const renderMs = (performance.now() - start) / benchFrames
  // Encoding typically adds ~60% on top of render time.
  const perFrameMs = renderMs * 1.6
  return Math.max(1, Math.round((totalFrames * perFrameMs) / 1000))
}
